ENT.Type = "ai";
ENT.Base = "base_ai";

ENT.PrintName		= "Drug Dealer";
ENT.Author			= "disseminate";
ENT.Contact			= "";
ENT.Purpose			= "";
ENT.Instructions	= "";

ENT.Category			= "GDrugs";
ENT.Spawnable			= GD.AdminsCanSpawnNPCs;
ENT.AdminSpawnable		= GD.AdminsCanSpawnNPCs;

function ENT:SetupDataTables()
	
	
	
end
