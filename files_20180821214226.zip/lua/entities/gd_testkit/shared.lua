ENT.Type = "anim";
ENT.Base = "base_anim";

ENT.PrintName		= "Test Kit";
ENT.Author			= "disseminate";
ENT.Contact			= "";
ENT.Purpose			= "";
ENT.Instructions	= "";

ENT.Spawnable			= false;
ENT.AdminSpawnable		= false;

function ENT:SetupDataTables()
	
	
	
end
