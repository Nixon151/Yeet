include( "shared.lua" );

function ENT:Draw3D2D( p )
	
	local a = 1;
	local d = LocalPlayer():EyePos():Distance( p );
	if( d > GD.DrugFadeStart ) then
		a = 1 - ( ( d - GD.DrugFadeStart ) / ( GD.DrugFadeEnd - GD.DrugFadeStart ) );
	end
	
	if( a <= 0 ) then return end
	
	surface.SetFont( "GD.LabEntitySmall" );
	local w, h = surface.GetTextSize( "Test Kit" );
	
	local y = 0;
	
	surface.SetTextColor( Color( 255, 255, 255, 255 * a ) );
	surface.SetTextPos( -w / 2, y );
	surface.DrawText( "Test Kit" );
	
end

function ENT:Draw()
	
	self:DrawModel();
	
	local a = LocalPlayer():EyeAngles();
	a:RotateAroundAxis( a:Forward(), 90 );
	a:RotateAroundAxis( a:Right(), 90 );
	
	local o = self:OBBMaxs().z + 10;
	local p = self:GetPos() + Vector( 0, 0, o );
	
	cam.Start3D2D( p, a, 0.07 );
		self:Draw3D2D( p );
	cam.End3D2D();
	
end
