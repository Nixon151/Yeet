ITEM.Class = "gd_meth";
ITEM.Name = "Class E Amnestics";
ITEM.Description = "It's Class E Amnestics.";
ITEM.Model = "models/gdrugs/meth/meth.mdl";
ITEM.Base = "base_gdrugs";
