ITEM.Class = "gd_lsd";
ITEM.Name = "Class D Amnestics";
ITEM.Description = "It's Class D Amnestics.";
ITEM.Model = "models/props_junk/garbage_newspaper001a.mdl";
ITEM.Base = "base_gdrugs";
