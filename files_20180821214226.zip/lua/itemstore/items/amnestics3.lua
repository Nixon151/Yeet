ITEM.Class = "gd_coke";
ITEM.Name = "Class C Amnestics";
ITEM.Description = "It's Class C Amnestics.";
ITEM.Model = "models/gdrugs/cocaine/cocaine.mdl";
ITEM.Base = "base_gdrugs";
