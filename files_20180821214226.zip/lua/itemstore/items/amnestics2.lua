ITEM.Class = "gd_tobacco";
ITEM.Name = "Class B Amnestics";
ITEM.Description = "It's Class B Amnestics.";
ITEM.Model = "models/gdrugs/weed/weed.mdl";
ITEM.Base = "base_gdrugs";
