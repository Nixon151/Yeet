ITEM.Class = "gd_weed";
ITEM.Name = "Class A Amnestics";
ITEM.Description = "It's Class A Amnestics.";
ITEM.Model = "models/gdrugs/weed/weed.mdl";
ITEM.Base = "base_gdrugs";
