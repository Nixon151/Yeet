#bodyGroupr

Easy bodygroup management for darkrp!

Created by Arizard and Zelpa.

Please consult README.lua for instructions.