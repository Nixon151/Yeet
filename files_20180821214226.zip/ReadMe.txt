FancyScoreboard
Version 1.3.4
Updated: 12/03/2018
Created by: http://steamcommunity.com/profiles/76561198046951756


Installation:

Put the fancy_scoreboard folder into your Garry's Mod addons folder
The folder structure should look like this: 'garrysmod/addons/fancy_scoreboard'


Configuration:

If you wish to edit the config of the scoreboard, do so via the 'config.lua' file located at:
'fancy_scoreboard/lua/fancy_scoreboard/config.lua'

I will not provide support if you edit any of the other base files!


Changelog:

v.1.3.4
- More Lua error fixes

v.1.3.3
- Fixed more common errors

v1.3.2
- Fixed misc lua errors
- Added more custom FAdmin menus

v1.3.1
- Fixed error when running other gamemodes
- Added option to disable "Team" or "Job" column

v1.3
- Fixed errors when players disconnect
- Fixed bug with ping not displaying properly
- Added Serverguard support

v1.2
- Fixed error with quick settings
- Added more settings for displaying team color
- Added support for adding custom columns to the scoreboard (Requires some more advanced Lua knowledge)

v1.1.2
- Fixed more issues with scoreboard getting stuck

v1.1.1
- Fixed issues with scoreboard getting stuck

v1.1
- Added team category sorting
- Added language features
- Added rank icons
- Added team colors
- Fixed various issues with menu not closing/opening properly
- Fixed issues with admin functions showing to non-admins

v1.0.2
- Fixed spacing issue for quick settings

v1.0.1
- Fixed sizing issue for certain screen sizes

v1.0
- Initial release