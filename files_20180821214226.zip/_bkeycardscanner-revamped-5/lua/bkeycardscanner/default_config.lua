bKeycardScanner.Config={}local
_=bKeycardScanner.Config
_.DefaultWeapon=!!1
_.TakeKeycard=!!1
_.Admins={"superadmin","76561198040894045","STEAM_0:1:40314158"}_.AllowPhysgun=!!1
_.ScanDistance=80
_.ScanTime=1.5
_.KeycardScannerESP={"superadmin","76561198040894045","STEAM_0:1:40314158"}_.MinimumTime=2
_.CrackTime=30
_.ProCrackTime=15
_.AllowIndentification=!!1
_.ShowIDCommand="/showid"_.ShowIDDistance=100
_.ShowIDString="%name% presents their identification, it reads: %team%"_.customChecks={}