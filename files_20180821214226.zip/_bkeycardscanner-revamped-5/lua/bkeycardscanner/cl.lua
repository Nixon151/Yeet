if (IsValid(bKeycardScanner.Menu)) then
	bKeycardScanner.Menu:Close()
end
if (IsValid(bKeycardScanner_Add_Frame)) then
	bKeycardScanner_Add_Frame:Close()
end

function bKeycardScanner:chatprint(msg,type)
	if (type == "error" or type == "bad") then
		chat.AddText(Color(255,0,0),"[bKeycardScanner] ",Color(255,255,255),msg)
	elseif (type == "success" or type == "good") then
		chat.AddText(Color(0,255,0),"[bKeycardScanner] ",Color(255,255,255),msg)
	else
		chat.AddText(Color(0,255,255),"[bKeycardScanner] ",Color(255,255,255),msg)
	end
end

bKeycardScanner:netr("mirror_scanners_nopermission",function()
	bKeycardScanner:chatprint("You don't have permission to interact with this keycard scanner.","bad")
end)

local function openmenu()
	local keycard_scanner = net.ReadEntity()
	local parent_child = net.ReadInt(3)

	bKeycardScanner.MenuKeycardScanner = keycard_scanner

	if (IsValid(bKeycardScanner.DoorLinkingFrom)) then
		bKeycardScanner.DoorLinkingFrom = nil
	end
	if (IsValid(bKeycardScanner.LinkingFrom)) then
		if (bKeycardScanner.LinkingFrom == keycard_scanner) then
			bKeycardScanner.LinkingFrom = nil
		else
			surface.PlaySound("garrysmod/content_downloaded.wav")
			bKeycardScanner:chatprint("Mirrored!","good")
			bKeycardScanner:nets("mirror_scanners")
				net.WriteEntity(bKeycardScanner.LinkingFrom)
				net.WriteEntity(keycard_scanner)
			net.SendToServer()
			bKeycardScanner.LinkingFrom = nil
			return
		end
	end

	if (IsValid(bKeycardScanner.Menu)) then
		bKeycardScanner.Menu:Close()
	end
	if (IsValid(bKeycardScanner_Add_Frame)) then
		bKeycardScanner_Add_Frame:Close()
	end

	bKeycardScanner_Add_Frame = vgui.Create("bKeycardScanner_DFrame")
	bKeycardScanner_Add_Frame.Alpha = 255
	bKeycardScanner_Add_Frame:SetVisible(false)
	bKeycardScanner_Add_Frame:SetTitle("")
	bKeycardScanner_Add_Frame:SetSize(350,135)
	bKeycardScanner_Add_Frame:Center()
	bKeycardScanner_Add_Frame.close.DoClick = function()
		bKeycardScanner_Add_Frame:SetVisible(false)
		bKeycardScanner_Add_Frame.TextLabel:SetText("")
	end

	bKeycardScanner_Add_Frame.ListcustomChecks = vgui.Create("bKeycardScanner_ListView",bKeycardScanner_Add_Frame)
	bKeycardScanner_Add_Frame.ListcustomChecks:SetSize(325,290)
	bKeycardScanner_Add_Frame.ListcustomChecks:AlignBottom(50)
	bKeycardScanner_Add_Frame.ListcustomChecks:CenterHorizontal()
	bKeycardScanner_Add_Frame.ListcustomChecks:AddColumn("customCheck")
	bKeycardScanner_Add_Frame.ListcustomChecks:SetVisible(false)

	bKeycardScanner_Add_Frame.ListTeams = vgui.Create("bKeycardScanner_ListView",bKeycardScanner_Add_Frame)
	bKeycardScanner_Add_Frame.ListTeams:SetSize(325,290)
	bKeycardScanner_Add_Frame.ListTeams:AlignBottom(50)
	bKeycardScanner_Add_Frame.ListTeams:CenterHorizontal()
	bKeycardScanner_Add_Frame.ListTeams:AddColumn("Team")
	bKeycardScanner_Add_Frame.ListTeams:SetVisible(false)

	bKeycardScanner_Add_Frame.ListPlayers = vgui.Create("bKeycardScanner_ListView",bKeycardScanner_Add_Frame)
	bKeycardScanner_Add_Frame.ListPlayers:SetSize(325,290)
	bKeycardScanner_Add_Frame.ListPlayers:AlignBottom(50)
	bKeycardScanner_Add_Frame.ListPlayers:CenterHorizontal()
	bKeycardScanner_Add_Frame.ListPlayers:AddColumn("SteamID")
	bKeycardScanner_Add_Frame.ListPlayers:AddColumn("Name")
	bKeycardScanner_Add_Frame.ListPlayers:SetVisible(false)

	bKeycardScanner_Add_Frame.Text = vgui.Create("bKeycardScanner_DLabel",bKeycardScanner_Add_Frame)
	bKeycardScanner_Add_Frame.Text:SetText("")
	bKeycardScanner_Add_Frame.Text:SetFont("bkeycardscanner_16")

	bKeycardScanner_Add_Frame.TextLabel = vgui.Create("DTextEntry",bKeycardScanner_Add_Frame)
	bKeycardScanner_Add_Frame.TextLabel:SetSize(bKeycardScanner_Add_Frame:GetWide() - 20,25)
	bKeycardScanner_Add_Frame.TextLabel:CenterHorizontal()
	bKeycardScanner_Add_Frame.TextLabel:AlignTop(35 + 16 + 10)
	bKeycardScanner_Add_Frame.TextLabel:SetFont("bkeycardscanner_16")
	bKeycardScanner_Add_Frame.TextLabel.OnEnter = function()
		bKeycardScanner_Add_Frame.Done.DoClick()
	end

	bKeycardScanner_Add_Frame.Done = vgui.Create("bKeycardScanner_DButton",bKeycardScanner_Add_Frame)
	bKeycardScanner_Add_Frame.Done:SetText("Add")
	bKeycardScanner_Add_Frame.Done:SetSize(100,30)
	bKeycardScanner_Add_Frame.Done:AlignBottom(10)
	bKeycardScanner_Add_Frame.Done.BorderThickness = 2
	bKeycardScanner_Add_Frame.Done:CenterHorizontal()

	bKeycardScanner.Menu = vgui.Create("bKeycardScanner_DFrame")
	local m = bKeycardScanner.Menu
	m:MakePopup()
	m:SetSize(450,560)
	m:Center()
	m:SetTitle("bKeycardScanner")
	if (parent_child == 1) then
		m:SetTitle("This keycard scanner is sending data to another.")
	elseif (parent_child == 2) then
		m:SetTitle("This keycard scanner is receiving data from another.")
	end

	local lock = vgui.Create("bKeycardScanner_DButton",m)
	lock:SetSize(137.5,50)
	lock:AlignTop(35)
	lock:AlignRight(10)
	if (keycard_scanner:GetLockdown() == true) then
		lock:SetText("UNLOCK")
		lock:SetColors(Color(0,100,0),Color(0,60,0),false)
		lock:SetTooltip("Unlocks this keycard to allow the below users to access it.")
	else
		lock:SetText("LOCKDOWN")
		lock:SetColors(Color(255,75,75),Color(100,0,0),false)
		lock:SetTooltip("Locks this keycard to only you until you unlock it.")
	end
	function lock:DoClick()
		if (lock:GetText() == "LOCKDOWN") then
			lock:SetText("UNLOCK")
			lock:SetColors(Color(0,100,0),Color(0,60,0))
			lock:SetTooltip("Unlocks this keycard to allow the below users to access it.")
			bKeycardScanner:nets("lock")
				net.WriteEntity(keycard_scanner)
			net.SendToServer()
		else
			lock:SetText("LOCKDOWN")
			lock:SetColors(Color(255,75,75),Color(100,0,0))
			lock:SetTooltip("Locks this keycard to only you until you unlock it.")
			bKeycardScanner:nets("unlock")
				net.WriteEntity(keycard_scanner)
			net.SendToServer()
		end
	end

	local help = vgui.Create("bKeycardScanner_DButton",m)
	help:SetSize(137.5,50)
	help:AlignTop(35)
	help:CenterHorizontal()
	help:SetText("HELP")
	function help:DoClick()
		gui.OpenURL("https://gmodsto.re/bkeycardscanner-help")
	end

	local destroy = vgui.Create("bKeycardScanner_DButton",m)
	destroy:SetSize(137.5,50)
	destroy:AlignTop(35)
	destroy:AlignLeft(10)
	destroy:SetText("DESTROY")
	destroy:SetColors(Color(255,75,75),Color(100,0,0),false)
	destroy:SetTooltip("Destroys the keycard scanner.")
	function destroy:DoClick()
		if (keycard_scanner:GetPermanent()) then
			Derma_Message("This keycard scanner is permanent, you must make it unpermanent before you can destroy it.","Error","OK")
		else
			bKeycardScanner:nets("destroy")
				net.WriteEntity(keycard_scanner)
			net.SendToServer()
			m:Close()
		end
	end

	local link_keycard = vgui.Create("bKeycardScanner_DButton",m)
	link_keycard:SetSize(137.5,50)
	link_keycard:AlignTop(35 + 50 + 10)
	link_keycard:AlignLeft(10)
	link_keycard.on = function()
		link_keycard:SetText("UNMIRROR")
		link_keycard:SetColors(Color(0,225,225),Color(0,170,170),false)
		link_keycard:SetTooltip("This will unlink this keycard scanner from its linked scanner.")
		function link_keycard:DoClick()
			bKeycardScanner:nets("unmirror_scanner")
				net.WriteEntity(keycard_scanner)
			net.SendToServer()
			link_keycard.off()
		end
	end
	link_keycard.off = function()
		link_keycard:SetText("MIRROR TO")
		link_keycard:SetColors(Color(0,225,225),Color(0,170,170),false)
		link_keycard:SetTooltip("This allows you to link keycard scanners together. Linked keycard scanners will be exactly the same, they're just in different physical positions.")
		function link_keycard:DoClick()
			RunConsoleCommand("gmod_tool","bkeycardscanner")
			bKeycardScanner:chatprint("Press E on your keycard scanner to cancel. Press E on another keycard scanner to link.")
			m:Close()
			bKeycardScanner.LinkingFrom = keycard_scanner
		end
	end
	if (IsValid(keycard_scanner:GetMirrorChild()) or IsValid(keycard_scanner:GetMirrorParent())) then
		link_keycard.on()
	else
		link_keycard.off()
	end

	local link_to_map = vgui.Create("bKeycardScanner_DButton",m)
	link_to_map:SetSize(137.5,50)
	link_to_map:AlignTop(35 + 50 + 10)
	link_to_map:CenterHorizontal()
	link_to_map.on = function()
		link_to_map:SetText("UNLINK MAP")
		link_to_map:SetColors(Color(135,0,200),Color(90,0,135),false)
		link_to_map:SetTooltip("[Admin only] Unlinks the map object this keycard scanner is linked to.")
		function link_to_map:DoClick()
			if (bKeycardScanner:IsAdmin(LocalPlayer())) then
				if (#keycard_scanner:GetDoors() > 0) then
					bKeycardScanner:nets("unlink_door")
						net.WriteEntity(keycard_scanner)
					net.SendToServer()
				elseif (IsValid(keycard_scanner:GetButton())) then
					bKeycardScanner:nets("unlink_button")
						net.WriteEntity(keycard_scanner)
					net.SendToServer()
				end
				link_to_map.off()
			else
				Derma_Message("You don't have permission to do this.","bKeycardScanner Error","OK")
			end
		end
	end
	link_to_map.off = function()
		link_to_map:SetText("LINK TO MAP")
		link_to_map:SetColors(Color(135,0,200),Color(90,0,135),false)
		link_to_map:SetTooltip("[Admin only] This allows you to link this keycard scanner to a physical map object instead of a fading door, such as doors (including double doors) and buttons.")
		function link_to_map:DoClick()
			if (bKeycardScanner:IsAdmin(LocalPlayer())) then
				RunConsoleCommand("gmod_tool","bkeycardscanner")
				bKeycardScanner:chatprint("Press E on your keycard scanner to cancel. Press E on a door or map button to link. If linking to a button, make sure any associated doors are closed before linking.")
				m:Close()
				bKeycardScanner.DoorLinkingFrom = keycard_scanner
			else
				Derma_Message("You don't have permission to do this.","bKeycardScanner Error","OK")
			end
		end
	end
	if (#keycard_scanner:GetDoors() > 0 or IsValid(keycard_scanner:GetButton())) then
		link_to_map.on()
	else
		link_to_map.off()
	end

	local label_1 = vgui.Create("bKeycardScanner_DLabel",m) local label = label_1
	label:SetText("Access Granted Key")
	label:SetFont("bkeycardscanner_18")
	label:SizeToContents()
	label:AlignLeft(15)
	label:AlignTop(35 + 50 + 10 + 50 + 10)

	local access_granted_key = vgui.Create("bKeycardScanner_Binder",m)
	access_granted_key:SetSize(137.5,50)
	access_granted_key:AlignTop(35 + 50 + 10 + 20 + 10 + 50 + 10)
	access_granted_key:AlignLeft(10)
	access_granted_key:SetColors(Color(0,100,0),Color(0,60,0),false)
	access_granted_key:SetTooltip("Left click on the button and press a key to set the access granted key. Right click on the button to remove it. This is the key that will be automatically pressed when the keycard is scanned and authorized. Set the key to the same thing on your fading door.")
	access_granted_key:SetValue(keycard_scanner:GetAccessGrantedKey())
	function access_granted_key:SetSelectedNumber(num)
		self.m_iSelectedNumber = num
		bKeycardScanner:nets("changebind")
			if (IsValid(keycard_scanner:GetMirrorParent())) then
				net.WriteEntity(keycard_scanner:GetMirrorParent())
			else
				net.WriteEntity(keycard_scanner)
			end
			net.WriteString(tostring(num))
			net.WriteInt(0,3)
		net.SendToServer()
	end

	local label_2 = vgui.Create("bKeycardScanner_DLabel",m) local label = label_2
	label:SetText("Access Denied Key")
	label:SetFont("bkeycardscanner_18")
	label:SizeToContents()
	label:AlignTop(35 + 50 + 10 + 50 + 10)
	label:AlignRight(17)

	local access_denied_key = vgui.Create("bKeycardScanner_Binder",m)
	access_denied_key:SetSize(137.5,50)
	access_denied_key:AlignTop(35 + 50 + 10 + 20 + 10 + 50 + 10)
	access_denied_key:AlignRight(10)
	access_denied_key:SetColors(Color(255,75,75),Color(100,0,0))
	access_denied_key:SetTooltip("Click on the button and press a key to set the access dnied key. Right click on the button to remove it. This is the key that will be automatically pressed when the keycard is scanned and authorization failed.")
	access_denied_key:SetValue(keycard_scanner:GetAccessDeniedKey())
	function access_denied_key:SetSelectedNumber(num)
		self.m_iSelectedNumber = num
		bKeycardScanner:nets("changebind")
			net.WriteEntity(keycard_scanner)
			net.WriteString(tostring(num))
			net.WriteInt(1,3)
		net.SendToServer()
	end

	local label_3 = vgui.Create("bKeycardScanner_DLabel",m) local label = label_3
	label:SetText("Time")
	label:SetFont("bkeycardscanner_18")
	label:SizeToContents()
	label:AlignTop(35 + 50 + 10 + 50 + 10)
	label:CenterHorizontal()

	local time = vgui.Create("bKeycardScanner_Binder",m)
	time:SetSize(137.5,50)
	time:AlignTop(35 + 50 + 10 + 20 + 10 + 50 + 10)
	time:CenterHorizontal()
	time:SetColors(Color(255,75,75),Color(100,0,0))
	time:SetTooltip("This is the amount of time the key is pressed for. Left click to increase, right click to decrease. Set to 0 to leave a linked door open/closed forever (toggle)")
	time:SetText(keycard_scanner:GetTime())
	time.DoClick = function()
		time:SetText(math.Clamp(tonumber(time:GetText()) + 1,0,10))
		bKeycardScanner:nets("changebind")
			net.WriteEntity(keycard_scanner)
			net.WriteString(tostring(time:GetText()))
			net.WriteInt(2,3)
		net.SendToServer()
	end
	time.DoRightClick = function()
		time:SetText(math.Clamp(tonumber(time:GetText()) - 1,0,10))
		bKeycardScanner:nets("changebind")
			net.WriteEntity(keycard_scanner)
			net.WriteString(tostring(time:GetText()))
			net.WriteInt(2,3)
		net.SendToServer()
	end

	local label_4 = vgui.Create("bKeycardScanner_DLabel",m) local label = label_4
	label:SetContentAlignment(5)
	label:SetText("Fading doors are not permanent.")
	label:SetFont("bkeycardscanner_18")
	label:SizeToContents()
	label:AlignTop(35 + 50 + 10 + 20 + 10 + 50)
	label:CenterHorizontal()

	local label_5 = vgui.Create("bKeycardScanner_DLabel",m) local label = label_5
	label:SetContentAlignment(5)
	label:SetText("You must link this to a door or button instead.")
	label:SetFont("bkeycardscanner_18")
	label:SizeToContents()
	label:AlignTop(35 + 50 + 10 + 20 + 10 + 50 + 20)
	label:CenterHorizontal()

	local set_permanent = vgui.Create("bKeycardScanner_DButton",m)
	set_permanent:SetSize(137.5,50)
	set_permanent:AlignTop(35 + 50 + 10)
	set_permanent:AlignRight(10)
	set_permanent.on = function()
		lock:SetVisible(false)
		label_1:SetVisible(false)
		label_2:SetVisible(false)
		label_3:SetVisible(false)
		access_granted_key:SetVisible(false)
		access_denied_key:SetVisible(false)
		label_4:SetVisible(true)
		label_5:SetVisible(true)

		time:AlignTop(35)
		time:AlignRight(10)

		set_permanent:SetText("UNPERMANENT")
		set_permanent:SetColors(Color(255,75,0),Color(200,55,0),false)
		set_permanent:SetTooltip("[Admin only] Turns off permanent mode for this keycard scanner.")
		function set_permanent:DoClick()
			if (bKeycardScanner:IsAdmin(LocalPlayer())) then
				bKeycardScanner:nets("make_permanent")
					net.WriteBool(false)
					net.WriteEntity(keycard_scanner)
				net.SendToServer()
				set_permanent.off()
			else
				Derma_Message("You don't have permission to do this.","bKeycardScanner Error","OK")
			end
		end
	end
	set_permanent.off = function()
		lock:SetVisible(true)
		label_1:SetVisible(true)
		label_2:SetVisible(true)
		label_3:SetVisible(true)
		access_granted_key:SetVisible(true)
		access_denied_key:SetVisible(true)
		label_4:SetVisible(false)
		label_5:SetVisible(false)

		time:AlignTop(35 + 50 + 10 + 20 + 10 + 50 + 10)
		time:CenterHorizontal()

		set_permanent:SetText("SET PERMANENT")
		set_permanent:SetColors(Color(255,75,0),Color(200,55,0),false)
		set_permanent:SetTooltip("[Admin only] This allows you to make this keycard scanner permanent, so it will reappear on startup for this map.")
		function set_permanent:DoClick()
			if (bKeycardScanner:IsAdmin(LocalPlayer())) then
				bKeycardScanner:nets("make_permanent")
					net.WriteBool(true)
					net.WriteEntity(keycard_scanner)
				net.SendToServer()
				set_permanent.on()
			else
				Derma_Message("You don't have permission to do this.","bKeycardScanner Error","OK")
			end
		end
	end
	if (keycard_scanner:GetPermanent() == true) then
		set_permanent.on()
	else
		set_permanent.off()
	end

	local tip = vgui.Create("bKeycardScanner_DLabel",m)
	tip:SetText("Right click a line to deauthorize an entry.")
	tip:SizeToContents()
	tip:CenterHorizontal()
	tip:AlignBottom(65)

	local list = vgui.Create("bKeycardScanner_ListView",m)
	list:SetSize(428,220)
	list:AlignBottom(90)
	list:CenterHorizontal()
	list:AddColumn("Type")
	list:AddColumn("Authorized")
	list:AddColumn("Name")
	list.OnRowRightClick = function(_,__,line)
		bKeycardScanner:nets("deauthorize")
			net.WriteEntity(keycard_scanner)
			net.WriteInt(({Player = 1,Team = 2,Usergroup = 3,customCheck = 4})[line:GetValue(1)],4)
			net.WriteString(line:GetValue(2))
		net.SendToServer()
		for i,v in pairs(list:GetLines()) do
			if (v == line) then
				list:RemoveLine(i)
				break
			end
		end
		if (#list:GetLines() == 0) then
			list:AddLine("No data!")
		end
	end
	bKeycardScanner:netr("data",function()
		if (not IsValid(list)) then
			bKeycardScanner:nets("stop_data_flow")
			net.SendToServer()
			return
		end
		local type = net.ReadInt(4)
		local value = net.ReadString()
		local name = net.ReadString()
		if (type == 1) then
			if (name == "") then
				list:AddLine("Player",value,"Unknown")
			else
				list:AddLine("Player",value,name)
			end
		elseif (type == 2) then
			list:AddLine("Team",value,"")
		elseif (type == 3) then
			list:AddLine("Usergroup",value,"")
		elseif (type == 4) then
			list:AddLine("customCheck",value,"")
		end
	end)
	bKeycardScanner:netr("no_data",function()
		if (not IsValid(list)) then return end
		list:AddLine("No data!")
	end)
	bKeycardScanner:nets("start_data_flow")
		net.WriteEntity(keycard_scanner)
	net.SendToServer()

	local add_player = vgui.Create("bKeycardScanner_DButton",m)
	add_player:SetSize(107.5,45)
	add_player:SetText("PLAYER")
	add_player:AlignBottom(10)
	add_player:AlignLeft(10)
	add_player:SetTooltip("Authorize a player to the keycard. This will be done by picking from a list you will be presented with.")
	add_player.DoClick = function()
		bKeycardScanner_Add_Frame:SetTitle("Add player")
		bKeycardScanner_Add_Frame:SetTall(400)
		bKeycardScanner_Add_Frame:Center()
		bKeycardScanner_Add_Frame:SetVisible(true)
		bKeycardScanner_Add_Frame:MakePopup()

		bKeycardScanner_Add_Frame.Text:SetText("Select player(s) below.")
		bKeycardScanner_Add_Frame.Text:SizeToContents()
		bKeycardScanner_Add_Frame.Text:CenterHorizontal()
		bKeycardScanner_Add_Frame.Text:AlignTop(35)

		bKeycardScanner_Add_Frame.TextLabel:SetVisible(false)

		bKeycardScanner_Add_Frame.Done:AlignBottom(10)
		bKeycardScanner_Add_Frame.ListTeams:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListPlayers:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListcustomChecks:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListTeams:SetVisible(false)
		bKeycardScanner_Add_Frame.ListPlayers:SetVisible(true)
		bKeycardScanner_Add_Frame.ListcustomChecks:SetVisible(false)

		bKeycardScanner_Add_Frame.ListPlayers:SetMultiSelect(false)
		bKeycardScanner_Add_Frame.Done:SetText("Add")

		bKeycardScanner_Add_Frame.ListPlayers:Clear()
		for _,v in pairs(player.GetHumans()) do
			if (v == LocalPlayer() and not keycard_scanner:GetPermanent()) then continue end
			local f = false
			for _,x in pairs(list:GetLines()) do
				if (x:GetValue(1) == "Player" and x:GetValue(2) == v:SteamID()) then
					f = true
					break
				end
			end
			if (not f) then
				bKeycardScanner_Add_Frame.ListPlayers:AddLine(v:SteamID(),v:Nick())
			end
		end

		bKeycardScanner_Add_Frame.Done.DoClick = function()
			if (#bKeycardScanner_Add_Frame.ListPlayers:GetSelected() == 0) then
				return
			end

			for _,v in pairs(bKeycardScanner_Add_Frame.ListPlayers:GetSelected()) do
				if (IsValid(player.GetBySteamID(v:GetValue(1)))) then
					bKeycardScanner:nets("authorize")
						net.WriteEntity(keycard_scanner)
						net.WriteInt(1,4)
						net.WriteString(v:GetValue(1))
					net.SendToServer()
					if (list:GetLine(1):GetValue(1) == "No data!") then
						list:RemoveLine(1)
					end
					list:AddLine("Player",v:GetValue(1),v:GetValue(2))
				end
			end

			bKeycardScanner_Add_Frame.TextLabel:SetText("")
			bKeycardScanner_Add_Frame:SetVisible(false)
		end
	end

	local add_team = vgui.Create("bKeycardScanner_DButton",m)
	add_team:SetSize(107.5,45)
	add_team:SetText("TEAM")
	add_team:AlignBottom(10)
	add_team:AlignLeft(10 + 107.5)
	add_team:SetTooltip("Authorize a team (job) to the keycard. This will be done by picking from a list you will be presented with.")
	add_team.DoClick = function()
		bKeycardScanner_Add_Frame:SetTitle("Add team")
		bKeycardScanner_Add_Frame:SetTall(400)
		bKeycardScanner_Add_Frame:Center()
		bKeycardScanner_Add_Frame:SetVisible(true)
		bKeycardScanner_Add_Frame:MakePopup()

		bKeycardScanner_Add_Frame.Text:SetText("Select team(s) below.")
		bKeycardScanner_Add_Frame.Text:SizeToContents()
		bKeycardScanner_Add_Frame.Text:CenterHorizontal()
		bKeycardScanner_Add_Frame.Text:AlignTop(35)

		bKeycardScanner_Add_Frame.TextLabel:SetVisible(false)

		bKeycardScanner_Add_Frame.Done:AlignBottom(10)
		bKeycardScanner_Add_Frame.ListTeams:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListPlayers:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListcustomChecks:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListTeams:SetVisible(true)
		bKeycardScanner_Add_Frame.ListPlayers:SetVisible(false)
		bKeycardScanner_Add_Frame.ListcustomChecks:SetVisible(false)

		bKeycardScanner_Add_Frame.Done:SetText("Add")

		bKeycardScanner_Add_Frame.ListTeams:Clear()
		for _,v in pairs(RPExtraTeams) do
			local f = false
			for _,x in pairs(list:GetLines()) do
				if (x:GetValue(1) == "Team" and x:GetValue(2) == v.name) then
					f = true
					break
				end
			end
			if (not f) then
				bKeycardScanner_Add_Frame.ListTeams:AddLine(v.name)
			end
		end

		bKeycardScanner_Add_Frame.Done.DoClick = function()
			if (#bKeycardScanner_Add_Frame.ListTeams:GetSelected() == 0) then
				return
			end

			for _,v in pairs(bKeycardScanner_Add_Frame.ListTeams:GetSelected()) do
				bKeycardScanner:nets("authorize")
					net.WriteEntity(keycard_scanner)
					net.WriteInt(2,4)
					net.WriteString(v:GetValue(1))
				net.SendToServer()
				if (list:GetLine(1):GetValue(1) == "No data!") then
					list:RemoveLine(1)
				end
				list:AddLine("Team",v:GetValue(1),"")
			end

			bKeycardScanner_Add_Frame.TextLabel:SetText("")
			bKeycardScanner_Add_Frame:SetVisible(false)
		end
	end

	local add_usergroup = vgui.Create("bKeycardScanner_DButton",m)
	add_usergroup:SetSize(109,45)
	add_usergroup:SetText("USERGROUP")
	add_usergroup:AlignBottom(10)
	add_usergroup:AlignLeft(10 + 107.5 + 107)
	add_usergroup:SetTooltip("Authorize a usergroup (rank) to the keycard.")
	add_usergroup.DoClick = function()
		bKeycardScanner_Add_Frame:SetTitle("Add usergroup")
		bKeycardScanner_Add_Frame:SetTall(135)
		bKeycardScanner_Add_Frame:Center()
		bKeycardScanner_Add_Frame:SetVisible(true)
		bKeycardScanner_Add_Frame:MakePopup()

		bKeycardScanner_Add_Frame.Text:SetText("Enter a usergroup below.")
		bKeycardScanner_Add_Frame.Text:SizeToContents()
		bKeycardScanner_Add_Frame.Text:CenterHorizontal()
		bKeycardScanner_Add_Frame.Text:AlignTop(35)

		bKeycardScanner_Add_Frame.TextLabel:SetVisible(true)
		bKeycardScanner_Add_Frame.TextLabel:RequestFocus()

		bKeycardScanner_Add_Frame.Done:AlignBottom(10)
		bKeycardScanner_Add_Frame.ListTeams:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListPlayers:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListcustomChecks:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListTeams:SetVisible(false)
		bKeycardScanner_Add_Frame.ListPlayers:SetVisible(false)
		bKeycardScanner_Add_Frame.ListcustomChecks:SetVisible(false)

		bKeycardScanner_Add_Frame.Done:SetText("Add")

		bKeycardScanner_Add_Frame.Done.DoClick = function()
			if (string.Trim(bKeycardScanner_Add_Frame.TextLabel:GetText()) == "") then
				return
			end

			bKeycardScanner:nets("authorize")
				net.WriteEntity(keycard_scanner)
				net.WriteInt(3,4)
				net.WriteString(bKeycardScanner_Add_Frame.TextLabel:GetText())
			net.SendToServer()
			if (list:GetLine(1):GetValue(1) == "No data!") then
				list:RemoveLine(1)
			end
			list:AddLine("Usergroup",bKeycardScanner_Add_Frame.TextLabel:GetText(),"")

			bKeycardScanner_Add_Frame.TextLabel:SetText("")
			bKeycardScanner_Add_Frame:SetVisible(false)
		end
	end

	local customcheck = vgui.Create("bKeycardScanner_DButton",m)
	customcheck:SetSize(107.5,45)
	customcheck:SetText("CUSTOM")
	customcheck:AlignBottom(10)
	customcheck:AlignRight(10)
	customcheck:SetTooltip("Authorize a server defined customCheck to this keycard scanner.")
	customcheck.DoClick = function()
		bKeycardScanner_Add_Frame:SetTitle("Add customCheck")
		bKeycardScanner_Add_Frame:SetTall(400)
		bKeycardScanner_Add_Frame:Center()
		bKeycardScanner_Add_Frame:SetVisible(true)
		bKeycardScanner_Add_Frame:MakePopup()

		bKeycardScanner_Add_Frame.Text:SetText("Select customCheck(s) below.")
		bKeycardScanner_Add_Frame.Text:SizeToContents()
		bKeycardScanner_Add_Frame.Text:CenterHorizontal()
		bKeycardScanner_Add_Frame.Text:AlignTop(35)

		bKeycardScanner_Add_Frame.TextLabel:SetVisible(false)

		bKeycardScanner_Add_Frame.Done:AlignBottom(10)
		bKeycardScanner_Add_Frame.ListTeams:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListPlayers:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListcustomChecks:AlignBottom(50)
		bKeycardScanner_Add_Frame.ListTeams:SetVisible(false)
		bKeycardScanner_Add_Frame.ListPlayers:SetVisible(false)
		bKeycardScanner_Add_Frame.ListcustomChecks:SetVisible(true)

		bKeycardScanner_Add_Frame.Done:SetText("Add")

		bKeycardScanner_Add_Frame.ListcustomChecks:Clear()
		for name in pairs(bKeycardScanner.Config.customChecks) do
			bKeycardScanner_Add_Frame.ListcustomChecks:AddLine(name)
		end

		bKeycardScanner_Add_Frame.Done.DoClick = function()
			if (#bKeycardScanner_Add_Frame.ListcustomChecks:GetSelected() == 0) then
				return
			end

			for _,v in pairs(bKeycardScanner_Add_Frame.ListcustomChecks:GetSelected()) do
				bKeycardScanner:nets("authorize")
					net.WriteEntity(keycard_scanner)
					net.WriteInt(4,4)
					net.WriteString(v:GetValue(1))
				net.SendToServer()
				if (list:GetLine(1):GetValue(1) == "No data!") then
					list:RemoveLine(1)
				end
				list:AddLine("customCheck",v:GetValue(1),"")
			end

			bKeycardScanner_Add_Frame.TextLabel:SetText("")
			bKeycardScanner_Add_Frame:SetVisible(false)
		end
	end

end
bKeycardScanner:netr("openmenu",openmenu)

bKeycardScanner:netr("tip",function()
	bKeycardScanner:chatprint(bKeycardScanner:t("tip"))
end)
bKeycardScanner:netr("distance_tip",function()
	bKeycardScanner:chatprint(bKeycardScanner:t("distance_tip"),"bad")
end)

bKeycardScanner:netr("identification",function()
	local ply      = net.ReadEntity()
	local t_name   = team.GetName(ply:Team())
	local t_color  = team.GetColor(ply:Team())
	local override = hook.Run("bkeycardscanner_get_presentation_message",ply)
	if (not override) then
		local msg = {}
		local msg_str_i = 1
		local white_needed = true
		local s = bKeycardScanner.Config.ShowIDString
		local i = 0
		while (i < #s) do
			i = i + 1
			local v = s[i]
			if (v == "%" and s[i + 1] == "n" and s[i + 2] == "a" and s[i + 3] == "m" and s[i + 4] == "e" and s[i + 5] == "%") then
				msg[#msg + 1] = t_color
				msg[#msg + 1] = ply:Nick()
				msg_str_i = msg_str_i + 1
				i = i + 5
				white_needed = true
			elseif (v == "%" and s[i + 1] == "t" and s[i + 2] == "e" and s[i + 3] == "a" and s[i + 4] == "m" and s[i + 5] == "%") then
				msg[#msg + 1] = t_color
				msg[#msg + 1] = t_name
				msg_str_i = msg_str_i + 1
				i = i + 5
				white_needed = true
			else
				if (white_needed) then
					msg[#msg + 1] = Color(255,255,255)
					msg_str_i = msg_str_i + 1
					white_needed = false
				end
				while (msg[msg_str_i] ~= nil and type(msg[msg_str_i]) ~= "string") do
					msg_str_i = msg_str_i + 1
				end
				if (not msg[msg_str_i]) then
					msg[msg_str_i] = ""
				end
				msg[msg_str_i] = msg[msg_str_i] .. v
			end
		end
		chat.AddText(unpack(msg))
	else
		chat.AddText(unpack(override))
	end
end)

bKeycardScanner:hook("PlayerBindPress","link_to_map_use",function(_,bind,pressed)
	if (IsValid(bKeycardScanner.DoorLinkingFrom) and bind == "+use" and pressed == true) then
		local tr = LocalPlayer():GetEyeTrace()
		if (IsValid(tr.Entity)) then
			if (
				not tr.Entity:IsWorld() and (
					tr.Entity:GetClass() == "func_door" or
					tr.Entity:GetClass() == "func_door_rotating" or
					tr.Entity:GetClass() == "prop_door_rotating" or
					tr.Entity:GetClass() == "func_movelinear" or
					tr.Entity:GetClass() == "prop_dynamic"
				)
			) then
				bKeycardScanner:nets("link_door")
					net.WriteEntity(bKeycardScanner.DoorLinkingFrom)
					net.WriteEntity(tr.Entity)
					net.WriteBool(false)
				net.SendToServer()
				bKeycardScanner.DoorLinkingFrom = nil
				surface.PlaySound("garrysmod/content_downloaded.wav")
				bKeycardScanner:chatprint("Linked!","good")
				return true
			elseif (
				not tr.Entity:IsWorld() and
				tr.Entity:GetNWBool("func_button") == true
			) then
				local function continue_link(disable_btn)
					bKeycardScanner:nets("link_button")
						net.WriteEntity(bKeycardScanner.DoorLinkingFrom)
						net.WriteEntity(tr.Entity)
						net.WriteBool(disable_btn)
					net.SendToServer()
					bKeycardScanner.DoorLinkingFrom = nil
					surface.PlaySound("garrysmod/content_downloaded.wav")
					bKeycardScanner:chatprint("Linked!","good")
				end
				Derma_Query(
					"Would you like to disable this button from being pressed as well?","Disable Button",
					"Yes",function()
						continue_link(true)
					end,
					"No",function()
						continue_link(false)
					end
				)
				return true
			end
		end
	end
end)

bKeycardScanner:hook("PhysgunPickup","update_keycard_scanner_tbl",function(ply,ent)
	if (not IsValid(ent)) then return end
	if (ent:IsWorld()) then return end
	if (ent:GetClass() ~= "bkeycardscanner") then return end
	if (not ent:GetPermanent()) then return end
	return false
end)

bKeycardScanner:hook("PreDrawHalos","DrawHalos",function()
	local linked_doors = {}
	local mirrored_scanners = {}
	if (IsValid(LocalPlayer():GetActiveWeapon()) and LocalPlayer():GetActiveWeapon():GetClass() == "gmod_tool" and GetConVar("gmod_toolmode"):GetString() == "bkeycardscanner") then
		local tr = LocalPlayer():GetEyeTrace()
		if (IsValid(tr.Entity) and not tr.Entity:IsWorld()) then
			if (tr.Entity:GetClass() == "bkeycardscanner") then
				if (bKeycardScanner:HasAdminESP(LocalPlayer()) or bKeycardScanner:IsOwnerOf(tr.Entity,LocalPlayer())) then
					if (IsValid(tr.Entity:GetMirrorParent()) or IsValid(tr.Entity:GetMirrorChild())) then
						table.insert(mirrored_scanners,tr.Entity)
						table.Add(mirrored_scanners,tr.Entity:GetAllMirrors())
					elseif (IsValid(bKeycardScanner.LinkingFrom) and bKeycardScanner.LinkingFrom ~= tr.Entity) then
						table.insert(mirrored_scanners,bKeycardScanner.LinkingFrom)
						table.insert(mirrored_scanners,tr.Entity)
					end
					local doors = tr.Entity:GetDoors()
					if (#doors > 0) then
						if (not table.HasValue(mirrored_scanners,tr.Entity)) then
							table.insert(linked_doors,tr.Entity)
						end
						table.Add(linked_doors,doors)
					end
					if (tr.Entity:GetButton()) then
						table.insert(linked_doors,tr.Entity:GetButton())
					end
				end
			elseif (
				tr.Entity:GetClass() == "func_door" or
				tr.Entity:GetClass() == "func_door_rotating" or
				tr.Entity:GetClass() == "prop_door_rotating" or
				tr.Entity:GetClass() == "func_movelinear" or
				tr.Entity:GetClass() == "prop_dynamic"
			) then
				if (IsValid(bKeycardScanner.DoorLinkingFrom)) then
					table.insert(linked_doors,bKeycardScanner.DoorLinkingFrom)
					table.insert(linked_doors,tr.Entity)
				elseif (tr.Entity:GetNWInt("b_bKeycardScannerEntIndex") ~= 0) then
					if (bKeycardScanner:HasAdminESP(LocalPlayer()) or bKeycardScanner:IsOwnerOf(Entity(tr.Entity:GetNWInt("b_bKeycardScannerEntIndex")),LocalPlayer())) then
						table.insert(linked_doors,Entity(tr.Entity:GetNWInt("b_bKeycardScannerEntIndex")))
						table.insert(linked_doors,tr.Entity)
						if (tr.Entity:GetNWString("b_MappedName") ~= "") then
							for _,v in pairs(ents.GetAll()) do
								if (v ~= tr.Entity and v:GetNWString("b_MappedName") == tr.Entity:GetNWString("b_MappedName")) then
									table.insert(linked_doors,v)
								end
							end
						end
					end
				end
			elseif (tr.Entity:GetNWBool("func_button") == true) then
				table.insert(linked_doors,bKeycardScanner.DoorLinkingFrom)
				table.insert(linked_doors,tr.Entity)
			end
		end
	end
	if (#linked_doors > 0) then
		halo.Add(linked_doors,Color(135,0,200),1,1,10,true,true)
	end
	if (#mirrored_scanners > 0) then
		halo.Add(mirrored_scanners,Color(0,225,225),1,1,10,true,true)
	end
end)

bKeycardScanner:print("Clientside loaded","good")
