MsgC("\n\n")
for i,v in pairs(string.ToTable(string.rep("#",59))) do
	MsgC(Color(i * 4.32203389831,255,0),v)
end
MsgC("\n\n")
for i,v in pairs({"  ____  _  __                            _ "," |  _ \\| |/ /                           | |"," | |_) | ' / ___ _   _  ___ __ _ _ __ __| |"," |  _ <|  < / _ \\ | | |/ __/ _` | '__/ _` |"," | |_) | . \\  __/ |_| | (_| (_| | | | (_| |"," |____/|_|\\_\\___|\\__, |\\___\\__,_|_|  \\__,_|","                  __/ |                    ","                 |___/                     "}) do
	MsgC(string.rep(" ",5))
	for i,_v in pairs(string.ToTable(v)) do
		MsgC(Color(i * 8.5,255,0),_v)
	end
	MsgC("\n")
end
MsgC("\n" .. string.rep(" ",13))
local spaces = ""
for i=1,math.floor(15 - (#bKeycardScanner.Version / 2)),1 do
	spaces = spaces .. " "
end
for i,v in pairs(string.ToTable(spaces .. bKeycardScanner.Version)) do
	MsgC(Color(i * 8.5,255,0),v)
end
MsgC("\n\n" .. string.rep(" ",13))
local spaces = ""
for i=1,math.floor(15 - (#("Licensed to " .. bKeycardScanner.Licensee) / 2)),1 do
	spaces = spaces .. " "
end
for i,v in pairs(string.ToTable(spaces .. "Licensed to " .. bKeycardScanner.Licensee)) do
	MsgC(Color(i * 8.5,255,0),v)
end
MsgC("\n\n\n")
for i,v in pairs(string.ToTable(string.rep("#",59))) do
	MsgC(Color(i * 4.32203389831,255,0),v)
end
MsgC("\n\n")

bKeycardScanner.EnglishLanguage = {
	tip = "Please insert your keycard.",
	distance_tip = "You were too far away from the keycard scanner.",
}

if (CLIENT) then
	if (not file.Exists("bkeycardscanner_language.txt","DATA")) then
		file.Write("bkeycardscanner_language.txt","English")
	end
	bKeycardScanner.SelectedLanguage = file.Read("bkeycardscanner_language.txt","DATA")
	bKeycardScanner.SelectedLanguage = bKeycardScanner.SelectedLanguage:sub(1,1):upper() .. bKeycardScanner.SelectedLanguage:sub(2)
	if (bKeycardScanner.SelectedLanguage ~= "English") then
		if (not file.Exists("bkeycardscanner/lang/" .. bKeycardScanner.SelectedLanguage .. ".lua","DATA")) then
			bKeycardScanner.SelectedLanguage = "English"
		else
			include("bkeycardscanner/lang/" .. bKeycardScanner.SelectedLanguage .. ".lua")
		end
	else
		bKeycardScanner.Language = nil
	end
end

if (file.Exists("bkeycardscanner_version.dat","DATA")) then

	local version_changes = {

	}

	if (version_changes[file.Read("bkeycardscanner_version.dat","DATA")]) then
		version_changes[file.Read("bkeycardscanner_version.dat","DATA")]()
		file.Write("bkeycardscanner_version.dat",bKeycardScanner.Version)
	end

end

require("billyerror")

function bKeycardScanner:print(msg,type)
	if (type == "error" or type == "bad") then
		MsgC(Color(255,0,0),"[bKeycardScanner] ",Color(255,255,255),msg .. "\n")
	elseif (type == "success" or type == "good") then
		MsgC(Color(0,255,0),"[bKeycardScanner] ",Color(255,255,255),msg .. "\n")
	else
		MsgC(Color(0,255,255),"[bKeycardScanner] ",Color(255,255,255),msg .. "\n")
	end
end
bKeycardScanner:print("Loading bKeycardScanner...")

function bKeycardScanner:hook(h,i,f)
	hook.Remove(h,"bkeycardscanner_" .. i)
	hook.Add(h,"bkeycardscanner_" .. i,f)
end
function bKeycardScanner:unhook(h,i)
	hook.Remove(h,"bkeycardscanner_" .. i)
end

function bKeycardScanner:nets(m)
	net.Start("bkeycardscanner_" .. m)
end
function bKeycardScanner:netr(m,f)
	if (SERVER) then
		net.Receive("bkeycardscanner_" .. m,function(l,p)
			f(p)
		end)
	else
		net.Receive("bkeycardscanner_" .. m,f)
	end
end

function bKeycardScanner:timer(i,d,r,f)
	timer.Create("bkeycardscanner_" .. i,d,r,f)
end
function bKeycardScanner:untimer(i)
	timer.Remove("bkeycardscanner_" .. i)
end

include("bkeycardscanner_config.lua")
if (not bKeycardScanner.Config) then
	BillyError("bKeycardScanner","There's a syntax error with your bKeycardScanner config. Please check your SERVER console for more information. We remind you that your config errors are not the developers' problem and you must fix them yourself.")
	include("bkeycardscanner/default_config.lua")
end

--[[if (bKeycardScanner.Config.DefaultLanguage ~= "English") then
	if (file.Exists("bkeycardscanner/lang/" .. bKeycardScanner.Config.DefaultLanguage .. ".lua","LUA")) then
		include("lang/" .. bKeycardScanner.Config.DefaultLanguage .. ".lua")
	else
		if (CLIENT) then BillyError("bKeycardScanner","That language does not exist. Please fix config.DefaultLanguage in your bKeycardScanner Config.") end
		bKeycardScanner.Config.DefaultLanguage = "English"
	end
end--]] bKeycardScanner.Config.DefaultLanguage = "English"

function bKeycardScanner:t(p)
	if (bKeycardScanner.Language) then
		if (bKeycardScanner.Language[p]) then
			return bKeycardScanner.Language[p]
		end
	end
	return bKeycardScanner.EnglishLanguage[p]
end

function bKeycardScanner:IsAdmin(ply)
	for _,v in pairs(bKeycardScanner.Config.Admins) do
		if (
			ply:GetUserGroup() == v  or
			ply:SteamID()      == v  or
			ply:SteamID64()    == v
		) then
			return true
		end
	end
	return false
end

function bKeycardScanner:HasAdminESP(ply)
	for _,v in pairs(bKeycardScanner.Config.KeycardScannerESP) do
		if (
			ply:GetUserGroup() == v  or
			ply:SteamID()      == v  or
			ply:SteamID64()    == v
		) then
			return true
		end
	end
	return false
end

function bKeycardScanner:IsOwnerOf(keycard_scanner,ply)
	if (IsValid(keycard_scanner)) then
		if (keycard_scanner:GetClass() == "bkeycardscanner") then
			if (CLIENT and keycard_scanner:GetClientCreator() == ply) then
				return true
			elseif (keycard_scanner:GetPermanent()) then
				if (bKeycardScanner:IsAdmin(ply)) then
					return true
				end
			elseif (SERVER and keycard_scanner:GetCreator() == ply) then
				return true
			end
		end
	end
	return false
end

function bKeycardScanner:IsDoorOpen(door)
	if (door:GetClass() == "func_door" or door:GetClass() == "func_door_rotating") then
		return (door:GetSaveTable().m_toggle_state == 0)
	elseif (door:GetClass() == "prop_door_rotating") then
		return (door:GetSaveTable().m_eDoorState ~= 0)
	end
end

if (SERVER) then
	bKeycardScanner:hook("PlayerInitialSpawn","load",function()
		timer.Simple(0,function()
			if (file.Exists("bkeycardscanner/sv.lua","LUA")) then
				include("bkeycardscanner/sv.lua")
			else
				include("bkeycardscanner/ext.lua")
			end
		end)
	end)
else
	include("bkeycardscanner/cl.lua")
end