AddCSLuaFile()

SWEP.Base = "bkeycardscanner_cracker_base"

if CLIENT then
	SWEP.Category = "bKeycardScanner"
	SWEP.PrintName = "Pro Keycard Scanner Cracker"
	SWEP.Slot = 4
	SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = true
end

SWEP.Author = "Willox"
SWEP.Instructions = "Left click to crack a keycard scanner"
SWEP.Contact = ""
SWEP.Purpose = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.ViewModel = Model("models/weapons/v_c4.mdl")
SWEP.WorldModel = Model("models/weapons/w_c4.mdl")

SWEP.AnimPrefix = "python"

SWEP.Sound = Sound("weapons/deagle/deagle-1.wav")

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

SWEP.KeyCrackSound = Sound("buttons/blip2.wav")

SWEP.IdleStance = "slam"

SWEP.Spawnable = true
SWEP.AdminOnly = true

function SWEP:GetCrackTime()
	return bKeycardScanner.Config.ProCrackTime
end