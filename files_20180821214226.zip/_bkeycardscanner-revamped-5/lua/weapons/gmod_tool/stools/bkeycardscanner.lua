if (SERVER) then
	CreateConVar("sbox_maxbkeycardscanners",10)
end

TOOL.Category = "Construction"
TOOL.Name = "Keycard Scanner"
TOOL.Command = nil

cleanup.Register("bKeycardScanners")

if (CLIENT) then
	language.Add("tool.bkeycardscanner.name","bKeycardScanner")
	language.Add("tool.bkeycardscanner.0","Left click to spawn the keycard scanner on the wall/floor you're pointing at. Press E on the keycard scanner to edit its settings.")
	language.Add("tool.bkeycardscanner.desc","")
	language.Add("Undone_bKeycardScanner","Undone bKeycardScanner")
	language.Add("Cleanup_bKeycardScanners","bKeycardScanners")
	language.Add("Cleaned_bKeycardScanners","Cleaned up all bKeycardScanners")
	language.Add("SBoxLimit_bKeycardScanners","You've hit the bKeycardScanner limit!")
end

function TOOL:LeftClick(tr)
	if (IsValid(tr) and tr.Entity:GetClass():lower() == "player") then
		return false
	end
	if (CLIENT) then return true end
	if (not self:GetWeapon():CheckLimit("bkeycardscanners")) then return false end

	if (SERVER) then

		local ply = self:GetOwner()

		local spawn_pos = tr.HitPos + tr.HitNormal
		local trace_ent = tr.Entity

		local ent = ents.Create("bkeycardscanner")
		ent:SetCreator(ply)
		ent:SetPos(spawn_pos)
		ent:SetAngles(tr.HitNormal:Angle() + Angle(90,0,0))
		ent:Spawn()

		undo.Create("bKeycardScanner")
			undo.AddEntity(ent)
			undo.SetPlayer(ply)
			undo.AddFunction(function(data)
				for _,v in pairs(data.Entities) do
					bKeycardScanner:DestroyKeycardScanner(v,true)
				end
			end)
		undo.Finish()

		ply:AddCount("bkeycardscanners",ent)
		ply:AddCleanup("bkeycardscanners",ent)

		hook.Run("keycardscanner_created",ent)

	end

	return true
end

function TOOL:Reload()
	return false
end

function TOOL:RightClick(tr)
	return false
end

if (CLIENT) then
	function TOOL:Deploy()
		self.IsAdminTool = (
			table.HasValue(bKeycardScanner.Config.KeycardScannerESP,LocalPlayer():SteamID()) or
			table.HasValue(bKeycardScanner.Config.KeycardScannerESP,LocalPlayer():SteamID64()) or
			table.HasValue(bKeycardScanner.Config.KeycardScannerESP,LocalPlayer():GetUserGroup())
		)
	end
end

if (CLIENT) then
	function TOOL.BuildCPanel(cp)
		cp:Help("Billy's Keycard Scanner\n\nLeft click to spawn the keycard scanner on the wall/floor you're pointing at. Press E on the keycard scanner to edit its settings.")
	end
end
