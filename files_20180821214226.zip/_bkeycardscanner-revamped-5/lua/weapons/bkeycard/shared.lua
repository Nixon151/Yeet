AddCSLuaFile()

if (CLIENT) then
	SWEP.Category = "bKeycardScanner"
	SWEP.PrintName = "Keycard"
	SWEP.Slot = 0
	SWEP.SlotPos = 0
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
	SWEP.WepSelectIcon = surface.GetTextureID("weapons/bkeycard")
end

SWEP.UseHands = true

SWEP.Spawnable = true
SWEP.AdminOnly = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

SWEP.HoldType = "pistol"
SWEP.ViewModelFOV = 70
SWEP.ViewModelFlip = false
SWEP.UseHands = true
SWEP.ViewModel = "models/bkeycardscanner/c_keycard.mdl"
SWEP.WorldModel = "models/bkeycardscanner/w_keycard.mdl"
SWEP.ShowViewModel = true
SWEP.ShowWorldModel = true

SWEP.WElements = {
	["keycard"] = { type = "Model", model = "models/bkeycardscanner/w_keycard.mdl", bone = "ValveBiped.Bip01_R_Hand", rel = "", pos = Vector(5.5, 1.557, -1.3), angle = Angle(19.87, 177.143, -6), size = Vector(0.699, 0.699, 0.699), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}

function SWEP:ShouldDropOnDie() return false end
function SWEP:Reload() return true end
function SWEP:PrintWeaponInfo() end

local function table_FullCopy(tab)
	if (not tab) then return nil end
	local res = {}
	for k, v in pairs( tab ) do
		if (type(v) == "table") then
			res[k] = table_FullCopy(v)
		elseif (type(v) == "Vector") then
			res[k] = Vector(v.x, v.y, v.z)
		elseif (type(v) == "Angle") then
			res[k] = Angle(v.p, v.y, v.r)
		else
			res[k] = v
		end
	end
	return res
end

if (CLIENT) then
	function SWEP:DynamicKeycard(name,color)
		self.PrintName = name
	end
end

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)
	if (CLIENT) then
		self.WElements = table_FullCopy(self.WElements)
		self:CreateModels(self.WElements)
	end
end

function SWEP:Holster()
	hook.Remove("Think","bkeycard_dmodelpanel")
	if (IsValid(bKeycardScanner_ModelPanel)) then
		bKeycardScanner_ModelPanel:Remove()
	end
    return true
end

function SWEP:SecondaryAttack()
	if (SERVER) then
		bKeycardScanner:ShowID(self:GetOwner())
	end
	self:SetNextSecondaryFire(CurTime()+3)
end

function SWEP:PrimaryAttack()
	if (not IsFirstTimePredicted()) then return end
	local ply = self:GetOwner()
	local ent = ply:GetEyeTrace().Entity
	if (IsValid(ent) and not ent:IsWorld() and ent:GetClass() == "bkeycardscanner") then
		if (not ent:GetWaiting()) then
			if (ent:GetPos():Distance(ply:GetPos()) < bKeycardScanner.Config.ScanDistance) then
				if (SERVER) then
					if (bKeycardScanner.Config.TakeKeycard) then
						ply:StripWeapon("bkeycard")
					end
					local scanid = ent:GetScanToken()
					if (bKeycardScanner.Config.ScanTime > 0) then
						ent:SetScanningPly(ply)
						ent:SetText("SCANNING")
						ent:SetScanning(true)
						ent:SetWaiting(true)
						ent:EmitSound("buttons/button15.wav",SNDLVL_45dB)
						ent:ShowKeycard(true)
						ent:SetLights(false,false,true)
					end
					local function success()
						if (IsValid(ent)) then
							if (not ent:VerifyScan(scanid)) then return end
							if (not ply:HasWeapon("bkeycard") and bKeycardScanner.Config.TakeKeycard) then
								ply:Give("bkeycard")
							end
							ent:AccessGranted()
						end
					end
					if (ent:GetCreator() == ply or (not ent:GetLockdown() and ent:IsAuthorized(ply))) then
						timer.Simple(bKeycardScanner.Config.ScanTime,success)
						return
					end
					timer.Simple(bKeycardScanner.Config.ScanTime,function()
						if (IsValid(ent)) then
							if (not ent:VerifyScan(scanid)) then return end
							if (not ply:HasWeapon("bkeycard") and bKeycardScanner.Config.TakeKeycard) then
								ply:Give("bkeycard")
							end
							ent:AccessDenied()
						end
					end)
				end
			elseif (CLIENT) then
				bKeycardScanner:chatprint("You're too far away!","bad")
			end
		elseif (CLIENT) then
			bKeycardScanner:chatprint("Please wait until the keycard scanner has finished scanning.","bad")
		end
	elseif (CLIENT) then
		bKeycardScanner:chatprint("That's not a keycard scanner!","bad")
	end
end

--########################################--
--       SWEP CONSTRUCTION KIT CODE       --
--########################################--

SWEP.wRenderOrder = nil
function SWEP:DrawWorldModel()
	
	if (self.ShowWorldModel == nil or self.ShowWorldModel) then
		--self:DrawModel()
	end
	
	if (!self.WElements) then return end
	
	if (!self.wRenderOrder) then

		self.wRenderOrder = {}

		for k, v in pairs( self.WElements ) do
			if (v.type == "Model") then
				table.insert(self.wRenderOrder, 1, k)
			elseif (v.type == "Sprite" or v.type == "Quad") then
				table.insert(self.wRenderOrder, k)
			end
		end

	end
	
	if (IsValid(self.Owner)) then
		bone_ent = self.Owner
	else
		bone_ent = self
	end
	
	for k, name in pairs( self.wRenderOrder ) do
	
		local v = self.WElements[name]
		if (!v) then self.wRenderOrder = nil break end
		if (v.hide) then continue end
		
		local pos, ang
		
		if (v.bone) then
			pos, ang = self:GetBoneOrientation( self.WElements, v, bone_ent )
		else
			pos, ang = self:GetBoneOrientation( self.WElements, v, bone_ent, "ValveBiped.Bip01_R_Hand" )
		end
		
		if (!pos) then continue end
		
		local model = v.modelEnt
		local sprite = v.spriteMaterial
		
		if (v.type == "Model" and IsValid(model)) then

			model:SetPos(pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z )
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)

			model:SetAngles(ang)
			local matrix = Matrix()
			matrix:Scale(v.size)
			model:EnableMatrix( "RenderMultiply", matrix )
			
			if (v.material == "") then
				model:SetMaterial("")
			elseif (model:GetMaterial() != v.material) then
				model:SetMaterial( v.material )
			end
			
			if (v.skin and v.skin != model:GetSkin()) then
				model:SetSkin(v.skin)
			end
			
			if (v.bodygroup) then
				for k, v in pairs( v.bodygroup ) do
					if (model:GetBodygroup(k) != v) then
						model:SetBodygroup(k, v)
					end
				end
			end
			
			if (v.surpresslightning) then
				render.SuppressEngineLighting(true)
			end
			
			render.SetColorModulation(v.color.r/255, v.color.g/255, v.color.b/255)
			render.SetBlend(v.color.a/255)
			model:DrawModel()
			render.SetBlend(1)
			render.SetColorModulation(1, 1, 1)
			
			if (v.surpresslightning) then
				render.SuppressEngineLighting(false)
			end
			
		elseif (v.type == "Sprite" and sprite) then
			
			local drawpos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			render.SetMaterial(sprite)
			render.DrawSprite(drawpos, v.size.x, v.size.y, v.color)
			
		elseif (v.type == "Quad" and v.draw_func) then
			
			local drawpos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
			ang:RotateAroundAxis(ang:Up(), v.angle.y)
			ang:RotateAroundAxis(ang:Right(), v.angle.p)
			ang:RotateAroundAxis(ang:Forward(), v.angle.r)
			
			cam.Start3D2D(drawpos, ang, v.size)
				v.draw_func( self )
			cam.End3D2D()

		end
		
	end
	
end

function SWEP:GetBoneOrientation( basetab, tab, ent, bone_override )
	
	local bone, pos, ang
	if (tab.rel and tab.rel != "") then
		
		local v = basetab[tab.rel]
		
		if (!v) then return end
		
		pos, ang = self:GetBoneOrientation( basetab, v, ent )
		
		if (!pos) then return end
		
		pos = pos + ang:Forward() * v.pos.x + ang:Right() * v.pos.y + ang:Up() * v.pos.z
		ang:RotateAroundAxis(ang:Up(), v.angle.y)
		ang:RotateAroundAxis(ang:Right(), v.angle.p)
		ang:RotateAroundAxis(ang:Forward(), v.angle.r)
			
	else
	
		bone = ent:LookupBone(bone_override or tab.bone)

		if (!bone) then return end
		
		pos, ang = Vector(0,0,0), Angle(0,0,0)
		local m = ent:GetBoneMatrix(bone)
		if (m) then
			pos, ang = m:GetTranslation(), m:GetAngles()
		end
		
		if (IsValid(self.Owner) and self.Owner:IsPlayer() and 
			ent == self.Owner:GetViewModel() and self.ViewModelFlip) then
			ang.r = -ang.r
		end
	
	end
	
	return pos, ang
end

function SWEP:CreateModels( tab )

	if (!tab) then return end

	for k, v in pairs( tab ) do
		if (v.type == "Model" and v.model and v.model != "" and (!IsValid(v.modelEnt) or v.createdModel != v.model) and 
				string.find(v.model, ".mdl") and file.Exists (v.model, "GAME") ) then
			
			v.modelEnt = ClientsideModel(v.model, RENDER_GROUP_VIEW_MODEL_OPAQUE)
			if (IsValid(v.modelEnt)) then
				v.modelEnt:SetPos(self:GetPos())
				v.modelEnt:SetAngles(self:GetAngles())
				v.modelEnt:SetParent(self)
				v.modelEnt:SetNoDraw(true)
				v.createdModel = v.model
			else
				v.modelEnt = nil
			end
			
		elseif (v.type == "Sprite" and v.sprite and v.sprite != "" and (!v.spriteMaterial or v.createdSprite != v.sprite) 
			and file.Exists ("materials/"..v.sprite..".vmt", "GAME")) then
			
			local name = v.sprite.."-"
			local params = { ["$basetexture"] = v.sprite }

			local tocheck = { "nocull", "additive", "vertexalpha", "vertexcolor", "ignorez" }
			for i, j in pairs( tocheck ) do
				if (v[j]) then
					params["$"..j] = 1
					name = name.."1"
				else
					name = name.."0"
				end
			end

			v.createdSprite = v.sprite
			v.spriteMaterial = CreateMaterial(name,"UnlitGeneric",params)
			
		end
	end
	
end