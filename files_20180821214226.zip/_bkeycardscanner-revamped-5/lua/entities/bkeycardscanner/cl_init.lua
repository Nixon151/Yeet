include("shared.lua")

function ENT:Initialize()
	self.Progress = 0
end

local function CrackingText()
	local stuff = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
	local s = ""
	for i=1,math.random(6,10) do
		if (math.random(1,2) == 1) then
			if (math.random(1,2) == 1) then
				s = s .. stuff[math.random(1,#stuff)]
			else
				s = s .. stuff[math.random(1,#stuff)]:upper()
			end
		else
			s = s .. math.random(0,9)
		end
	end
	return s
end
function ENT:Draw()
	self:DrawModel()

	if (self:GetScanning()) then
		if (not self.Progressing) then
			self.Progressing = true
			self.ScanTime = CurTime() + bKeycardScanner.Config.ScanTime
		end
		self.Progress = 1 - ((self.ScanTime - CurTime()) / bKeycardScanner.Config.ScanTime)
	else
		self.Progress = 0
		self.Progressing = false
	end

	cam.Start3D2D(self:LocalToWorld(Vector(-3.14,-2.31,0.47)), self:LocalToWorldAngles(Angle(0,90,0)), 0.025)
		if (self:GetText() == "GRANTED") then
			surface.SetDrawColor(Color(48,164,0))
			surface.DrawRect(0,0,185,50)
		elseif (self:GetText() == "DENIED" or self:GetBeingCracked() or self:GetLockdown()) then
			surface.SetDrawColor(Color(156,0,0))
			surface.DrawRect(0,0,185,50)
		else
			surface.SetDrawColor(Color(1,54,165))
			surface.DrawRect(0,0,185,50)
		end
		surface.SetDrawColor(Color(48,164,0))
		surface.DrawRect(0,0,185 * self.Progress,50)
		if (self:GetBeingCracked()) then
			if (not self.CrackingText) then
				self.CrackingText = CrackingText()
				self.CrackingTime = CurTime()
			end
			if (CurTime() > self.CrackingTime + 0.01) then
				self.CrackingText = CrackingText()
				self.CrackingTime = CurTime()
			end
			draw.DrawText(self.CrackingText,"bkeycardscanner_3d2d",92.5,10,Color(255,255,255),TEXT_ALIGN_CENTER)
		else
			if (self:GetText() == "WAITING" and self:GetLockdown()) then
				draw.DrawText("LOCKDOWN","bkeycardscanner_3d2d",92.5,10,Color(255,255,255),TEXT_ALIGN_CENTER)
			else
				draw.DrawText(self:GetText(),"bkeycardscanner_3d2d",92.5,10,Color(255,255,255),TEXT_ALIGN_CENTER)
			end
		end
	cam.End3D2D()
end

function ENT:OnRemove()
	if (IsValid(bKeycardScanner.Menu)) then
		if (bKeycardScanner.MenuKeycardScanner == self) then
			bKeycardScanner.Menu:Close()
		end
	end
end