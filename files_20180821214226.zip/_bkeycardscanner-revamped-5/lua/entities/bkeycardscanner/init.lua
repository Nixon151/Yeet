AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	if (not file.Exists("bkeycardscanner","DATA")) then
		file.CreateDir("bkeycardscanner")
	end
	if (not file.Exists("bkeycardscanner/id.txt","DATA")) then
		file.Write("bkeycardscanner/id.txt",0)
	end

	self:SetModel("models/bkeycardscanner/bkeycardscanner.mdl")
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	self:SetClientCreator(self:GetCreator())
	self:SetTime(bKeycardScanner.Config.MinimumTime)
	self:SetText("WAITING")

	hook.Run("bkeycardscanner_keycardscanner_created",self)
end

function ENT:VerifyScan(scanid)
	if (self.ScanID == scanid) then
		return true
	else
		return false
	end
end
function ENT:GetScanToken()
	self.ScanID = (self.ScanID or -1) + 1
	return self.ScanID
end

function ENT:Use(ply)
	if ((self:GetPermanent() and bKeycardScanner:IsAdmin(ply)) or bKeycardScanner:IsOwnerOf(self,ply)) then
		bKeycardScanner:nets("openmenu")
			net.WriteEntity(self)
			net.WriteInt(0,3)
		net.Send(ply)
	else
		bKeycardScanner:nets("tip")
		net.Send(ply)
	end
end

function ENT:SpawnFunction(ply,tr,ClassName)
	if (not tr.Hit) then return end

	local SpawnPos = tr.HitPos + tr.HitNormal * 10
	local SpawnAng = ply:EyeAngles()
	SpawnAng.p = -90

	local ent = ents.Create( ClassName )
	ent:SetCreator( ply )
	ent:SetPos( SpawnPos )
	ent:SetAngles( SpawnAng )
	ent:Spawn()
	ent:Activate()

	return ent
end