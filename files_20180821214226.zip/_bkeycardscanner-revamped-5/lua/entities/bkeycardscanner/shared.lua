ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "bKeycardScanner"
ENT.Author = "Billy (STEAM_0:1:40314158)"

ENT.Spawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Int",0,"ScannerID")

	self:NetworkVar("Bool",1,"Scanning")
	self:NetworkVar("Bool",2,"BeingCracked")
	self:NetworkVar("String",0,"Text")

	self:NetworkVar("Entity",0,"ClientCreator")
	self:NetworkVar("Entity",1,"MirrorParent")
	self:NetworkVar("Entity",2,"MirrorChild")
	self:NetworkVar("Entity",3,"ScanningPly")

	-- Mirrored stuff
	self:NetworkVar("Int",1,"_i_AccessGrantedKey")
	self:NetworkVar("Int",2,"_i_AccessDeniedKey")
	self:NetworkVar("Int",3,"_i_Time")
	self:NetworkVar("Int",4,"_i_LinkedDoorMapIndex")
	self:NetworkVar("Int",5,"_i_LinkedDoorEntIndex")
	self:NetworkVar("Int",6,"_i_LinkedButtonMapIndex")
	self:NetworkVar("Int",7,"_i_LinkedButtonEntIndex")
	self:NetworkVar("Bool",3,"_i_Lockdown")
	self:NetworkVar("Bool",4,"_i_Permanent")
	self:NetworkVar("Bool",5,"_i_Waiting")
	self:NetworkVar("Bool",6,"_i_DisableButton")
	self:NetworkVar("String",1,"_i_LinkedDoorName")
end

local function get_root_parent(keycard_scanner)
	if (IsValid(keycard_scanner:GetMirrorParent())) then
		return get_root_parent(keycard_scanner:GetMirrorParent())
	else
		return keycard_scanner
	end
end
local function get_all_mirrors(keycard_scanner,mirrors,root)
	if (not root) then
		root = get_root_parent(keycard_scanner)
	end
	table.insert(mirrors,root)
	if (IsValid(root:GetMirrorChild())) then
		return get_all_mirrors(nil,mirrors,root:GetMirrorChild())
	else
		return mirrors
	end
end
function ENT:GetAllMirrors()
	return get_all_mirrors(self,{})
end

if (SERVER) then
	function ENT:ResetData()
		self:Set_i_AccessGrantedKey(0)
		self:Set_i_AccessDeniedKey(0)
		self:Set_i_Time(0)
		self:Set_i_LinkedDoorMapIndex(0)
		self:Set_i_LinkedDoorEntIndex(0)
		self:Set_i_Lockdown(false)
		self:Set_i_LinkedDoorName("")
		self.Authorized = {}
		if (self:GetPermanent() == true) then
			bKeycardScanner:UpdatePermanentKeycardScanners()
		end
	end

	function ENT:SetPermanent(arg,ply)
		for _,v in pairs(self:GetAllMirrors()) do
			v:Set_i_AccessGrantedKey(0)
			v:Set_i_AccessDeniedKey(0)
			v:Set_i_Permanent(arg)
			v:SetLockdown(false)
			if (arg == true) then
				v:SetCreator(NULL)
				v:SetClientCreator(NULL)
			elseif (IsValid(ply)) then
				v:SetCreator(ply)
				v:SetClientCreator(ply)
			end
		end
		bKeycardScanner:UpdatePermanentKeycardScanners()
	end
	function ENT:SetLockdown(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetLockdown(arg)
		else
			self:Set_i_Lockdown(arg)
		end
	end
	function ENT:SetAccessGrantedKey(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetAccessGrantedKey(arg)
		else
			self:Set_i_AccessGrantedKey(arg)
		end
	end
	function ENT:SetAccessDeniedKey(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetAccessDeniedKey(arg)
		else
			self:Set_i_AccessDeniedKey(arg)
		end
	end
	function ENT:SetTime(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetTime(arg)
		else
			self:Set_i_Time(arg)
		end
	end
	function ENT:SetWaiting(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetWaiting(arg)
		else
			self:Set_i_Waiting(arg)
		end
	end
	function ENT:SetDisableButton(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetDisableButton(arg)
		else
			self:Set_i_DisableButton(arg)
		end
	end

	function ENT:SetDoor(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetDoor(arg)
		else
			self:Set_i_LinkedButtonMapIndex(0)
			self:Set_i_LinkedButtonMapIndex(0)
			for _,v in pairs(self:GetDoors()) do
				v:SetNWInt("b_bKeycardScannerEntIndex",0)
			end
			if (type(arg) == "string") then
				self:Set_i_LinkedDoorMapIndex(0)
				self:Set_i_LinkedDoorEntIndex(0)
				self:Set_i_LinkedDoorName(arg)
				for _,v in pairs(ents.FindByName(arg)) do
					v:SetNWInt("b_bKeycardScannerEntIndex",self:EntIndex())
					v:SetNWInt("b_MappedName",v:GetName())
				end
			elseif (arg == 0) then
				self:Set_i_LinkedDoorMapIndex(0)
				self:Set_i_LinkedDoorEntIndex(0)
				self:Set_i_LinkedDoorName("")
			elseif (type(arg) == "number") then
				local door = ents.GetMapCreatedEntity(arg)
				self:Set_i_LinkedDoorMapIndex(arg)
				self:Set_i_LinkedDoorEntIndex(door:EntIndex())
				self:Set_i_LinkedDoorName("")
				door:SetNWInt("b_bKeycardScannerEntIndex",self:EntIndex())
			end
		end
	end
	function ENT:SetButton(arg)
		if (IsValid(self:GetMirrorParent())) then
			self:GetMirrorParent():SetDoor(arg)
		else
			self:Set_i_LinkedDoorMapIndex(0)
			self:Set_i_LinkedDoorEntIndex(0)
			if (self:Get_i_LinkedButtonEntIndex() ~= 0) then
				local prev_btn = Entity(self:Get_i_LinkedButtonEntIndex())
				if (IsValid(prev_btn)) then
					prev_btn:SetNWInt("b_bKeycardScannerEntIndex",0)
				end
			end
			if (arg == 0) then
				self:Set_i_LinkedButtonMapIndex(0)
				self:Set_i_LinkedButtonMapIndex(0)
			else
				local button = ents.GetMapCreatedEntity(arg)
				self:Set_i_LinkedButtonMapIndex(arg)
				self:Set_i_LinkedButtonEntIndex(button:EntIndex())
				button:SetNWInt("b_bKeycardScannerEntIndex",self:EntIndex())
			end
		end
	end

	function ENT:AccessGranted()
		self:GetScanToken()
		self:SetText("GRANTED")
		self:SetScanning(false)
		self:SetScanningPly(NULL)
		self:EmitSound("buttons/button14.wav",SNDLVL_45dB)
		self:ShowKeycard(false)
		self:SetLights(false,true,false)
		timer.Simple(self:GetTime(),function()
			if (IsValid(self)) then
				self:SetText("WAITING")
				self:SetWaiting(false)
				self:ShowKeycard(false)
				self:SetLights(false,false,false)
			end
		end)
		if (IsValid(self:GetButton())) then
			local button = self:GetButton()
			button:Fire("unlock")
			button:Fire("use")
			if (self:GetDisableButton()) then
				button:Fire("lock")
				if (self:GetTime() ~= 0) then
					timer.Simple(self:GetTime(),function()
						button:Fire("unlock")
						button:Fire("use")
						if (self:GetDisableButton()) then
							button:Fire("lock")
						end
					end)
				end
			end
		else
			local doors = self:GetDoors()
			if (#doors > 0) then
				for _,v in pairs(doors) do
					if (bKeycardScanner:IsDoorOpen(v)) then
						v:Fire("Close")
						v:Fire("Lock")
					else
						v:Fire("Unlock")
						v:Fire("Open")
						if (self:GetTime() ~= 0) then
							timer.Simple(self:GetTime(),function()
								if (bKeycardScanner:IsDoorOpen(v)) then
									v:Fire("Close")
								end
								v:Fire("Lock")
							end)
						end
					end
				end
			end
		end
		if (IsValid(self:GetCreator()) and self:GetAccessGrantedKey() ~= 0) then
			numpad.Activate(self:GetCreator(),self:GetAccessGrantedKey(),true)
			timer.Simple(self:GetTime(),function()
				numpad.Deactivate(self:GetCreator(),self:GetAccessGrantedKey(),true)
			end)
		end
	end
	function ENT:AccessDenied()
		self:GetScanToken()
		self:SetText("DENIED")
		self:SetScanning(false)
		self:SetScanningPly(NULL)
		self:EmitSound("buttons/button10.wav",SNDLVL_45dB)
		self:ShowKeycard(false)
		self:SetLights(true,false,false)
		timer.Simple(2,function()
			if (IsValid(self)) then
				self:SetText("WAITING")
				self:SetWaiting(false)
				self:ShowKeycard(false)
				self:SetLights(false,false,false)
			end
		end)
		if (IsValid(self:GetCreator()) and self:GetAccessDeniedKey() ~= 0) then
			numpad.Activate(self:GetCreator(),self:GetAccessDeniedKey(),true)
			timer.Simple(self:GetTime(),function()
				numpad.Deactivate(self:GetCreator(),self:GetAccessDeniedKey(),true)
			end)
		end
	end

	function ENT:ShowKeycard(show)
		if (show) then
			self:SetBodygroup(0,1)
		else
			self:SetBodygroup(0,0)
		end
	end
	function ENT:SetLights(red,green,blue)
		if (not red and not green and not blue) then
			self:SetSkin(0)
		elseif (red) then
			self:SetSkin(2)
		elseif (green) then
			self:SetSkin(1)
		elseif (blue) then
			self:SetSkin(3)
		end
	end

	function ENT:Think()
		if (IsValid(self:GetScanningPly()) and self:GetScanningPly():GetPos():Distance(self:GetPos()) > bKeycardScanner.Config.ScanDistance) then
			if (bKeycardScanner.Config.TakeKeycard) then
				self:GetScanningPly():Give("bkeycard")
			end
			bKeycardScanner:nets("distance_tip")
			net.Send(self:GetScanningPly())
			self:AccessDenied()
		end
	end
end

function ENT:GetDisableButton()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetDisableButton()
	else
		return self:Get_i_DisableButton()
	end
end
function ENT:GetWaiting()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetWaiting()
	else
		return self:Get_i_Waiting()
	end
end
function ENT:GetTime()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetTime()
	else
		return self:Get_i_Time()
	end
end
function ENT:GetPermanent()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetPermanent()
	else
		return self:Get_i_Permanent()
	end
end
function ENT:GetLockdown()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetLockdown()
	else
		return self:Get_i_Lockdown()
	end
end
function ENT:GetAccessGrantedKey(arg)
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetAccessGrantedKey()
	else
		return self:Get_i_AccessGrantedKey()
	end
end
function ENT:GetAccessDeniedKey(arg)
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetAccessDeniedKey()
	else
		return self:Get_i_AccessDeniedKey()
	end
end

function ENT:IsAuthorized(ply)
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():IsAuthorized(ply)
	else
		local r = false
		for _,v in pairs(self.Authorized) do
			if (v[1] == 4 and bKeycardScanner.Config.customChecks[v[2]]) then
				local result = bKeycardScanner.Config.customChecks[v[2]](self:GetCreator(), ply)
				if (result == true) then
					r = true
				elseif (result == false) then
					return false
				end
			elseif (
			       (v[1] == 1 and v[2] == ply:SteamID())
			    or (v[1] == 2 and v[2] == team.GetName(ply:Team()))
				or (v[1] == 3 and v[2] == ply:GetUserGroup())
			) then
				r = true
			end
		end
		return r
	end
end

function ENT:GetDoors()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetDoors()
	end
	if (self:Get_i_LinkedDoorName() ~= "") then
		if (SERVER) then
			return ents.FindByName(self:Get_i_LinkedDoorName())
		else
			local doors = {}
			for _,v in pairs(ents.GetAll()) do
				if (v:GetNWString("b_MappedName") == self:Get_i_LinkedDoorName()) then
					table.insert(doors,v)
				end
			end
			return doors
		end
	elseif (self:Get_i_LinkedDoorMapIndex() ~= 0 or self:Get_i_LinkedDoorEntIndex() ~= 0) then
		if (SERVER) then
			return {ents.GetMapCreatedEntity(self:Get_i_LinkedDoorMapIndex())}
		else
			return {Entity(self:Get_i_LinkedDoorEntIndex())}
		end
	end
	return {}
end

function ENT:GetButton()
	if (IsValid(self:GetMirrorParent())) then
		return self:GetMirrorParent():GetButton()
	end
	if (self:Get_i_LinkedButtonEntIndex() ~= 0 or self:Get_i_LinkedButtonMapIndex() ~= 0) then
		if (SERVER) then
			return ents.GetMapCreatedEntity(self:Get_i_LinkedButtonMapIndex())
		else
			return Entity(self:Get_i_LinkedButtonEntIndex())
		end
	end
end