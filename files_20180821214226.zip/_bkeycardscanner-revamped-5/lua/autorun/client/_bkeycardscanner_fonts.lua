surface.CreateFont("bkeycardscanner_16",{
	font = "Purista",
	size = 16,
})

surface.CreateFont("bkeycardscanner_18",{
	font = "Purista",
	size = 18,
})

surface.CreateFont("bkeycardscanner_20",{
	font = "Purista",
	size = 20,
})

surface.CreateFont("bkeycardscanner_24",{
	font = "Purista",
	size = 24,
})


surface.CreateFont("bkeycardscanner_3d2d",{
	font = "dotty",
	size = 36,
	antialias = true
})
