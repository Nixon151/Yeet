if (bKeycardScanner and CLIENT) then
	if (IsValid(bKeycardScanner.Menu)) then
		bKeycardScanner.Menu:Close()
	end
end

bKeycardScanner = {}
bKeycardScanner.Version = "Revamped-5"
bKeycardScanner.Licensee = "76561198123392139"

if (SERVER) then
	resource.AddWorkshop("1261820532")
	resource.AddFile("resource/fonts/dotty.ttf")
	resource.AddFile("resource/fonts/puristabold.otf")

	AddCSLuaFile("bkeycardscanner/sh.lua")
	AddCSLuaFile("bkeycardscanner/cl.lua")
	AddCSLuaFile("bkeycardscanner/default_config.lua")
	AddCSLuaFile("bkeycardscanner_config.lua")
	for _,v in pairs((file.Find("vgui/bkeycardscanner/*.lua","LUA"))) do
		AddCSLuaFile("vgui/bkeycardscanner/" .. v)
	end
end
include("bkeycardscanner/sh.lua")
