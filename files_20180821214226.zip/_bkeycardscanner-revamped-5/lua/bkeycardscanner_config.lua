bKeycardScanner.Config = {} local config = bKeycardScanner.Config
--[[


	██╗    ██╗ █████╗ ██████╗ ███╗   ██╗██╗███╗   ██╗ ██████╗
	██║    ██║██╔══██╗██╔══██╗████╗  ██║██║████╗  ██║██╔════╝
	██║ █╗ ██║███████║██████╔╝██╔██╗ ██║██║██╔██╗ ██║██║  ███╗
	██║███╗██║██╔══██║██╔══██╗██║╚██╗██║██║██║╚██╗██║██║   ██║
	╚███╔███╔╝██║  ██║██║  ██║██║ ╚████║██║██║ ╚████║╚██████╔╝
	 ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝ ╚═════╝

	If you are using a leak of bKeycardScanner, before you even bother to configure it, I warn you that the leak WILL NOT work.

	If you are willing to take the risk, you may be causing yourself a danger. SO DON'T DO IT.

	You can purchase the script on ScriptFodder.

	----------------------------------------------------------------------------------------------------------------------------------------------------------------

	Si tu utilises un leak de bKeycardScanner, avant que tu te fasses chier à le configurer, je te préviens que ce leak NE MARCHERA PAS.

	Si tu tiens à prendre le risque, tu te poses un danger inutile. ALORS NE LE FAIS PAS.

	Tu peux acheter ce script sur ScriptFodder.

	=================================================================================================================================================================

	██████╗ ██╗  ██╗███████╗██╗   ██╗ ██████╗ █████╗ ██████╗ ██████╗ ███████╗ ██████╗ █████╗ ███╗   ██╗███╗   ██╗███████╗██████╗
	██╔══██╗██║ ██╔╝██╔════╝╚██╗ ██╔╝██╔════╝██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗████╗  ██║████╗  ██║██╔════╝██╔══██╗
	██████╔╝█████╔╝ █████╗   ╚████╔╝ ██║     ███████║██████╔╝██║  ██║███████╗██║     ███████║██╔██╗ ██║██╔██╗ ██║█████╗  ██████╔╝
	██╔══██╗██╔═██╗ ██╔══╝    ╚██╔╝  ██║     ██╔══██║██╔══██╗██║  ██║╚════██║██║     ██╔══██║██║╚██╗██║██║╚██╗██║██╔══╝  ██╔══██╗
	██████╔╝██║  ██╗███████╗   ██║   ╚██████╗██║  ██║██║  ██║██████╔╝███████║╚██████╗██║  ██║██║ ╚████║██║ ╚████║███████╗██║  ██║
	╚═════╝ ╚═╝  ╚═╝╚══════╝   ╚═╝    ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝

	Please note that there is quite a lot of profanity and insults in this config, mostly because many people can't FUCKING READ
	However, if you can read and you have common sense, we're best bros so you can just ignore the profanity.

	WARNING: Are you retarded? Then this might be more difficult for you! The config is very simple and I provide instructions,
			 examples, templates and more but some people still can't figure it out. If that's you, read it again and PLEASE
			 don't make a ticket. We have more important things to attend to and configuration of addons is NEVER the developer's
			 responsibility.

	WARNING: You might need to know English to configure this addon! Wow, surprise surprise, English is a very popular language!
			 Maybe you should learn it if you don't know it. Haha, let's all keep laughing at how France is the least English
			 speaking country in Europe.

	WARNING: Use a fucking syntax text editor! Are you using Notepad? Fuck off! Download Notepad++, Sublime Text or Atom.io.

	 _____        __            _ ___          __
	|  __ \      / _|          | | \ \        / /
	| |  | | ___| |_ __ _ _   _| | |\ \  /\  / /__  __ _ _ __   ___  _ __
	| |  | |/ _ \  _/ _` | | | | | __\ \/  \/ / _ \/ _` | '_ \ / _ \| '_ \
	| |__| |  __/ || (_| | |_| | | |_ \  /\  /  __/ (_| | |_) | (_) | | | |
	|_____/ \___|_| \__,_|\__,_|_|\__| \/  \/ \___|\__,_| .__/ \___/|_| |_|
													   | |
													   |_|

	If you'd like players to spawn with the keycard, set this to true. If not, set it to false.

	EXAMPLES:

	config.DefaultWeapon = true
	config.DefaultWeapon = false

]] config.DefaultWeapon = true --[[

	  _______    _        _  __                            _
	 |__   __|  | |      | |/ /                           | |
	    | | __ _| | _____| ' / ___ _   _  ___ __ _ _ __ __| |
	    | |/ _` | |/ / _ \  < / _ \ | | |/ __/ _` | '__/ _` |
	    | | (_| |   <  __/ . \  __/ |_| | (_| (_| | | | (_| |
	    |_|\__,_|_|\_\___|_|\_\___|\__, |\___\__,_|_|  \__,_|
	                                __/ |
	                               |___/

	Should the keycard be removed from the player's loadout when being scanned?

	EXAMPLES:

	config.TakeKeycard = true
	config.TakeKeycard = false

]] config.TakeKeycard = true --[[

	              _           _
	     /\      | |         (_)
	    /  \   __| |_ __ ___  _ _ __  ___
	   / /\ \ / _` | '_ ` _ \| | '_ \/ __|
	  / ____ \ (_| | | | | | | | | | \__ \
	 /_/    \_\__,_|_| |_| |_|_|_| |_|___/


	bKeycardScanner admins can:

	* Link keycard scanners to doors
	* Make keycard scanners permanent
	* Edit & read other people's keycard scanners

	You can put usergroups, SteamIDs and SteamID64s in this.

	EXAMPLES:

	config.Admins = {"superadmin","admin","moderator"}
	config.Admins = {"76561198040894045","STEAM_0:1:40314158"}
	config.Admins = {"superadmin","76561198040894045","STEAM_0:1:40314158"}

]] config.Admins = {"superadmin","76561198040894045","STEAM_0:1:40314158"} --[[

	          _ _               _____  _
	    /\   | | |             |  __ \| |
	   /  \  | | | _____      _| |__) | |__  _   _ ___  __ _ _   _ _ __
	  / /\ \ | | |/ _ \ \ /\ / /  ___/| '_ \| | | / __|/ _` | | | | '_ \
	 / ____ \| | | (_) \ V  V /| |    | | | | |_| \__ \ (_| | |_| | | | |
	/_/    \_\_|_|\___/ \_/\_/ |_|    |_| |_|\__, |___/\__, |\__,_|_| |_|
	                                          __/ |     __/ |
								             |___/     |___/

	Usually your players won't need to physgun their keycard scanners. If for some reason they
	want to, you can enable it here.

	EXAMPLES:

	config.AllowPhysgun = true
	config.AllowPhysgun = false

]] config.AllowPhysgun = true --[[

	  _____                 _____  _     _
	 / ____|               |  __ \(_)   | |
	| (___   ___ __ _ _ __ | |  | |_ ___| |_ __ _ _ __   ___ ___
	 \___ \ / __/ _` | '_ \| |  | | / __| __/ _` | '_ \ / __/ _ \
	 ____) | (_| (_| | | | | |__| | \__ \ || (_| | | | | (_|  __/
	|_____/ \___\__,_|_| |_|_____/|_|___/\__\__,_|_| |_|\___\___|

	The distance in source units that someone can scan their keycard in the
	keycard scanner from.

 	EXAMPLES:

	config.ScanDistance = 80
	config.ScanDistance = 100
	config.ScanDistance = 150

]] config.ScanDistance = 100 --[[

	  _____              _______ _
	 / ____|            |__   __(_)
	| (___   ___ __ _ _ __ | |   _ _ __ ___   ___
	 \___ \ / __/ _` | '_ \| |  | | '_ ` _ \ / _ \
	 ____) | (_| (_| | | | | |  | | | | | | |  __/
	|_____/ \___\__,_|_| |_|_|  |_|_| |_| |_|\___|

	The amount of time it takes for a keycard to be scanned in seconds.

  	EXAMPLES:

 	config.ScanTime = 1.5
 	config.ScanTime = 2
 	config.ScanTime = 5

]] config.ScanTime = 1.3 --[[

	 _  __                            _  _____                                 ______  _____ _____  
	| |/ /                           | |/ ____|                               |  ____|/ ____|  __ \ 
	| ' / ___ _   _  ___ __ _ _ __ __| | (___   ___ __ _ _ __  _ __   ___ _ __| |__  | (___ | |__) |
	|  < / _ \ | | |/ __/ _` | '__/ _` |\___ \ / __/ _` | '_ \| '_ \ / _ \ '__|  __|  \___ \|  ___/ 
	| . \  __/ |_| | (_| (_| | | | (_| |____) | (_| (_| | | | | | | |  __/ |  | |____ ____) | |     
	|_|\_\___|\__, |\___\__,_|_|  \__,_|_____/ \___\__,_|_| |_|_| |_|\___|_|  |______|_____/|_|     
	           __/ |                                                                                
	          |___/                                                                                 
	
	What ranks can see linked keycard scanners and doors when they have their toolgun out?

	You can put usergroups, SteamIDs and SteamID64s in this.

	EXAMPLES:

	config.KeycardScannerESP = {"superadmin","admin","moderator"}
	config.KeycardScannerESP = {"76561198040894045","STEAM_0:1:40314158"}
	config.KeycardScannerESP = {"superadmin","76561198040894045","STEAM_0:1:40314158"}

]] config.KeycardScannerESP = {"superadmin","76561198040894045","STEAM_0:1:40314158"} --[[

	 __  __ _       _                        _______ _                
	|  \/  (_)     (_)                      |__   __(_)               
	| \  / |_ _ __  _ _ __ ___  _   _ _ __ ___ | |   _ _ __ ___   ___ 
	| |\/| | | '_ \| | '_ ` _ \| | | | '_ ` _ \| |  | | '_ ` _ \ / _ \
	| |  | | | | | | | | | | | | |_| | | | | | | |  | | | | | | |  __/
	|_|  |_|_|_| |_|_|_| |_| |_|\__,_|_| |_| |_|_|  |_|_| |_| |_|\___|
	                                                                 

	The time in seconds that the keycard scanner's open/close time cannot go below.

	EXAMPLES:

	config.MinimumTime = 2
	config.MinimumTime = 3
	config.MinimumTime = 4

]] config.MinimumTime = 0 --[[

	  _____                _ _______ _                
	 / ____|              | |__   __(_)               
	| |     _ __ __ _  ___| | _| |   _ _ __ ___   ___ 
	| |    | '__/ _` |/ __| |/ / |  | | '_ ` _ \ / _ \
	| |____| | | (_| | (__|   <| |  | | | | | | |  __/
	 \_____|_|  \__,_|\___|_|\_\_|  |_|_| |_| |_|\___|
	                                                   

	The time in seconds that the regular keycard scanner cracker takes to crack a keycard scanner.

	EXAMPLES:

	config.CrackTime = 30
	config.CrackTime = 45
	config.CrackTime = 60

]] config.CrackTime = 10 --[[

	 _____            _____                _ _______ _                
	|  __ \          / ____|              | |__   __(_)               
	| |__) | __ ___ | |     _ __ __ _  ___| | _| |   _ _ __ ___   ___ 
	|  ___/ '__/ _ \| |    | '__/ _` |/ __| |/ / |  | | '_ ` _ \ / _ \
	| |   | | | (_) | |____| | | (_| | (__|   <| |  | | | | | | |  __/
	|_|   |_|  \___/ \_____|_|  \__,_|\___|_|\_\_|  |_|_| |_| |_|\___|
	                                                                   
	The time in seconds that the pro keycard scanner cracker takes to crack a keycard scanner.

	EXAMPLES:

	config.ProCrackTime = 15
	config.ProCrackTime = 30
	config.ProCrackTime = 45

]] config.ProCrackTime = 5.7 --[[

	           _ _             _____           _            _   _  __ _           _   _
	    /\   | | |           |_   _|         | |          | | (_)/ _(_)         | | (_)
	   /  \  | | | _____      _| |  _ __   __| | ___ _ __ | |_ _| |_ _  ___ __ _| |_ _  ___  _ __
	  / /\ \ | | |/ _ \ \ /\ / / | | '_ \ / _` |/ _ \ '_ \| __| |  _| |/ __/ _` | __| |/ _ \| '_ \
	 / ____ \| | | (_) \ V  V /| |_| | | | (_| |  __/ | | | |_| | | | | (_| (_| | |_| | (_) | | | |
	/_/    \_\_|_|\___/ \_/\_/_____|_| |_|\__,_|\___|_| |_|\__|_|_| |_|\___\__,_|\__|_|\___/|_| |_|

	Whether or not someone can use right click to show their keycard to someone.
	(By "show", I mean display a chat message in chat verifying their job/team)

	EXAMPLES:

	config.AllowIndentification = true
	config.AllowIndentification = false

]] config.AllowIndentification = true --[[

	  _____ _                 _____ _____   _____                                          _ 
	 / ____| |               |_   _|  __ \ / ____|                                        | |
	| (___ | |__   _____      _| | | |  | | |     ___  _ __ ___  _ __ ___   __ _ _ __   __| |
	 \___ \| '_ \ / _ \ \ /\ / / | | |  | | |    / _ \| '_ ` _ \| '_ ` _ \ / _` | '_ \ / _` |
	 ____) | | | | (_) \ V  V /| |_| |__| | |___| (_) | | | | | | | | | | | (_| | | | | (_| |
	|_____/|_| |_|\___/ \_/\_/_____|_____/ \_____\___/|_| |_| |_|_| |_| |_|\__,_|_| |_|\__,_|
	                                                                                          

	Not only can players show their IDs by right clicking with the keycard equipped,
	but they can also use the classic command. You can turn this off as well by making this false.

	EXAMPLES:

	config.ShowIDCommand = "/showid"
	config.ShowIDCommand = "!showid"
	config.ShowIDCommand = false -- no command

]] config.ShowIDCommand = "/showid" --[[

	  _____ _                 _____ _____  _____  _     _                       
	 / ____| |               |_   _|  __ \|  __ \(_)   | |                      
	| (___ | |__   _____      _| | | |  | | |  | |_ ___| |_ __ _ _ __   ___ ___ 
	 \___ \| '_ \ / _ \ \ /\ / / | | |  | | |  | | / __| __/ _` | '_ \ / __/ _ \
	 ____) | | | | (_) \ V  V /| |_| |__| | |__| | \__ \ || (_| | | | | (_|  __/
	|_____/|_| |_|\___/ \_/\_/_____|_____/|_____/|_|___/\__\__,_|_| |_|\___\___|
	                                                                             
	                                                                             
	The distance in Source units people can "hear" someone showing their ID from.

	EXAMPLES:

	config.ShowIDDistance = 100
	config.ShowIDDistance = 200

]] config.ShowIDDistance = 100 --[[ config.ShowIDCommand = "/showid" --[[

	  _____ _                 _____ _____   _____ _        _             
	 / ____| |               |_   _|  __ \ / ____| |      (_)            
	| (___ | |__   _____      _| | | |  | | (___ | |_ _ __ _ _ __   __ _ 
	 \___ \| '_ \ / _ \ \ /\ / / | | |  | |\___ \| __| '__| | '_ \ / _` |
	 ____) | | | | (_) \ V  V /| |_| |__| |____) | |_| |  | | | | | (_| |
	|_____/|_| |_|\___/ \_/\_/_____|_____/|_____/ \__|_|  |_|_| |_|\__, |
	                                                                __/ |
	                                                               |___/ 

	The actual message people will see in the chat when someon shows their ID.
	Use %name% for the player's name and %team% for their team.

	EXAMPLES:

	config.ShowIDString = "%name% presents their identification, it reads: %team%"

]] config.ShowIDString = "%name% presents their identification, it reads: %team%" --[[

	                _                   _____ _               _        
	               | |                 / ____| |             | |       
	  ___ _   _ ___| |_ ___  _ __ ___ | |    | |__   ___  ___| | _____ 
	 / __| | | / __| __/ _ \| '_ ` _ \| |    | '_ \ / _ \/ __| |/ / __|
	| (__| |_| \__ \ || (_) | | | | | | |____| | | |  __/ (__|   <\__ \
	 \___|\__,_|___/\__\___/|_| |_| |_|\_____|_| |_|\___|\___|_|\_\___/
	                                                                   
	FOR ADVANCED USERS ONLY! No support is given on this! You must know basic Lua to use this.
	This is where you can add custom authorizations that players can enable on their keycard scanners.

	For example, if you have a party system script, you can code a customCheck (like in DarkRP) in this config
	for the party system and then players can add your customCheck to their keycard scanners which would
	allow anyone in their party to have access to the keycard scanner.

	In the keycard scanner's menu, there will be a button that says "customChecks" under the authorization list.
	Your customChecks will show up there.

]] config.customChecks = {
	
	--[[

	-- This example is for https://www.gmodstore.com/scripts/view/2109/simple-party-system
	["Is in my party?"] = function(keycard_scanner_ply, scanning_ply)
		-- keycard_scanner_ply is the player who created the keycard scanner
		-- keycard_scanner_ply will be NULL if the keycard scanner is a permanent keycard scanner!!
		-- scanning_ply is the player trying to scan their keycard
		if (keycard_scanner_ply:GetParty() == scanning_ply:GetParty()) then
			return true -- return true to grant the player access
			-- You can also return false to FORCE access denied (overwrite any other authorizations)
		end
	end,

	]]

}