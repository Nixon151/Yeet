bKeycardScanner_Tooltips = bKeycardScanner_Tooltips or {}

local PANEL = {}

function PANEL:Paint(w,h)
	surface.SetDrawColor(Color(5,5,5,self.Alpha))
	surface.DrawRect(0,0,w,h)
	surface.SetDrawColor(Color(self.LerpColor.x,self.LerpColor.y,self.LerpColor.z))
	if (self:IsHovered()) then
		if (input.IsMouseDown(MOUSE_LEFT)) then
			self.LerpColor = LerpVector(0.05,self.LerpColor,Vector(self.ButtonDownColor.r,self.ButtonDownColor.g,self.ButtonDownColor.b))
		else
			self.LerpColor = LerpVector(0.05,self.LerpColor,Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b))
		end
		self.LerpHeight = Lerp(0.05,self.LerpHeight,h)
		surface.DrawRect(0,h-self.LerpHeight,w,self.LerpHeight)
	else
		self.LerpColor = LerpVector(0.05,self.LerpColor,Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b))
		self.LerpHeight = Lerp(0.05,self.LerpHeight,self.BorderThickness or 4)
		surface.DrawRect(0,h-self.LerpHeight,w,self.LerpHeight)
	end
end

function PANEL:Init()
	self.LerpHeight = 3
	self.LerpColor = Vector(52,139,249)
	self.ButtonColor = Color(52,139,249)
	self.ButtonDownColor = Color(33,90,160)
	self.Alpha = 255*0.75

	self:SetFont("bkeycardscanner_20")
	self:SetTextColor(Color(255,255,255))
end

function PANEL:SetTooltip(tt)
	self.Tooltip = tt
	if (IsValid(self.TooltipGUI)) then
		self.TooltipGUI:SetText(self.Tooltip)
		self.TooltipGUI:SetWide(200)
	end
	if (tt == "") then
		if (IsValid(self.TooltipGUI)) then
			self.TooltipGUI:Remove()
		end
	end
end

function PANEL:OnCursorEntered()
	local bb = self
	if (self.Tooltip == "" or self.Tooltip == nil) then return end
	self.TooltipGUI = vgui.Create("DLabel")
	table.insert(bKeycardScanner_Tooltips,self.TooltipGUI)
	self.TooltipGUI:SetDrawOnTop(true)
	self.TooltipGUI:SetTextColor(Color(255,255,255))
	self.TooltipGUI:SetFont("bkeycardscanner_16")
	self.TooltipGUI:SetDrawBackground(true)
	self.TooltipGUI:SetContentAlignment(7)
	self.TooltipGUI:SetText(self.Tooltip)
	self.TooltipGUI:SetWide(200)
	self.TooltipGUI:SetTall(ScrH())
	self.TooltipGUI:SetWrap(true)
	self.TooltipGUI.NoPaint = true
	local x,y = gui.MousePos()
	self.TooltipGUI:SetPos(x - (self.TooltipGUI:GetWide() / 2),y + 35)
	function self.TooltipGUI:Paint(w,h)
		if (not IsValid(bb)) then
			self:Remove()
			return
		end
		self:SizeToContentsY()
		if (not self.NoPaint) then
			surface.DisableClipping(true)
			surface.SetDrawColor(0,0,0,250)
			surface.DrawRect(-5,-5,w + 10,h + 10)
		end
		self.NoPaint = false
		local x,y = gui.MousePos()
		self:SizeToContentsY()
		self:SetPos(x - (self:GetWide() / 2),y + 35)
	end
end
function PANEL:OnCursorExited()
	if (IsValid(self.TooltipGUI)) then
		self.TooltipGUI:Remove()
	end
	for _,v in pairs(bKeycardScanner_Tooltips) do
		v:Remove()
	end
end

function PANEL:SetColors(ButtonColor,ButtonDownColor,animate)
	self.ButtonColor = ButtonColor
	self.ButtonDownColor = ButtonDownColor
	if (not animate) then
		if (self:IsHovered()) then
			if (input.IsMouseDown(MOUSE_LEFT)) then
				self.LerpColor = Vector(self.ButtonDownColor.r,self.ButtonDownColor.g,self.ButtonDownColor.b)
			else
				self.LerpColor = Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b)
			end
		else
			self.LerpColor = Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b)
		end
	end
end

derma.DefineControl("bKeycardScanner_DButton",nil,PANEL,"DButton")

local PANEL = {}

function PANEL:Paint(w,h)
	surface.SetDrawColor(Color(5,5,5,self.Alpha))
	surface.DrawRect(0,0,w,h)
	surface.SetDrawColor(Color(self.LerpColor.x,self.LerpColor.y,self.LerpColor.z))
	if (self:IsHovered()) then
		if (input.IsMouseDown(MOUSE_LEFT)) then
			self.LerpColor = LerpVector(0.05,self.LerpColor,Vector(self.ButtonDownColor.r,self.ButtonDownColor.g,self.ButtonDownColor.b))
		else
			self.LerpColor = LerpVector(0.05,self.LerpColor,Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b))
		end
		self.LerpHeight = Lerp(0.05,self.LerpHeight,h)
		surface.DrawRect(0,h-self.LerpHeight,w,self.LerpHeight)
	else
		self.LerpColor = LerpVector(0.05,self.LerpColor,Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b))
		self.LerpHeight = Lerp(0.05,self.LerpHeight,self.BorderThickness or 4)
		surface.DrawRect(0,h-self.LerpHeight,w,self.LerpHeight)
	end
end

function PANEL:Init()
	self.LerpHeight = 3
	self.LerpColor = Vector(52,139,249)
	self.ButtonColor = Color(52,139,249)
	self.ButtonDownColor = Color(33,90,160)
	self.Alpha = 255*0.75

	self:SetFont("bkeycardscanner_20")
	self:SetTextColor(Color(255,255,255))
end

function PANEL:SetTooltip(tt)
	self.Tooltip = tt
	if (IsValid(self.TooltipGUI)) then
		self.TooltipGUI:SetText(self.Tooltip)
		self.TooltipGUI:SetWide(200)
	end
	if (tt == "") then
		if (IsValid(self.TooltipGUI)) then
			self.TooltipGUI:Remove()
		end
	end
end

function PANEL:OnCursorEntered()
	local bb = self
	if (self.Tooltip == "" or self.Tooltip == nil) then return end
	self.TooltipGUI = vgui.Create("DLabel")
	table.insert(bKeycardScanner_Tooltips,self.TooltipGUI)
	self.TooltipGUI:SetDrawOnTop(true)
	self.TooltipGUI:SetTextColor(Color(255,255,255))
	self.TooltipGUI:SetFont("bkeycardscanner_16")
	self.TooltipGUI:SetDrawBackground(true)
	self.TooltipGUI:SetContentAlignment(7)
	self.TooltipGUI:SetText(self.Tooltip)
	self.TooltipGUI:SetWide(200)
	self.TooltipGUI:SetTall(ScrH())
	self.TooltipGUI:SetWrap(true)
	self.TooltipGUI.NoPaint = true
	local x,y = gui.MousePos()
	self.TooltipGUI:SetPos(x - (self.TooltipGUI:GetWide() / 2),y + 35)
	function self.TooltipGUI:Paint(w,h)
		if (not IsValid(bb)) then
			self:Remove()
			return
		end
		self:SizeToContentsY()
		if (not self.NoPaint) then
			surface.DisableClipping(true)
			surface.SetDrawColor(0,0,0,250)
			surface.DrawRect(-5,-5,w + 10,h + 10)
		end
		self.NoPaint = false
		local x,y = gui.MousePos()
		self:SizeToContentsY()
		self:SetPos(x - (self:GetWide() / 2),y + 35)
	end
end
function PANEL:OnCursorExited()
	if (IsValid(self.TooltipGUI)) then
		self.TooltipGUI:Remove()
	end
	for _,v in pairs(bKeycardScanner_Tooltips) do
		v:Remove()
	end
end

function PANEL:SetColors(ButtonColor,ButtonDownColor,animate)
	self.ButtonColor = ButtonColor
	self.ButtonDownColor = ButtonDownColor
	if (not animate) then
		if (self:IsHovered()) then
			if (input.IsMouseDown(MOUSE_LEFT)) then
				self.LerpColor = Vector(self.ButtonDownColor.r,self.ButtonDownColor.g,self.ButtonDownColor.b)
			else
				self.LerpColor = Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b)
			end
		else
			self.LerpColor = Vector(self.ButtonColor.r,self.ButtonColor.g,self.ButtonColor.b)
		end
	end
end

derma.DefineControl("bKeycardScanner_Binder",nil,PANEL,"DBinder")

local PANEL = {}

function PANEL:Init()
	self:SetFont("bkeycardscanner_20")
	self:SetTextColor(Color(255,255,255))
end

derma.DefineControl("bKeycardScanner_DLabel",nil,PANEL,"DLabel")

local PANEL = {}

function PANEL:Init()

	self:SetSortable( true )
	self:SetMouseInputEnabled( true )
	self:SetMultiSelect( true )
	self:SetHideHeaders( false )

	self:SetPaintBackground( true )
	self:SetHeaderHeight( 35 )
	self:SetDataHeight( 25 )

	self.Columns = {}

	self.Lines = {}
	self.Sorted = {}

	self:SetDirty( true )

	self.pnlCanvas = vgui.Create( "Panel", self )

end

function PANEL:Paint(w,h)
	surface.SetDrawColor(Color(5,5,5,255*0.75))
	surface.DrawRect(0,0,w,h)
end

function PANEL:AddColumn( strName, iPosition )

	local pColumn = nil

	pColumn = vgui.Create( "bKeycardScanner_ListView_Column", self )

	pColumn:SetName( strName )
	pColumn:SetZPos( 10 )

	if ( iPosition ) then

		table.insert( self.Columns, iPosition, pColumn )

		for i = 1, #self.Columns do
			self.Columns[ i ]:SetColumnID( i )
		end

	else

		local ID = table.insert( self.Columns, pColumn )
		pColumn:SetColumnID( ID )

	end

	self:InvalidateLayout()

	return pColumn

end

function PANEL:AddLine( ... )

	self:SetDirty( true )
	self:InvalidateLayout()

	local Line = vgui.Create( "bKeycardScanner_ListView_Line", self.pnlCanvas )
	local ID = table.insert( self.Lines, Line )

	Line:SetListView( self )
	Line:SetID( ID )

	-- This assures that there will be an entry for every column
	for k, v in pairs( self.Columns ) do
		Line:SetColumnText( k, "" )
	end

	for k, v in pairs( {...} ) do
		Line:SetColumnText( k, v )
	end

	-- Make appear at the bottom of the sorted list
	local SortID = table.insert( self.Sorted, Line )

	if ( SortID % 2 == 1 ) then
		Line:SetAltLine( true )
	end

	for _,v in pairs(Line.Columns) do
		--v:SetTextColor(Color(255,255,255))
		v:SetFont("bkeycardscanner_16")
	end

	return Line

end

derma.DefineControl("bKeycardScanner_ListView",nil,PANEL,"DListView")

local PANEL = {}

function PANEL:Init()
	self.Header = vgui.Create( "bKeycardScanner_DButton", self )
	self.Header.Alpha = 255
	self.Header.DoClick = function() self:DoClick() end
	self.Header.DoRightClick = function() self:DoRightClick() end
	self.Header:SetFont("bkeycardscanner_16")
	self.Header:SetTextColor(Color(255,255,255))

	self.DraggerBar = vgui.Create( "DListView_DraggerBar", self )

	self:SetMinWidth( 10 )
	self:SetMaxWidth( 1920 * 10 )

	self:GetChildren()[1]:Remove()
end

derma.DefineControl("bKeycardScanner_ListView_Column",nil,PANEL,"DListView_Column")

local PANEL = {}

function PANEL:Paint(w,h)
	if (self:IsLineSelected()) then
		surface.SetDrawColor(Color(200,200,200,255*0.75))
	else
		surface.SetDrawColor(Color(5,5,5,255*0.75))
	end
	surface.DrawRect(0,0,w,h)
end

function PANEL:SetColumnText( i, strText )

	if ( type( strText ) == "Panel" ) then

		if ( IsValid( self.Columns[ i ] ) ) then self.Columns[ i ]:Remove() end

		strText:SetParent( self )
		self.Columns[ i ] = strText
		self.Columns[ i ].Value = strText
		return

	end

	if ( !IsValid( self.Columns[ i ] ) ) then

		self.Columns[ i ] = vgui.Create( "bKeycardScanner_DListViewLabel", self )
		self.Columns[ i ]:SetMouseInputEnabled( false )

	end

	self.Columns[ i ]:SetText( tostring( strText ) )
	self.Columns[ i ].Value = strText
	return self.Columns[ i ]

end

function PANEL:SetTooltip(tt)
	self.Tooltip = tt
	if (IsValid(self.TooltipGUI)) then
		self.TooltipGUI:SetText(self.Tooltip)
		self.TooltipGUI:SetWide(200)
	end
	if (tt == "") then
		if (IsValid(self.TooltipGUI)) then
			self.TooltipGUI:Remove()
		end
	end
end

function PANEL:OnCursorEntered()
	local bb = self
	if (self.Tooltip == "" or self.Tooltip == nil) then return end
	self.TooltipGUI = vgui.Create("DLabel")
	table.insert(bKeycardScanner_Tooltips,self.TooltipGUI)
	self.TooltipGUI:SetDrawOnTop(true)
	self.TooltipGUI:SetTextColor(Color(255,255,255))
	self.TooltipGUI:SetFont("bkeycardscanner_16")
	self.TooltipGUI:SetDrawBackground(true)
	self.TooltipGUI:SetContentAlignment(7)
	self.TooltipGUI:SetText(self.Tooltip)
	self.TooltipGUI:SetWide(200)
	self.TooltipGUI:SetTall(ScrH())
	self.TooltipGUI:SetWrap(true)
	self.TooltipGUI.NoPaint = true
	local x,y = gui.MousePos()
	self.TooltipGUI:SetPos(x - (self.TooltipGUI:GetWide() / 2),y + 35)
	function self.TooltipGUI:Paint(w,h)
		if (not IsValid(bb)) then
			self:Remove()
			return
		end
		self:SizeToContentsY()
		if (not self.NoPaint) then
			surface.DisableClipping(true)
			surface.SetDrawColor(0,0,0,250)
			surface.DrawRect(-5,-5,w + 10,h + 10)
		end
		self.NoPaint = false
		local x,y = gui.MousePos()
		self:SizeToContentsY()
		self:SetPos(x - (self:GetWide() / 2),y + 35)
	end
end
function PANEL:OnCursorExited()
	if (IsValid(self.TooltipGUI)) then
		self.TooltipGUI:Remove()
	end
	for _,v in pairs(bKeycardScanner_Tooltips) do
		v:Remove()
	end
end

derma.DefineControl("bKeycardScanner_ListView_Line",nil,PANEL,"DListView_Line")

local PANEL = {}

function PANEL:Init()
	self:SetTextInset(5,0)
end

function PANEL:UpdateColours()
	if (self:GetParent():IsLineSelected()) then
		self:SetTextStyleColor(Color(0,0,0))
		return
	end
	self:SetTextStyleColor(Color(255,255,255))
end

derma.DefineControl("bKeycardScanner_DListViewLabel",nil,PANEL,"DLabel")

local PANEL = {}

function PANEL:Paint(w,h)
	surface.SetDrawColor(Color(26,26,26,self.Alpha))
	surface.DrawRect(0,0,w,h)
end

function PANEL:Init()
	local p = self

	self.Alpha = 255*0.95

	self:SetFocusTopLevel( true )
	self:SetPaintShadow( true )
	self:SetDraggable( true )
	self:SetSizable( false )
	self:SetScreenLock( false )
	self:SetDeleteOnClose( true )
	self:SetMinWidth( 50 )
	self:SetMinHeight( 50 )
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )
	self.m_fCreateTime = SysTime()
	self:DockPadding( 5, 24 + 5, 5, 5 )

	self.close = vgui.Create("bKeycardScanner_DButton",self)
	self.close:SetFont("bkeycardscanner_16")
	self.close:SetSize(24,24)
	self.close:AlignRight(5)
	self.close:AlignTop(5)
	self.close:SetText("X")
	self.close:SetColors(Color(255,75,75),Color(100,0,0),false)
	self.close.BorderThickness = 2
	function self.close:DoClick()
		p:Close()
	end

	self.title = vgui.Create("bKeycardScanner_DLabel",self)
	self.title:SetText("bKeycardScanner")
	self.title:SetFont("bkeycardscanner_20")
	self.title:SizeToContents()
	self.title:CenterHorizontal()
	self.title:AlignTop(5)

	self.btnClose:Remove()
	self.btnMaxim:Remove()
	self.btnMinim:Remove()
	self.lblTitle:Remove()
end

function PANEL:PerformLayout()

	self.title:SizeToContents()
	self.title:CenterHorizontal()
	self.title:AlignTop(5)

	self.close:AlignRight(5)
	self.close:AlignTop(5)

end

function PANEL:ShowCloseButton(show)
	self.close:SetVisible(show)
end

function PANEL:SetTitle(txt)
	self.title:SetText(txt)
	self.title:SizeToContents()
	self.title:CenterHorizontal()
	self.title:AlignTop(5)
end

derma.DefineControl("bKeycardScanner_DFrame",nil,PANEL,"DFrame")
