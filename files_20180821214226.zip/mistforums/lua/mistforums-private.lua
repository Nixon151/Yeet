MistForum.api_key = "gtN1oHX1HrGgWuO0jMbNfPceqVQoGz"
MistForum.api_secret = "RG3PxKwW2LURhKxVS0GOfkkUERcKGM"
MistForum.url = "https://galaxyscp.mistforums.com"
MistForum.community_name = "GalaxyGaming"