--[[---------------------------------------------------------------------------
DarkRP custom jobs
---------------------------------------------------------------------------

This file contains your custom jobs.
This file should also contain jobs from DarkRP that you edited.

Note: If you want to edit a default DarkRP job, first disable it in darkrp_config/disabled_defaults.lua
	Once you've done that, copy and paste the job to this file and edit it.

The default jobs can be found here:
https://github.com/FPtje/DarkRP/blob/master/gamemode/config/jobrelated.lua

For examples and explanation please visit this wiki page:
http://wiki.darkrp.com/index.php/DarkRP:CustomJobFields


Add jobs under the following line:
---------------------------------------------------------------------------]]
TEAM_RECRUIT = DarkRP.createJob("Clone Recruit", {
    color = Color(153, 153, 153, 255),
    model = {"models/player/cr/cr.mdl", "models/reizer_cgi_p2/clone_snow/clone_snow.mdl"},
    description = [[You are a clone recruit for the 101st Regiment.]],
    weapons = {"tfa_swch_dc15a_alt_training"},
    command = "cr",
    max = 0,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "101st Regiment",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_101 = DarkRP.createJob("101st Regiment: Trooper", {
    color = Color(153, 153, 153, 255),
    model = {"models/reizer_cgi_p2/clone_trp/clone_trp.mdl", "models/reizer_cgi_p2/clone_snow/clone_snow.mdl"},
    description = [[You are a clone trooper for the 101st Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "101trp",
    max = 100,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "101st Regiment",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_101 = DarkRP.createJob("101st Regiment: NCO", {
    color = Color(153, 153, 153, 255),
    model = {"models/reizer_cgi_p2/clone_sgt/clone_sgt.mdl", "models/reizer_cgi_p2/clone_snow/clone_snow.mdl"},
    description = [[You are a clone nco for the 101st Regiment.]],
    weapons = {"tfa_dc15a_expanded", "tfa_752_dc15s_expanded", "tfa_sw_repshot", "clone_card_c1"},
    command = "101nco",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "101st Regiment",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_101 = DarkRP.createJob("101st Regiment: Officer", {
    color = Color(153, 153, 153, 255),
    model = {"models/reizer_cgi_p2/clone_cpt/clone_cpt.mdl", "models/reizer_cgi_p2/clone_snow/clone_snow.mdl"},
    description = [[You are a clone officer for the 101st Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "101off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "101st Regiment",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_101 = DarkRP.createJob("101st Regiment: Commander A'den", {
    color = Color(153, 153, 153, 255),
    model = {"models/reizer_cgi_p2/clone_cmd/clone_cmd.mdl", "models/reizer_cgi_p2/clone_snow/clone_snow.mdl"},
    description = [[You are a clone commander for the 101st Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "101cmdr",
    max = 1,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "101st Regiment",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Trooper", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_trp/501_trp.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "501trp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Assault Trooper", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_d1/501_d1.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repshot", "clone_card_c1"},
    command = "501astrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Heavy Trooper", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_d2/501_d2.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "501hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Engineer", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_d3/501_d3.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "501eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(100)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Medic", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_med/501_med.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "501med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Sharpshooter", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_assault/501_assault.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "501shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Elite Sharpshooter [T2]", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_col/501_col.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "tfa_752_dlt19", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "501elshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Pilot", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_pilot/501_pilot.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "501pil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Jet Trooper [T4]", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_jet/501_jet.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "501jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Blaze Trooper [T5]", {
    color = Color(0, 26, 255, 255),
    model = {"models/player/501st/501super.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"flamethrower_basic", "clone_card_c1"},
    command = "501blz",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: ARC Trooper [RNCR Only]", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_arc/501_arc.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone trooper for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "clone_card_c1"},
    command = "501arc",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Officer", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_cpt/501_cpt.mdl", "models/reizer_cgi_p2/501_snow_trp/501_snow_trp.mdl"},
    description = [[You are a clone officer for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "501off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_501 = DarkRP.createJob("501st Legion: Commander Rex", {
    color = Color(0, 26, 255, 255),
    model = {"models/reizer_cgi_p2/501_rex/501_rex.mdl", "models/reizer_cgi_p2/501_snow_cmd/501_snow_cmd.mdl"},
    description = [[You are a clone commander for the 501st Legion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "501cmdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "501st Legion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Trooper", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_trp/212_trp.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "212trp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Combat Trooper", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_maj/212_maj.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repshot", "clone_card_c1"},
    command = "212cmbtrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Heavy Trooper", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_d7/212_d7.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "212hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Engineer", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_guire/212_guire.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "212eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Medic", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_med/212_med.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "212med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Elite Trooper [T2]", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_d1/212_d1.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "clone_card_c1"},
    command = "212eltrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Sharpshooter", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_assault/212_assault.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "212shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Elite Sharpshooter [T2]", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_d6/212_d6.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "clone_card_c1"},
    command = "212elshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Pilot", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_pilot/212_pilot.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15s", "tfa_swch_dc17", "clone_card_c1"},
    command = "212pil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(100)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: ARC Trooper [RNCR Only]", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_pilot/212_pilot.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "clone_card_c1"},
    command = "212arc",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Jet Trooper [T4]", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_jet/212_jet.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "212jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Elite Jet Trooper [T4]", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_jet/212_jet.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "212eljet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Blaze Trooper [T5]", {
    color = Color(189, 150, 14, 255),
    model = {"models/player/212th/212super.mdl"},
    description = [[You are a clone trooper for the 212th Battalion.]],
    weapons = {"flamethrower_basic", "clone_card_c1"},
    command = "212blz",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Officer", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_col/212_col.mdl", "models/reizer_cgi_p2/212_snow_trp/212_snow_trp.mdl"},
    description = [[You are a clone officer for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "212off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_212 = DarkRP.createJob("212th Battalion: Commander Cody", {
    color = Color(189, 150, 14, 255),
    model = {"models/reizer_cgi_p2/212_cody/212_cody.mdl", "models/reizer_cgi_p2/212_snow_cmd/212_snow_cmd.mdl"},
    description = [[You are a clone commander for the 212th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "212cmdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "212th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Trooper", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/nv_2ac/2nd_ac.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "2ndtrp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Medic", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/nv_2ac/2nd_ac.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "2ndmed",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Heavy Trooper", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/nv_2ac/2nd_ac.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_z6", "tfa_swch_dc15s", "clone_card_c1"},
    command = "2ndhvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Elite Trooper [T2]", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/nv_2ac/2nd_ac.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "clone_card_c1"},
    command = "2ndeltrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Sharpshooter", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/youre_welcome_love_delta/2nd_ac_visor.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "2ndshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Elite Sharpshooter [T2]", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/deltas_2nd_ac/2nd_ac_engineer.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "2ndeshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Jet Trooper [T4]", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/deltas_2nd_ac/2nd_ac_jet_troop.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "2ndjet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Officer", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/nv_2ac/2nd_ac.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "2ndoff",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_2NDAB = DarkRP.createJob("2nd Airborne: Commander Barlex", {
    color = Color(255, 138, 0, 255),
    model = {"models/player/deltas_2nd_ac/2nd_ac_visor_up.mdl"},
    description = [[You are a clone trooper for the 2nd Airborne Division.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "2ndcdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "2nd Airborne Division"
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Trooper", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_1/gm_1.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_alphablaster", "clone_card_c1"},
    command = "21trp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Medic", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_10/gm_10.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "21med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Heavy Trooper", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_3/gm_3.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "21hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Engineer", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_1/gm_1.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "21eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Pilot", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/21_pilot/21_pilot.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15s", "tfa_swch_dc17", "clone_card_c1"},
    command = "21pil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Sharpshooter", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_11/gm_11.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "21shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Elite Sharpshooter [T2]", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_8/gm_8.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "21eshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Magma Trooper [T5]", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_7/gm_7.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_dc17", "tfa_swch_alphablaster", "flamethrower_basic", "clone_card_c1"},
    command = "21mag",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Jet Trooper [T4]", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/21_jet/21_jet.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "21jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Elite Jet Trooper [T4]", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/21_d5/21_d5.mdl"},
    description = [[You are a clone trooper for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_dc17", "tfa_dlt19_extended", "weapon_jetpack", "clone_card_c1"},
    command = "21eljet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Officer", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/gm_2/gm_2.mdl"},
    description = [[You are a clone officer for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "21off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_21 = DarkRP.createJob("Galactic Marines: Commander Bacara", {
    color = Color(159, 10, 173, 255),
    model = {"models/reizer_cgi_p2/21_bacara/21_bacara.mdl"},
    description = [[You are a clone commander for the Galactic Marines.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "21cmdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Galactic Marines",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Trooper", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_trooper/gingers_91st_trooper.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "91trp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Heavy Trooper", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_trooper_p2/gingers_91st_trooper_p2.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "91hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Engineer", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_visor_trooper/gingers_91st_visor_trooper.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "91eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(100)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Medic", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_medic/gingers_91st_medic.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "91med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Sharpshooter", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_trooper2/gingers_91st_trooper2.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "91shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Elite Sharpshooter [T2]", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_sniper/gingers_91st_sniper.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "tfa_752_dlt19", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "91elshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Jet Trooper [T4]", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_jet_trooper/gingers_91st_jet_trooper.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "91jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Aerial Recon Trooper [T4]", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_aerial_recon/gingers_91st_aerial_recon.mdl"},
    description = [[You are a clone trooper for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "clone_card_c1"},
    command = "91air",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Officer", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_lieutenant/gingers_91st_lieutenant.mdl"},
    description = [[You are a clone officer for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "91off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_91 = DarkRP.createJob("91st Recon: Commander Neyo", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gingers_91st_neyo/gingers_91st_neyo.mdl"},
    description = [[You are a clone commander for the 91st Recon.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "91cmdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "91st Recon",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Trooper", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_trp/104_trp.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "104trp",
    max= 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Combat Trooper", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_d1/104_d1.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repshot", "clone_card_c1"},
    command = "104cmbtrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Heavy Trooper", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_d2/104_d2.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "104hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Engineer", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_d4/104_d4.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "104eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Medic", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_med/104_med.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "104med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Elite Trooper [T2]", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_d5/104_d5.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "104eltrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Sharpshooter", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_assault/104_assault.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "104shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Elite Sharpshooter [T2]", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_col/104_col.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "104elshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Pilot", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_pilot/104_pilot.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15s", "tfa_swch_dc17", "clone_card_c1"},
    command = "104pil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: ARC Trooper [RNCR Only]", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_arc/104_arc.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "tfa_swch_alphablaster", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "104arc",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Jet Trooper [T4]", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_d5/104_d5.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "104jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Blaze Trooper [T5]", {
    color = Color(130, 130, 130, 255),
    model = {"models/player/wolfpack/wolfsuper.mdl"},
    description = [[You are a clone trooper for the 104th Battalion.]],
    weapons = {"flamethrower_basic", "clone_card_c1"},
    command = "104blz",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Officer", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_maj/104_maj.mdl", "models/reizer_cgi_p2/104_snow_trp/104_snow_trp.mdl"},
    description = [[You are a clone officer for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "104off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_104 = DarkRP.createJob("104th Battalion: Commander Wolffe", {
    color = Color(130, 130, 130, 255),
    model = {"models/reizer_cgi_p2/104_wolf/104_wolf.mdl", "models/reizer_cgi_p2/104_snow_cmd/104_snow_cmd.mdl"},
    description = [[You are a clone commander for the 104th Battalion.]],
    weapons = {"tfa_swch_dc15s", "tfa_swch_dc15s", "clone_card_c3"},
    command = "104cmdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "104th Battalion",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Trooper", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_trp/41_trp.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "41trp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Combat Trooper", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_d1/41_d1.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repshot", "clone_card_c1"},
    command = "41cmbtrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Heavy Trooper", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_d2/41_d2.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "41hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Engineer", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_d3/41_d3.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "41eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Medic", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_med/41_med.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "41med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Elite Trooper [T2]", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_d4/41_d4.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "clone_card_c1"},
    command = "41eltrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Sharpshooter", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_d5/41_d5.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "41shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Elite Sharpshooter [T2]", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_col/41_col.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_dlt19x", "dc15agrapple", "clone_card_c1"},
    command = "41elshp",
    max= 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Pilot", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_pilot/41_pilot.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15s", "tfa_swch_dc17", "clone_card_c1"},
    command = "41pil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: ARC Trooper [RNCR Only]", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_arc/41_arc.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "tfa_swch_alphablaster", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "41arc",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Jet Trooper [T4]", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_d6/41_d6.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "41jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Blaze Trooper [T5]", {
    color = Color(15, 110, 0, 255),
    model = {"models/player/41st/41super.mdl"},
    description = [[You are a clone trooper for the 41st Green Company.]],
    weapons = {"flamethrower_basic", "clone_card_c1"},
    command = "41blz",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Officer", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_maj/41_maj.mdl", "models/reizer_cgi_p2/41_snow_trp/41_snow_trp.mdl"},
    description = [[You are a clone officer for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "41off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_41 = DarkRP.createJob("41st Green Company: Commander Gree", {
    color = Color(15, 110, 0, 255),
    model = {"models/reizer_cgi_p2/41_gree/41_gree.mdl", "models/reizer_cgi_p2/41_snow_cmd/41_snow_cmd.mdl"},
    description = [[You are a clone commander for the 41st Green Company.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "41cmdr",
    max= 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "41st Green Company",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Trooper", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_trp2/327_trp2.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c1"},
    command = "327trp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Combat Trooper", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_trp/327_trp.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repshot", "clone_card_c1"},
    command = "327cmbtrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Heavy Trooper", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_d1/327_d1.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_z6", "clone_card_c1"},
    command = "327hvytrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Engineer", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_d2/327_d2.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "repair_tool", "clone_card_c1"},
    command = "327eng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Medic", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_med/327_med.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "327med",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Elite Trooper [T2]", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_d1/327_d1.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "327eltrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Sharpshooter", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_trp/327_trp.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repsnip", "clone_card_c1"},
    command = "327shp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Elite Sharpshooter [T2]", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_trp/327_trp.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "tfa_sw_dc17dual", "tfa_dlt19x", "clone_card_c1"},
    command = "327elshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Pilot", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_pilot/327_pilot.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15s", "tfa_swch_dc17", "clone_card_c1"},
    command = "327pil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: ARC Trooper [RNCR Only]", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_arc/327_arc.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "tfa_swch_alphablaster", "tfa_sw_dc17dual", "clone_card_c1"},
    command = "327arc",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Jet Trooper [T4]", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_jet/327_jet.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone trooper for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "weapon_jetpack", "clone_card_c1"},
    command = "327jet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Officer", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_d2/327_d2.mdl", "models/reizer_cgi_p2/327_snow_trp/327_snow_trp.mdl"},
    description = [[You are a clone officer for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c2"},
    command = "327off",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_327 = DarkRP.createJob("327th Star Corps: Commander Bly", {
    color = Color(227, 193, 6, 255),
    model = {"models/reizer_cgi_p2/327_bly/327_bly.mdl", "models/reizer_cgi_p2/327_snow_cmd/327_snow_cmd.mdl"},
    description = [[You are a clone commander for the 327th Star Corps.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "clone_card_c3"},
    command = "327cmdr",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "327th Star Corps",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Trooper", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_6/arc_6.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "realistic_hook", "clone_card_c1"},
    command = "rncrtrp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Engineer", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_2/arc_2.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "repair_tool", "realistic_hook", "clone_card_c1"},
    command = "rncreng",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Combat Trooper", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_assault/arc_assault.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "tfa_sw_repshot", "realistic_hook", "weapon_jetpack", "clone_card_c1"},
    command = "rncrcmbt",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Sharpshooter", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_sniper/arc_sniper.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "tfa_sw_repsnip", "realistic_hook", "weapon_jetpack", "clone_card_c1"},
    command = "rncrshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Elite Sharpshooter [T2]", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_sniper/arc_sniper.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "tfa_dlt19x", "realistic_hook", "weapon_jetpack", "clone_card_c1"},
    command = "rncrelshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Heavy", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_cpt/arc_cpt.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "tfa_swch_z6", "realistic_hook", "weapon_jetpack", "clone_card_c1"},
    command = "rncrhvy",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Medic", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_med/arc_med.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_swch_alphablaster", "darkrp_defibrillator", "realistic_hook", "weapon_jetpack", "clone_card_c1"},
    command = "rncrmed",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Pilot", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/clone_pilot_cpt/clone_pilot_cpt.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_dc17", "realistic_hook", "clone_card_c1"},
    command = "rncrpil",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Jet Trooper [T4]", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_trooper/arc_trooper.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_752_dlt19", "tfa_swch_alphablaster", "tfa_sw_dc17dual", "realistic_hook", "weapon_jetpack", "clone_card_c1"},
    command = "rncrjet",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Magma Trooper [T5]", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_dread2/arc_dread2.mdl"},
    description = [[You are a clone arf trooper for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "flamethrower_basic", "tfa_swch_alphablaster", "realistic_hook", "clone_card_c1"},
    command = "rncrmag",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Officer", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/arc_1/arc_1.mdl"},
    description = [[You are a clone officer for the Rancor Battalion.]],
    weapons = {"tfa_swch_alphablaster", "tfa_swch_dc15s", "tfa_sw_dc17dual", "realistic_hook", "clone_card_c2"},
    command = "rncroff",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(250)
        ply:SetHealth(250)
        ply:SetArmor(250)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Commander Colt", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/rancor_colt/rancor_colt.mdl"},
    description = [[You are a clone commander for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_alphablaster", "tfa_swch_dc17", "realistic_hook", "clone_card_c3"},
    command = "rncrcolt",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Commander Havoc", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/rancor_havoc/rancor_havoc.mdl"},
    description = [[You are a clone commander for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_alphablaster", "tfa_swch_dc17", "realistic_hook", "clone_card_c3"},
    command = "rncrhavoc",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_ARC = DarkRP.createJob("Rancor: ARC Commander Blitz", {
    color = Color(255, 0, 30, 255),
    model = {"models/reizer_cgi_p2/rankor_blitz/rancor_blitz.mdl"},
    description = [[You are a clone commander for the Rancor Battalion.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_swch_alphablaster", "tfa_swch_dc17", "realistic_hook", "clone_card_c3"},
    command = "rncrblitz",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "RANCOR",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(250)
        ply:SetHealth(250)
        ply:SetArmor(250)
    end
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Trooper", {
    color = Color(59, 59, 59, 255),
    model = {"models/reizer_cgi_p2/clone_arf/clone_arf.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "realistic_hook", "clone_card_c1"},
    command = "arftrp",
    max = 20,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Medic", {
    color = Color(59, 59, 59, 255),
    model = {"models/reizer_cgi_p2/rancor_arf2/rancor_arf2.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "clone_card_c1"},
    command = "arfmed",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Assault", {
    color = Color(59, 59, 59, 255),
    model = {"models/player/ct/ct.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "realistic_hook", "clone_card_c1"},
    command = "arfass",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Sharpshooter", {
    color = Color(59, 59, 59, 255),
    model = {"models/player/ltn/ltn.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_sw_repsnip", "tfa_swch_dc15s", "realistic_hook", "clone_card_c1"},
    command = "arfshp",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Heavy", {
    color = Color(59, 59, 59, 255),
    model = {"models/player/cpt/cpt.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_swch_z6", "tfa_swch_dc15s", "realistic_hook", "clone_card_c1"},
    command = "arfhvy",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Officer", {
    color = Color(59, 59, 59, 255),
    model = {"models/player/vcmd/vcmd.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "realistic_hook", "clone_card_c2"},
    command = "arfoff",
    max = 10,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_ARF = DarkRP.createJob("Advanced Recon Forces: Commander", {
    color = Color(59, 59, 59, 255),
    model = {"models/player/cmd/cmd.mdl"},
    description = [[You are apart of the Advanced Recon Commando Regiment.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_repshot", "realistic_hook", "clone_card_c3"},
    command = "arfcmd",
    max = 1,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Advanced Recon Forces"
})
TEAM_RC = DarkRP.createJob("Republic Commando: Delta Squad Boss", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_boss_dirty/rc_boss_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "clone_card_c3"},
    command = "rcdboss",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Delta Squad Fixer", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_fixer_dirty/rc_fixer_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "clone_card_c2"},
    command = "rcdfixer",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Delta Squad Scorch", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_scorch_dirty/rc_scorch_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "tfa_detonator", "clone_card_c1"},
    command = "rcdscorch",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Delta Squad Sev", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_sev_dirty/rc_sev_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "clone_card_c1"},
    command = "rcdsev",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Ion Squad Climber", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_ion_leader_clean/rc_ion_leader_clean.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "clone_card_c3"},
    command = "rciclimber",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Ion Squad Trace", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_ion_trooper/rc_ion_trooper.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "clone_card_c2"},
    command = "rcitrace",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Ion Squad Ras", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_ion_trooper2/rc_ion_trooper2.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "tfa_detonator", "clone_card_c1"},
    command = "rciras",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Ion Squad Unnamed", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_ion_trooper3/rc_ion_trooper3.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc15sa", "tfa_sw_repshot", "tfa_dlt19x", "clone_card_c2"},
    command = "rciunnamed",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Omega Squad Niner", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_niner_dirty/rc_niner_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c3", "tfa_sw_repshot"},
    command = "rconiner",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Omega Squad Darman", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_darman_dirty/rc_darman_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c2", "tfa_detonator", "tfa_sw_repshot"},
    command = "rcodarman",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Omega Squad Atin", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_atin_dirty/rc_atin_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c1", "tfa_sw_repshot"},
    command = "rcoatin",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Omega Squad Fi", {
    color = Color(51, 51, 51, 255),
    model = {"models/reizer_cgi_p2/rc_fi_dirty/rc_fi_dirty.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c1", "tfa_sw_repshot"},
    command = "rcofi",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Foxtrot Squad Gregor", {
    color = Color(255, 153, 0, 255),
    model = {"models/synergyroleplay/rcfoxtrotsquad/rcfoxtrotgregor/rcfoxtrotgregor.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c3", "tfa_sw_repshot"},
    command = "rcfgreg",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Foxtrot Squad Officer", {
    color = Color(255, 153, 0, 255),
    model = {"models/synergyroleplay/rcfoxtrotsquad/rcfoxtrottrooper3/rcfoxtrottrooper3.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c2", "tfa_detonator", "tfa_sw_repshot"},
    command = "rcfoff",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Foxtrot Squad Sergeant", {
    color = Color(255, 153, 0, 255),
    model = {"models/synergyroleplay/rcfoxtrotsquad/rcfoxtrottrooper2/rcfoxtrottrooper2.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c1", "tfa_sw_repshot"},
    command = "rcfsgt",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_RC = DarkRP.createJob("Republic Commando: Foxtrot Squad Trooper", {
    color = Color(255, 153, 0, 255),
    model = {"models/synergyroleplay/rcfoxtrotsquad/rcfoxtrottrooper1/rcfoxtrottrooper1.mdl"},
    description = [[You are a Republic Commando.]],
    weapons = {"tfa_swch_dc17m_br", "tfa_swch_dc17m_at", "tfa_swch_dc15sa", "tfa_dlt19x", "clone_card_c1", "tfa_sw_repshot"},
    command = "rcftrp",
    max = 1,
    salary = 100,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Commando",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_COMMAND = DarkRP.createJob("High Command: Defense Regimental Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/gonzo/cgionix/cgionix.mdl"},
    description = [[You are a High Command.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_sw_repshot", "tfa_sw_repsnip", "tfa_swch_z6", "clone_card_c4"},
    command = "defreg",
    max = 1,
    salary = 500,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Clone High Command",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_COMMAND = DarkRP.createJob("High Command: Attack Regimental Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/reizer_cgi_p2/clone_cpt2/clone_cpt2.mdl"},
    description = [[You are a High Command.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_sw_repshot", "tfa_sw_repsnip", "tfa_swch_z6", "clone_card_c4"},
    command = "attreg",
    max = 1,
    salary = 500,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Clone High Command",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_COMMAND = DarkRP.createJob("High Command: Specialized Regimental Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/reizer_cgi_p2/zorg/zorg.mdl"},
    description = [[You are a High Command.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_sw_repshot", "tfa_sw_repsnip", "tfa_swch_z6", "clone_card_c4"},
    command = "specreg",
    max = 1,
    salary = 500,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Clone High Command",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_COMMAND = DarkRP.createJob("High Command: RC Regimental Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/gonzo/starwars/stripeparts.mdl"},
    description = [[You are a High Command.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_sw_repshot", "tfa_sw_repsnip", "tfa_swch_z6", "clone_card_c4"},
    command = "rcreg",
    max = 1,
    salary = 500,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Clone High Command",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_COMMAND = DarkRP.createJob("High Command: Senior Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/gonzo/greynullarc/greynullarc.mdl"},
    description = [[You are a High Command.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_sw_repshot", "tfa_sw_repsnip", "tfa_swch_z6", "clone_card_c4"},
    command = "sencmd",
    max = 7,
    salary = 500,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Clone High Command",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_COMMAND = DarkRP.createJob("High Command: Marshal Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/gonzo/vgclones2/bleach/bleach.mdl"},
    description = [[You are a High Command.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "tfa_sw_dc17dual", "tfa_sw_repshot", "tfa_sw_repsnip", "tfa_swch_z6", "clone_card_c4"},
    command = "mshlcmdr",
    max = 5,
    salary = 500,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Clone High Command",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Trooper", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_trooper/deltas_ks_trooper.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "realrbn_tazer_mr", "weapon_cuff_guard", "arrest_stick", "clone_card_c1"},
    command = "sectrp",
    max = 10,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Sharpshooter", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_sharpshooter/deltas_ks_sharpshooter.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_sw_repsnip", "tfa_swch_dc15s", "realrbn_tazer_mr", "weapon_cuff_guard", "arrest_stick", "clone_card_c1"},
    command = "secshp",
    max = 10,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Medic", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_medic/deltas_ks_medic.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "darkrp_defibrillator", "weapon_bactainjector", "weapon_cuff_guard", "arrest_stick", "realrbn_tazer_mr", "clone_card_c1"},
    command = "secmed",
    max = 10,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Elite Jet Trooper [T3]", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_jet/deltas_ks_jet_elite.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "realrbn_tazer_mr", "weapon_cuff_guard", "arrest_stick", "weapon_jetpack", "clone_card_c1"},
    command = "secjet",
    max = 10,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Aerial Unit", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_aerial_recon/deltas_ks_aerial_recon.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_swch_dc15a_scoped", "tfa_swch_dc15s", "realrbn_tazer_mr", "weapon_cuff_guard", "arrest_stick", "weapon_jetpack", "clone_card_c1"},
    command = "secaerial",
    max = 10,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Officer", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_captain/deltas_ks_captain.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "realrbn_tazer_mr", "weapon_cuff_guard", "arrest_stick", "clone_card_c2"},
    command = "secoff",
    max = 10,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_SEC = DarkRP.createJob("Coruscant Guard: Commander", {
    color = Color(255, 0, 0, 255),
    model = {"models/player/deltas_ks_commander/deltas_ks_commander.mdl"},
    description = [[You are apart of the kamino security.]],
    weapons = {"tfa_swch_dc15a", "tfa_swch_dc15s", "realrbn_tazer_mr", "weapon_cuff_guard", "arrest_stick", "clone_card_c3"},
    command = "seccmdr",
    max = 1,
    salary = 150,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Coruscant Guard",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Midshipman [T2]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_male_09.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navalmid",
    max = 30,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Sublieutenant [T2]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_male_08.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navalsublt",
    max = 20,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Lieutenant [T2]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_male_07.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navallt",
    max = 20,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Captain [T2]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_male_06.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navalcpt",
    max = 15,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Commodore [T2]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_male_05.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navalcomm",
    max = 10,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Rear Admiral [T2]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_hawke.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navalrearadm",
    max = 1,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Vice Admiral [T3]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_male_02.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navalviceadm",
    max = 1,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_NAVAL = DarkRP.createJob("Republic Navy: Admiral [T4]", {
    color = Color(173, 173, 173, 255),
    model = {"models/player/scifi_bill.mdl"},
    description = [[You are a Republic Naval.]],
    weapons = {"tfa_swch_dc17", "clone_card_c3navy"},
    command = "navaladm",
    max = 1,
    salary = 160,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Republic Navy",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_CIS = DarkRP.createJob("Event - CIS Army: B1 Battle Droid [T1]", {
    color = Color(158, 0, 0, 255),
    model = {"models/tfa/comm/gg/pm_sw_droid_b1.mdl"},
    description = [[You are apart of the CIS Army.]],
    weapons = {"e5_blaster_rifle"},
    command = "b1drd",
    max = 35,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Event - CIS Army",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_CIS = DarkRP.createJob("Event - CIS Army: B1 Battle Droid Commander [T2]", {
    color = Color(158, 0, 0, 255),
    model = {"models/tfa/comm/gg/pm_sw_droid_commander.mdl"},
    description = [[You are apart of the CIS Army.]],
    weapons = {"e5_blaster_rifle"},
    command = "b1drdcmdr",
    max = 10,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Event - CIS Army",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_CIS = DarkRP.createJob("Event - CIS Army: B2 Super Battle Droid [T3]", {
    color = Color(158, 0, 0, 255),
    model = {"models/tfa/comm/gg/pm_sw_droid_b2.mdl"},
    description = [[You are apart of the CIS Army.]],
    weapons = {"b2_wrist_blaster"},
    command = "b2drd",
    max = 35,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Event - CIS Army",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_CIS = DarkRP.createJob("Event - CIS Army: Commando Droid [T3]", {
    color = Color(158, 0, 0, 255),
    model = {"models/tfa/comm/gg/pm_sw_droid_commando.mdl"},
    description = [[You are apart of the CIS Army.]],
    weapons = {"e5_commando_blaster", "realistic_hook"},
    command = "cmndodrd",
    max = 35,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Event - CIS Army",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(100)
        ply:SetHealth(100)
        ply:SetArmor(0)
    end
})
TEAM_CIS = DarkRP.createJob("Event - CIS Army: General Grievous [T3]", {
    color = Color(158, 0, 0, 255),
    model = {"models/tfa/comm/gg/pm_sw_grievous.mdl"},
    description = [[You are apart of the CIS Army.]],
    weapons = {"weapon_lightsaber"},
    command = "grievous",
    max = 1,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Event - CIS Army",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(8000)
        ply:SetHealth(8000)
        ply:SetArmor(0)
    end
})
TEAM_CIS = DarkRP.createJob("Event - CIS Army: Count Dooku [T5]", {
    color = Color(158, 0, 0, 255),
    model = {"models/tfa/comm/gg/pm_sw_dooku.mdl"},
    description = [[You are apart of the CIS Army.]],
    weapons = {"weapon_lightsaber"},
    command = "dooku",
    max = 1,
    salary = 0,
    admin = 0,
    vote = false,
    hasLicense = false,
    candemote = false,
    category = "Event - CIS Army",
    PlayerSpawn = function(ply)
        ply:SetMaxHealth(8000)
        ply:SetHealth(8000)
        ply:SetArmor(0)
    end
})
--[[---------------------------------------------------------------------------
Define which team joining players spawn into and what team you change to if demoted
---------------------------------------------------------------------------]]
GAMEMODE.DefaultTeam = TEAM_RECRUIT


--[[---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------]]
GAMEMODE.CivilProtection = {
}

--[[---------------------------------------------------------------------------
Jobs that are hitmen (enables the hitman menu)
---------------------------------------------------------------------------]]