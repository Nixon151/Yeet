--[[-----------------------------------------------------------------------
Categories
---------------------------------------------------------------------------
The categories of the default F4 menu.

Please read this page for more information:
http://wiki.darkrp.com/index.php/DarkRP:Categories

In case that page can't be reached, here's an example with explanation:

DarkRP.createCategory{
    name = "Citizens", -- The name of the category.
    categorises = "jobs", -- What it categorises. MUST be one of "jobs", "entities", "shipments", "weapons", "vehicles", "ammo".
    startExpanded = true, -- Whether the category is expanded when you open the F4 menu.
    color = Color(0, 107, 0, 255), -- The color of the category header.
    canSee = function(ply) return true end, -- OPTIONAL: whether the player can see this category AND EVERYTHING IN IT.
    sortOrder = 100, -- OPTIONAL: With this you can decide where your category is. Low numbers to put it on top, high numbers to put it on the bottom. It's 100 by default.
}


Add new categories under the next line!
---------------------------------------------------------------------------]]
--[[-----------------------------------------------------------------------
Categories
---------------------------------------------------------------------------
The categories of the default F4 menu.

Please read this page for more information:
http://wiki.darkrp.com/index.php/DarkRP:Categories

In case that page can't be reached, here's an example with explanation:

DarkRP.createCategory{
    name = "Citizens", -- The name of the category.
    categorises = "jobs", -- What it categorises. MUST be one of "jobs", "entities", "shipments", "weapons", "vehicles", "ammo".
    startExpanded = true, -- Whether the category is expanded when you open the F4 menu.
    color = Color(0, 107, 0, 255), -- The color of the category header.
    canSee = function(ply) return true end, -- OPTIONAL: whether the player can see this category AND EVERYTHING IN IT.
    sortOrder = 100, -- OPTIONAL: With this you can decide where your category is. Low numbers to put it on top, high numbers to put it on the bottom. It's 100 by default.
}


Add new categories under the next line!
---------------------------------------------------------------------------]]
DarkRP.createCategory{
    name = "101st Regiment",
    categorises = "jobs",
    startExpanded = false,
    color = Color(153, 153, 153, 255),
    canSee = function(ply) return true end,
    sortOrder = 1
}
DarkRP.createCategory{
    name = "501st Legion",
    categorises = "jobs",
    startExpanded = false,
    color = Color(0, 26, 255, 255),
    canSee = function(ply) return true end,
    sortOrder = 2
}
DarkRP.createCategory{
    name = "212th Battalion",
    categorises = "jobs",
    startExpanded = false,
    color = Color(189, 150, 14, 255),
    canSee = function(ply) return true end,
    sortOrder = 3
}
DarkRP.createCategory{
    name = "2nd Airborne Division",
    categorises = "jobs",
    startExpanded = false,
    color = Color(189, 150, 14, 255),
    canSee = function(ply) return true end,
    sortOrder = 4
}
DarkRP.createCategory{
    name = "Galactic Marines",
    categorises = "jobs",
    startExpanded = false,
    color = Color(159, 10, 173, 255),
    canSee = function(ply) return true end,
    sortOrder = 5
}
DarkRP.createCategory{
    name = "91st Recon",
    categorises = "jobs",
    startExpanded = false,
    color = Color(255, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 6
}
DarkRP.createCategory{
    name = "104th Battalion",
    categorises = "jobs",
    startExpanded = false,
    color = Color(130, 130, 130, 255),
    canSee = function(ply) return true end,
    sortOrder = 7
}
DarkRP.createCategory{
    name = "41st Green Company",
    categorises = "jobs",
    startExpanded = false,
    color = Color(12, 87, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 8
}
DarkRP.createCategory{
    name = "327th Star Corps",
    categorises = "jobs",
    startExpanded = false,
    color = Color(227, 193, 6, 255),
    canSee = function(ply) return true end,
    sortOrder = 9
}
DarkRP.createCategory{
    name = "RANCOR",
    categorises = "jobs",
    startExpanded = false,
    color = Color(255, 0, 30, 255),
    canSee = function(ply) return true end,
    sortOrder = 10
}
DarkRP.createCategory{
    name = "Advanced Recon Forces",
    categorises = "jobs",
    startExpanded = false,
    color = Color(59, 59, 59, 255),
    canSee = function(ply) return true end,
    sortOrder = 11
}
DarkRP.createCategory{
    name = "Republic Commando",
    categorises = "jobs",
    startExpanded = false,
    color = Color(51, 51, 51, 255),
    canSee = function(ply) return true end,
    sortOrder = 12
}
DarkRP.createCategory{
    name = "Clone High Command",
    categorises = "jobs",
    startExpanded = false,
    color = Color(255, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 13
}
DarkRP.createCategory{
    name = "Coruscant Guard",
    categorises = "jobs",
    startExpanded = false,
    color = Color(255, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 14
}
DarkRP.createCategory{
    name = "Republic Navy",
    categorises = "jobs",
    startExpanded = false,
    color = Color(173, 173, 173, 255),
    canSee = function(ply) return true end,
    sortOrder = 15
}
DarkRP.createCategory{
    name = "Event - CIS Army",
    categorises = "jobs",
    startExpanded = false,
    color = Color(158, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 16
}
DarkRP.createCategory{
    name = "Custom Classes",
    categorises = "jobs",
    startExpanded = false,
    color = Color(158, 0, 0, 255),
    canSee = function(ply) return true end,
    sortOrder = 17
}