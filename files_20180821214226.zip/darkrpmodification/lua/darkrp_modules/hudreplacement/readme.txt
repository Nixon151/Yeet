--[[---------------------------------------------------------------------------
---------------------------------------------------------------------------
Custom F4 Menu
---------------------------------------------------------------------------
---------------------------------------------------------------------------]]

This is an example addon that allows you to replace the HUD entirely or just parts of it.
It has code for a VERY simple HUD, as it's just to show how it works.

It does however, have code that hides parts of the default DarkRP HUD.
This might be interesting when you have your own HUD that you want to import.
