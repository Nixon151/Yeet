# INSTALLATION
This is an addon NOT A darkrp_modification module so PLEASE DON'T PUT IT IN THE darkrp_modification folder.
This goes in garrysmod/addons and is a stand alone addon.

# CONFIGURATION
At the moment there are no configuration options. I plan to add these in a future update.
