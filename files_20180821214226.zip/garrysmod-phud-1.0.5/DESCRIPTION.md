# Poly HUD
#### by thelastpenguin

PolyHUD is based on a geometric design fitting together skewed parallelograms, pentagons, and rectangles into an interesting and visually pleasing puzzle creating a nice looking, clean, and functional HUD with a touch of elegance that comes from attention to detail. 

PolyHUD works great with any DarkRP UI scheme especially minimal menu's. It is also themed perfectly to go along with my companion script (https://scriptfodder.com/scripts/view/1527)[Tri Panel F4 Menu]

# FEATURES
 - agenda display
 - player info display
 - health, money, job, armor, salary
 - blurred UI elements and polygons
 - avatar icon in bottom left

# INSTALLATION
 - this is not a darkrp modification, it is a standalone addon.
 - place the addon file into garrysmod/addons/ and it will load with darkrp 
 - DarkRP 2.5.0 is the minimum supported version of darkrp. 