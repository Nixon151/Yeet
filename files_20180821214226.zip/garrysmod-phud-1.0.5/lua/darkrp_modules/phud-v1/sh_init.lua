phud = { }
phud.noop = function() end
phud.include_sv = SERVER and include or phud.noop
phud.include_cl = SERVER and AddCSLuaFile or include
phud.include_sh = function(...)
  phud.include_cl(...)
  return phud.include_sv(...)
end
phud.include_sh('phud/init_sh.lua')
return concommand.Add((CLIENT and 'phud_reload_cl' or 'phud_reload_sv'), function()
  return phud.include_sh('darkrp_modules/phud-v1/sh_init.lua')
end)
