
--[[
You can now allow only certain jobs to bail players out of jail
You can now disable confiscating weapons given through jobs
Unarresting/arresting now calls DarkRPs original hooks
Fixed issue with not being able to confiscate weapons from itemstore inventory
Added support for DConfig (Not tested, but should work fine)

Configs added:
BailJobs
RestrictBailing
AllowConfiscatingJobWeapons
]]
RHandcuffsConfig = RHandcuffsConfig or {}

--Contact me on SF for help to translate
--Languages available:
--[[
Chinese
Danish
Dutch
English
French
German
Korean
Norwegian
Polish
Russian
]]
RHandcuffsConfig.LanguageToUse = "English"
 
RHandcuffsConfig.JailerModel = "models/player/Group01/Female_01.mdl"
RHandcuffsConfig.JailerText = "Jailer"
 
RHandcuffsConfig.BailerModel = "models/Barney.mdl"
RHandcuffsConfig.BailerText = "Bailer"
//Restrict bailing to specific jobs?
RHandcuffsConfig.RestrictBailing = false

RHandcuffsConfig.CuffSound = "weapons/357/357_reload1.wav"
 
//The bail price for each year so -> YEARS*ThisConfig, so 10 years = 5000 in this case
RHandcuffsConfig.BailPricePerYear = 500
//How many years(minutes) can a player be arrested for?
RHandcuffsConfig.MaxJailYears = 10
//What it displays as, default is years
RHandcuffsConfig.JailAmountType = "Years"
//How long it takes to lockpick the cuffs
RHandcuffsConfig.CuffPickTime = 15
//How long it takes to cuff someone
RHandcuffsConfig.CuffTime = 2
//Displays if player is cuffed overhead while aiming at him
RHandcuffsConfig.DisplayOverheadCuffed = false
//Calculates Movement/Penalty, so 2 would make player move half as fast
//Moving penalty while cuffed
RHandcuffsConfig.RestrainedMovePenalty = 3
//Moving penalty while dragging
RHandcuffsConfig.DraggingMovePenalty = 3
//Setting this to true will cause the system to bonemanipulate clientside, might cause sync issues but won't require you to install all playermodels on the server
RHandcuffsConfig.BoneManipulateClientside = false
//Range for cuffing
RHandcuffsConfig.CuffRange = 75
//Range while dragging, if player is too far away the dragging will cancel
RHandcuffsConfig.DragMaxRange = 175
//Maximum of velocity for dragging (raise if dragging is slow)
RHandcuffsConfig.DragMaxForce = 30
//Lower this to raise the velocity of dragging (lower if dragging is slow)
RHandcuffsConfig.DragRangeForce = 100
//Does the player has to be cuffed in order to arrest him?
RHandcuffsConfig.RestrainArrest = true
//Can only arrest players through the jailer NPC
RHandcuffsConfig.NPCArrestOnly = true
//Should the player stay cuffed after arrested?
RHandcuffsConfig.RestrainOnArrest = true
//Cuffs must be removed before you can unarrest if this is set to true
RHandcuffsConfig.UnarrestMustRemoveCuffs = true
//Give rewards when successfully arrested someone?
RHandcuffsConfig.ArrestReward = true
//Reward amount
RHandcuffsConfig.ArrestRewardAmount = 250
//Allow to confiscate weapons given through job?
RHandcuffsConfig.AllowConfiscatingJobWeapons = true
//Reward for each weapon
RHandcuffsConfig.ConfiscateRewardAmount = 250
//Reward for each item
RHandcuffsConfig.ConfiscateItemRewardAmount = 150
//Sets players to a specific team when arrested
RHandcuffsConfig.SetTeamOnArrest = false
//Players can't press E on anything while cuffed
RHandcuffsConfig.DisableUseOnRestrain = true
--[[
1 = Only cuffing player can drag
2 = Only jobs in the Whitelisted jobs can drag
3 = Anyone can drag
]]
RHandcuffsConfig.DraggingPermissions = 1
//Key to drag a player
//https://wiki.garrysmod.com/page/Enums/IN
RHandcuffsConfig.KEY = IN_USE
 
RHandcuffsConfig.SurrenderEnabled = true
//All keys can be found here -> https://wiki.garrysmod.com/page/Enums/KEY
//Key for surrendering
RHandcuffsConfig.SurrenderKey = KEY_T
//You can't surrender while holding these weapons 
RHandcuffsConfig.SurrenderWeaponWhitelist = {
["weapon_arc_phone"] = true,
}
//Disables drawing player shadow
//Only use this if the shadows are causing issues
//This is a temp fix, will be fixed in the future
RHandcuffsConfig.DisablePlayerShadow = false

//Disable confiscation system (both for itemstore and weapons)
RHandcuffsConfig.DisableConfiscations = false
//If itemstore is installed, should confiscating illegal items be enabled?
RHandcuffsConfig.ItemStoreIllegalItemsEnabled = true
//Items that are illegal, defined by the entity class
RHandcuffsConfig.ItemStoreIllegalItems = {
["money_printer"] = true,
["weapon_ak472"] = true,
}
RHandcuffsConfig.BlackListedWeapons = {
["gmod_tool"] = true,
["weapon_keypadchecker"] = true,
["vc_wrench"] = true,
["vc_jerrycan"] = true,
["vc_spikestrip_wep"] = true,
["laserpointer"] = true,
["remotecontroller"] = true,
["idcard"] = true,
["pickpocket"] = true,
["keys"] = true,
["pocket"] = true,
["driving_license"] = true,
["firearms_license"] = true,
["weapon_physcannon"] = true,
["gmod_camera"] = true,
["weapon_physgun"] = true,
["weapon_r_restrained"] = true,
["tbfy_surrendered"] = true,
["weapon_r_cuffed"] = true,
["collections_bag"] = true,
["weapon_fists"] = true,
["weapon_arc_atmcard"] = true,
["itemstore_pickup"] = true,
["weapon_checker"] = true,
["driving_license_checker"] = true,
["fine_list"] = true,
["weapon_r_handcuffs"] = true,
["door_ram"] = true,
["med_kit"] = true,
["stunstick"] = true,
["arrest_stick"] = true,
["unarrest_stick"] = true,
["weaponchecker"] = true,
}
//Set this to true if you wanna restrict the cuffs use to only specific jobs
RHandcuffsConfig.RestrictCuffsToWhitelist = false
 
//Add all female models here or the handcuffs positioning will be weird
//It's case sensitive, make sure all letters are lowercase
RHandcuffsConfig.FEMALE_MODELS = {
    "models/player/group01/female_01.mdl",
    "models/player/group01/female_02.mdl",
    "models/player/group01/female_03.mdl",
    "models/player/group01/female_04.mdl",
    "models/player/group01/female_05.mdl", 
    "models/player/group01/female_06.mdl",
    "models/player/group03/female_01.mdl",
    "models/player/group03/female_02.mdl",
    "models/player/group03/female_03.mdl",
    "models/player/group03/female_04.mdl",
    "models/player/group03/female_05.mdl", 
    "models/player/group03/female_06.mdl",
}

function RHC_InitJobsConfig()
timer.Simple(3, function() 
	//The team it sets on player during jailtime if enabled
    RHandcuffsConfig.ArrestTeam = TEAM_GANG
	//Jobs that can use the cuffs if the cuffs is restricted
	RHandcuffsConfig.WhitelistedJobs = {
		[TEAM_POLICE] = true,
		[TEAM_CHIEF] = true,
	}
	//Jobs that can't be cuffed
	RHandcuffsConfig.ImmuneJobs = {
		[TEAM_POLICE] = true,
		[TEAM_CHIEF] = true,
		[TEAM_MAYOR] = true,
	}
	//Jobs that are allowed to bail out players from jail
	RHandcuffsConfig.BailJobs = {
		[TEAM_POLICE] = true,
		[TEAM_CHIEF] = true,
		[TEAM_MAYOR] = true,
	}	
end)
end

hook.Add("DarkRPFinishedLoading", "RHC_InitJobs", function()
    if DCONFIG then
		hook.Add("DConfigDataLoaded", "RHC_InitJobs", RHC_InitJobsConfig)
	elseif ezJobs then
        hook.Add("ezJobsLoaded", "RHC_InitJobs", RHC_InitJobsConfig)
    else
        hook.Add("loadCustomDarkRPItems", "RHC_InitJobs", RHC_InitJobsConfig)
    end
end)