
for k, v in pairs(file.Find("tbfy_rhandcuffs/languages/*.lua","LUA")) do 
	include("tbfy_rhandcuffs/languages/" .. v);
	if SERVER then
		AddCSLuaFile("tbfy_rhandcuffs/languages/" .. v);
	end
end
