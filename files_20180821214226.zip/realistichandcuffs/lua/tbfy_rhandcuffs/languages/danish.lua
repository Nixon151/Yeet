//Translated by: Happy Blotter og hul i l�gposen http://steamcommunity.com/profiles/76561198125716412/
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["Danish"] = {
CuffedBy = "Du er blevet sat i h�ndjern af: %s",
Cuffer = "Du har nu sat h�ndjern p� %s.",
ReleasedBy = "Du er nu blevet l�sladt af: %s",
Releaser = "Du har nu l�sladt %s.",
 
CantEnterVehicle = "Du kan ikke stige ind i bilen, n�r du er l�nket!",
CantLeaveVehicle = "Du kan ikke stige ud af bilen, n�r du er l�nket!",
CantSpawnProps = "Du kan ikke s�tte props, n�r du er l�nket!",
CantChangeTeam = "Du kan ikke skifte team, n�r du er l�nket!.",
CantSwitchSeat = "Du kan ikke skifte s�de, n�r du er l�nket!",
 
ConfiscateReward = "Du blev bel�nnet med $%s for at konfiskere et v�ben.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "Du blev bel�nnet med $%s for at arrestere %s.",
AlreadyArrested = "Denne spiller er allerede arresteret!",
MustBeCuffed = "Spilleren skal v�re l�nket f�r du kan arrestere ham!",
ReqLockpick = "Lockpick h�ndjernet, for at kunne l�slade denne spiller!",
 
PlayerPutInDriver = "Player was put in driver seat.",
CantCuffRestrained = "Du kan ikke l�nke en tilbageholdt spiller.",
NoSeats = "Ingen s�der til r�dighed!",
CuffingText = "L�nker %s",
TazedPlayer = "Elektrificeret spiller",
 
CuffedText = "Du er l�nket!",
SurrenderedText = "Du har overgivet dig selv!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}
