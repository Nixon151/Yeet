﻿//Translated by Anthony Fuller http://steamcommunity.com/id/anthonyfuller
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["Polish"] = {
CuffedBy = "Zostałeś ciśnięty przez: %s",
Cuffer = "Zręcznie machnąłeś %s.",
ReleasedBy = "Zostałeś zwolniony przez: %s",
Releaser = "Udało Ci się wydać %s.",
 
CantEnterVehicle = "Nie można wsiąść do pojazdu, gdy jest cuff!",
CantLeaveVehicle = "Nie możesz opuścić samochodu, bo masz mankiet!",
CantSpawnProps = "Nie możesz spawnować rekwizytów, gdy ciuchy!",
CantChangeTeam = "Nie można zmienić zespołu podczas mankiet.",
CantSwitchSeat = "Nie można zmieniać miejsc siedzących podczas manewr.",
 
ConfiscateReward = "Zostałeś nagrodzony $%s za konfiskatę broni.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "Zostałeś nagrodzony $%s za aresztowanie %s.",
AlreadyArrested = "Ten gracz został już aresztowany!",
MustBeCuffed = "Gracz musi być kajdany, aby zostać aresztowany!",
ReqLockpick = "Lockpick mankiety, aby nie poruszać tego odtwarzacza!",

PlayerPutInDriver = "Player was put in driver seat.",
CantCuffRestrained = "Nie możesz zapiąć powściągliwego gracza.",
NoSeats = "Brak miejsc!",
CuffingText = "Cuffing %s",
TazedPlayer = "Odtwarzacz podparty",
 
CuffedText = "Jesteś spięty!",
SurrenderedText = "Zrzekł się!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}