//Translated by: Lobo(http://steamcommunity.com/id/LoboSolitario1211/ )
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["Spanish"] = {
CuffedBy = "Has sido esposado por: %s",
Cuffer = "Esposaste correctamente a %s.",
ReleasedBy = "Te ha desatado: %s",
Releaser = "Desataste correctamente a %s.",

CantEnterVehicle = "¡No puedes entrar a un vehículo estando esposado!",
CantLeaveVehicle = "¡No puedes salirte del vehículo porque estás esposado!",
CantSpawnProps = "¡No puedes spawnear props esposado!",
CantChangeTeam = "No puedes cambiarte mientras estás esposado.",
CantSwitchSeat = "No puedes cambiarte de asiento estando esposado.",

ConfiscateReward = "Fuiste recompensado por $%s por confiscar un arma.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "Fuiste recompensado por $%s por arrestar a %s.",
AlreadyArrested = "¡Este jugador está ya arrestado!",
MustBeCuffed = "El jugador debe de estar esposado para poder arrestarle!",
ReqLockpick = "Debes forzar la cerradura para soltar a este hombre!",

PlayerPutInDriver = "El jugador se puso en el asiento del conductor.",
CantCuffRestrained = "No puedes esposar a un jugador que se encuentra ya esposado.",
NoSeats = "Sin asientos disponibles!",
CuffingText = "Esposando a %s",
TazedPlayer = "Jugador taseado",

CuffedText = "Estás esposado!",
SurrenderedText = "Te has rendido!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}