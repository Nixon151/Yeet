//Translated by Das Ente https://steamcommunity.com/id/dasentlein/
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["Korean"] = {
CuffedBy = "%s님이 당신에게 수갑을 채웠습니다.",
Cuffer = "%s님에게 수갑을 채웠습니다.",
ReleasedBy = "%s님이 당신의 수갑을 풀었습니다.",
Releaser = "%s님의 수갑을 풀었습니다.",
 
CantEnterVehicle = "수갑이 채워져있어 차에 탈 수 없습니다!",
CantLeaveVehicle = "수갑이 채워져있어 차에서 내릴 수 없습니다!",
CantSpawnProps = "수갑이 채워져있어 프롭을 소환할 수 없습니다!",
CantChangeTeam = "수갑이 채워져있어 직업을 변경할 수 없습니다!",
CantSwitchSeat = "수갑이 채워져있어 좌석을 이동할 수 없습니다!",
 
ConfiscateReward = "무기를 압수한 보상으로 $%d를 받았습니다.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "다음의 범죄자를 체포한 보상으로 $%s를 받았습니다: %s",
AlreadyArrested = "이 플레이어는 이미 체포되었습니다!",
MustBeCuffed = "플레이어를 체포하려면 먼저 수갑을 채워야합니다!",
ReqLockpick = "문따개로 수갑을 풀어 감옥에서 꺼낼 수 있습니다!",
 
PlayerPutInDriver = "플레이어가 운전석에 앉았습니다.",
CantCuffRestrained = "이미 수갑이 채워져있습니다.",
NoSeats = "좌석이 없습니다!",
CuffingText = "%s에게 수갑을 채우는 중",
TazedPlayer = "지친 플레이어",
 
CuffedText = "수갑이 채워졌습니다!",
SurrenderedText = "항복했습니다!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}