//Translated by Lenny https://steamcommunity.com/id/LennySwenni/
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["Norwegian"] = {
CuffedBy = "Du har blitt satt i h�ndjern: %s",
Cuffer = "Du har n� satt h�ndjern p� %s.",
ReleasedBy = "Du holder p� � bli l�slatt av: %s",
Releaser = "Du har blitt satt fri av: %s.",

CantEnterVehicle = "Du kan ikke g� inn i biler n�r du er i h�ndjern",
CantLeaveVehicle = "Du kan ikke g� ut av bilen n�r du er i h�ndjern",
CantSpawnProps = "Du kan ikke plassere props n�r du er i h�ndjern!",
CantChangeTeam = "Du kan ikke bytte lag n�r du er i h�ndjern.",
CantSwitchSeat = "Du kan ikke skifte sete n�r du er i h�ndjern",

ConfiscateReward = "Du ble bel�nnet med $%s for � konfiskere et v�pen.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "Du ble bel�nnet med $%s for � arrestere %s.",
AlreadyArrested = "Denne spiller er allerede arrestert!",
MustBeCuffed = "Spilleren m� v�re i h�ndjern f�r du kan arrestere ham!",
ReqLockpick = "Du m� lockpicke h�ndjerne for � slippe l�s denne spilleren!",

PlayerPutInDriver = "Player was put in driver seat.",
CantCuffRestrained = "Du kan ikke lenke en tilbakeholdt spiller.",
NoSeats = "Ingen seter til tilgjengelige!",
CuffingText = "H�ndjern %s",
TazedPlayer = "Eliktriserer spiller",

CuffedText = "Du har blitt puttet i h�ndjern!",
SurrenderedText = "Du har overgivet deg selv!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}