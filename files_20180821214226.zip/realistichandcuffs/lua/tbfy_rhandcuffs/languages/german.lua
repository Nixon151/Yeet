//Translated by phynx (https://steamcommunity.com/profiles/76561198040343084 )
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["German"] = {
CuffedBy = "Du wurdest von %s festgenommen",
Cuffer = "Du hast %s festgenommen.",
ReleasedBy = "Du wurdest von %s freigelassen",
Releaser = "Du hast %s freigelassen.",
 
CantEnterVehicle = "Du kannst nicht in ein Fahrzeug einsteigen w�hrend du Handschellen an hast!",
CantLeaveVehicle = "Du bist verhaftet und kannst das Auto nicht verlassen!",
CantSpawnProps = "Du kannst w�hrend du festgenommen bist keine Props spawnen!",
CantChangeTeam = "Du kannst den Job nicht wechseln w�hrend du festgenommen bist.",
CantSwitchSeat = "Du kannst w�hrend du festgenommen bist deinen Sitzplatz nicht �ndern.",
 
ConfiscateReward = "Du hast %s� f�r das konfiszieren einer Waffe erhalten.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "Du hast %s� f�r die Festnahme von %s erhalten.",
AlreadyArrested = "Dieser Spieler ist bereits festgenommen!",
MustBeCuffed = "Du musst den Spieler verhaften!",
ReqLockpick = "Knacke das Schloss der Handschellen um den Spieler freizulassen!",

PlayerPutInDriver = "Player was put in driver seat.",
CantCuffRestrained = "Du kannst keinen gefesselten Spieler festnehmen.",
NoSeats = "Keine Sitzpl�tze!",
CuffingText = "%s festnehmen",
TazedPlayer = "Spieler getazerd",
 
CuffedText = "Du bist festgenommen!",
SurrenderedText = "Du gibst auf!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}