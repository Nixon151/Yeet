//Translated by: iFocus https://steamcommunity.com/id/ifocus1337/
RHandcuffsConfig.Language =  RHandcuffsConfig.Language or {}
RHandcuffsConfig.Language["Russian"] = {
CuffedBy = "Вы были закованы: %s",
Cuffer = "Вы успешно заковали %s.",
ReleasedBy = "Вы были успешно освобождены: %s",
Releaser = "Вы успешно освободили %s.",

CantEnterVehicle = "Вы не можете войти в машину пока вы в наручниках!",
CantLeaveVehicle = "Вы не можете выйти из машины пока вы в наручниках!",
CantSpawnProps = "Вы не можете спавнить пропы пока вы в наручниках!",
CantChangeTeam = "Вы не можете сменить профессию пока вы в наручниках.",
CantSwitchSeat = "Вы не можете пересесть пока вы в наручниках.",

ConfiscateReward = "Вы получили $%s за конфискованное оружие.",
ConfiscateRewardItem = "You were rewarded $%s for confiscating a %s.",
ArrestReward = "Вы получили $%s за арест %s.",
AlreadyArrested = "Этот игрок уже арестован!",
MustBeCuffed = "Игрок должен находиться в наручниках, чтобы вы могли его арестовать!",
ReqLockpick = "Взломайте наручники чтобы освободить этого игрока!!",

PlayerPutInDriver = "Player was put in driver seat.",
CantCuffRestrained = "Вы не можете заковать игрока, который в наручниках.",
NoSeats = "Все места заняты!",
CuffingText = "Заковываем %s",
TazedPlayer = "Ошеломленный игрок",

CuffedText = "Вы в наручниках!",
SurrenderedText = "Вы сдались!",
NotAllowedToUse = "This job is not allowed to use the handcuffs!",
CantChangeTeamArrested = "Can't change team while jailed.",
UnArrested = "You were unarrested by %s.",
UnArrester = "You unarrested %s.",
}