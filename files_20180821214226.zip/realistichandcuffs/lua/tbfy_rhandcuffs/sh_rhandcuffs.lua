
local PLAYER = FindMetaTable( "Player" )
RHC_ArrestedPlayers = RHC_ArrestedPlayers or {}

function PLAYER:RHC_IsArrested()
	if RHC_ArrestedPlayers[self:SteamID()] then
		return true
	else
		return false
	end
end

function PLAYER:RHC_GetATime()
	local SteamID = self:SteamID()
	if RHC_ArrestedPlayers[SteamID] then
		return RHC_ArrestedPlayers[SteamID].ATime
	else
		return 0
	end
end

function PLAYER:RHC_GetANick()
	local SteamID = self:SteamID()
	if RHC_ArrestedPlayers[SteamID] then
		return RHC_ArrestedPlayers[SteamID].ANick
	else
		return "None"
	end
end

function PLAYER:IsRHCWhitelisted()
	if !RHandcuffsConfig.RestrictCuffsToWhitelist then
		return true
	else
		if !RHandcuffsConfig.WhitelistedJobs then RHC_InitJobsConfig() end
		return RHandcuffsConfig.WhitelistedJobs[self:Team()]
	end
end

function PLAYER:IsRHCImmune()
	if !RHandcuffsConfig.ImmuneJobs then RHC_InitJobsConfig() end
	return RHandcuffsConfig.ImmuneJobs[self:Team()]
end

function PLAYER:CanRHCBail()
	if !RHandcuffsConfig.BailJobs then RHC_InitJobsConfig() end
	return RHandcuffsConfig.BailJobs[self:Team()]
end

function PLAYER:TBFY_CanSurrender()
	local Wep = self:GetActiveWeapon()
	if !IsValid(Wep) or RHandcuffsConfig.SurrenderWeaponWhitelist[Wep:GetClass()] then
		return false
	else
		return true	
	end
end

hook.Add("canLockpick", "AllowCuffPicking", function(Player, CuffedP, Trace)
	if CuffedP:GetNWBool("rhc_cuffed", false) then
		return true
	end
end)

hook.Add("lockpickTime", "SetupCuffPickTime", function()
	return RHandcuffsConfig.CuffPickTime
end)

hook.Add("canRequestHit", "RHC_RestrictHitMenu", function(Hitman, Player)
	if Hitman:GetNWBool("rhc_cuffed", false) then
		return false
	end
end)