
if SERVER then
	include("tbfy_shared/sv_tbfyshared.lua")
	include("tbfy_shared/sh_tbfyshared.lua")
	
	AddCSLuaFile("tbfy_shared/sh_tbfyshared.lua")
	AddCSLuaFile("tbfy_shared/cl_tbfyshared.lua")
elseif CLIENT then
	include("tbfy_shared/sh_tbfyshared.lua")
    include("tbfy_shared/cl_tbfyshared.lua")	
end