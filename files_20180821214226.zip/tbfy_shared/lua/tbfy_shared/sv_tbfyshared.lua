
util.AddNetworkString("tbfy_spawn_entity")
util.AddNetworkString("tbfy_notify")

function TBFY_Notify(Player, msgtype, len, msg)
    net.Start("tbfy_notify")
        net.WriteString(msg)
        net.WriteFloat(msgtype)
        net.WriteFloat(len)
    net.Send(Player)
end

net.Receive("tbfy_spawn_entity", function(len, Player)
	if !Player:IsAdmin() then return end

	if Player.NextESpawn and Player.NextESpawn > CurTime() then return end
	Player.NextESpawn = CurTime() + 1		
	
	local Ent, Pos, Ang = net.ReadString(), net.ReadVector(), net.ReadAngle()
	
	local NewE = ents.Create(Ent)
	NewE.SBy = Player
	NewE:SetPos(Pos)
	NewE:SetAngles(Ang)
	NewE:Spawn()
	NewE:GetPhysicsObject():EnableMotion(false)
	
	if NewE.TBFY_OnSpawn then
		NewE:TBFY_OnSpawn()
	end
	
	Player.LastEntC = NewE
end)