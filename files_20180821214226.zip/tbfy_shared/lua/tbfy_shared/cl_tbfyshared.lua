
TBFY_SH = TBFY_SH or {}
TBFY_SH.SetupTbl = TBFY_SH.SetupTbl or {}

function TBFY_SH.SetupCategory(self, CatName)
	TBFY_SH.SetupTbl[CatName] = TBFY_SH.SetupTbl[CatName] or {}
	TBFY_SH.SetupTbl[CatName].Ents = TBFY_SH.SetupTbl[CatName].Ents or {}
	TBFY_SH.SetupTbl[CatName].Buttons = TBFY_SH.SetupTbl[CatName].Buttons or {}
end

function TBFY_SH.SetupEntity(self, CatName, Name, Entity, Model, Offs)
	TBFY_SH.SetupTbl[CatName].Ents[Entity] = {N = Name, M = Model, CFuncL = nil, CFuncR = nil, CFuncDraw = nil, CFuncThink = nil, Offset = Offs}
end

function TBFY_SH.SetupCustomFunctionL(self, CatName, Entity, Func)
	TBFY_SH.SetupTbl[CatName].Ents[Entity].CFuncL = Func
end

function TBFY_SH.SetupCustomFunctionR(self, CatName, Entity, Func)
	TBFY_SH.SetupTbl[CatName].Ents[Entity].CFuncR = Func
end

function TBFY_SH.SetupCustomFunctionDraw(self, CatName, Entity, Func)
	TBFY_SH.SetupTbl[CatName].Ents[Entity].CFuncDraw = Func
end

function TBFY_SH.SetupCustomFunctionThink(self, CatName, Entity, Func)
	TBFY_SH.SetupTbl[CatName].Ents[Entity].CFuncThink = Func
end

function TBFY_SH.SetupCMDButton(self, CatName, Name, CMD)
	TBFY_SH.SetupTbl[CatName].Buttons[Name] = CMD
end

//Make sure all addons have time to setup all hooks
timer.Simple(4, function()
	hook.Call("tbfy_InitSetup")
end)

net.Receive("tbfy_notify", function()
    local txt = net.ReadString()
    GAMEMODE:AddNotify(txt, net.ReadFloat(), net.ReadFloat())
    surface.PlaySound("buttons/lightswitch2.wav")

    MsgC(Color(255, 20, 20, 255), "[TBFY] ", Color(200, 200, 200, 255), txt, "\n")
end)

surface.CreateFont( "tbfy_header", {
	font = "Arial",
	size = 20,
	weight = 1000,
	antialias = true,
})

surface.CreateFont("tbfy_entname", {
	font = "Verdana",
	size = 12,
	weight = 1000,
	antialias = true,
})

surface.CreateFont("tbfy_buttontext", {
	font = "Verdana",
	size = 11,
	weight = 1000,
	antialias = true,
})

local MainPanelColor = Color(255,255,255,200)
local HeaderColor = Color(50,50,50,255)
local TabListColors = Color(215,215,220,255)
local ButtonColor = Color(50,50,50,255)
local ButtonColorHovering = Color(75,75,75,200)
local ButtonColorPressed = Color(150,150,150,200)
local ButtonOutline = Color(0,0,0,200)
local Padding = 5
local HeaderH = 25

local PANEL = {}

function PANEL:Init()
	self.ButtonText = ""
	self.BColor = ButtonColor
	self:SetText("")
	self.Font = "tbfy_buttontext"
	self.DClickC = ButtonColorPressed
	self.DHoverC = ButtonColorHovering
	self.DButtonC = ButtonColor
end

function PANEL:UpdateColours()

	if self:IsDown() or self.m_bSelected then self.BColor = self.DClickC return end
	if self.Hovered and !self:GetDisabled() then self.BColor = self.DHoverC return end

	self.BColor = self.DButtonC
	return
end

function PANEL:SetBText(Text)
	self.ButtonText = Text
end

function PANEL:SetBFont(Font)
	self.Font = Font
end

function PANEL:SetBColors(Press,Hover,Normal)
	self.DClickC = Press
	self.DHoverC = Hover
	self.DButtonC = Normal
end

function PANEL:Paint(W,H)
	draw.RoundedBox(4, 0, 0, W, H, self.BColor)
	draw.SimpleText(self.ButtonText, self.Font, W/2, H/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )   
end
vgui.Register("tbfy_button", PANEL, "DButton")

local PANEL = {}

function PANEL:AddSheet( label, panel, material )

	if ( !IsValid( panel ) ) then return end

	local Sheet = {}

	Sheet.Button = vgui.Create( "tbfy_button", self.Navigation )

	Sheet.Button:SetImage( material )
	Sheet.Button.Target = panel
	Sheet.Button:Dock( TOP )
	Sheet.Button:SetBText( label )
	Sheet.Button:DockMargin( 0, 1, 0, 0 )

	Sheet.Button.DoClick = function()
		self:SetActiveButton( Sheet.Button )
	end

	Sheet.Panel = panel
	Sheet.Panel:SetParent( self.Content )
	Sheet.Panel:SetVisible( false )

	table.insert( self.Items, Sheet )

	if ( !IsValid( self.ActiveButton ) ) then
		self:SetActiveButton( Sheet.Button )
	end

end
vgui.Register("tbfy_DColumnSheet", PANEL, "DColumnSheet")

local PANEL = {}

function PANEL:Paint(W,H)
	draw.RoundedBox(4, 0,Padding,W-Padding,H-Padding*2,TabListColors)
end
vgui.Register("tbfy_DPanel", PANEL, "DPanel")

local PANEL = {}

function PANEL:Init()
	self:SetSize(50, 50)
	self.Name = ""
	
	self.SpawnI = vgui.Create("SpawnIcon" , self)
end

function PANEL:SetupIcon(Class, ETbl)
	self.SpawnI:Dock(FILL)
	self.SpawnI:SetModel(ETbl.M)
	self.SpawnI.DoClick = function()
		local Swep = LocalPlayer():GetActiveWeapon()
		if IsValid(Swep) then
			Swep:UpdateSelectedEnt(Class, ETbl)
		end
	end
	self.Name = ETbl.N
end

function PANEL:PaintOver(W,H)
	surface.SetFont("tbfy_entname")
	local N = self.Name
	local TW, TH = surface.GetTextSize(N)
	TW = TW + 4
	draw.RoundedBox(4, W/2-TW/2, H-TH, TW, TH, HeaderColor)	
	draw.SimpleText(N, "tbfy_entname", W/2, H, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
end

vgui.Register("tbfy_DEnt", PANEL)

local PANEL = {}

function PANEL:Init()
	self:MakePopup()
	
    self.TopDPanel = vgui.Create("DPanel", self)
	self.TopDPanel.Paint = function(selfp, W,H)
		draw.RoundedBoxEx(8, 0, 0, W, H, HeaderColor, true, true, false, false)	
		draw.SimpleText("TBFY - Setup Tool", "tbfy_header", W/2, H/2, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)			
	end		
	
	self.Sheet = vgui.Create("tbfy_DColumnSheet", self)
	
	self.CloseButton = vgui.Create("tbfy_button", self)
	self.CloseButton:SetBText("X")
	self.CloseButton.DoClick = function() self:Remove() end	
	
	self:InitSetup()
end

local Width, Height = 500, 550
function PANEL:InitSetup()
	self.DPanels = {}
	for k,v in pairs(TBFY_SH.SetupTbl) do
		local panel = vgui.Create("tbfy_DPanel", self.Sheet)
		self.Sheet:AddSheet(k, panel)
		
		local EntCat = vgui.Create("DCollapsibleCategory", panel)
		EntCat:SetLabel("Entities")
		EntCat:SetExpanded(1)
		
		local DList = vgui.Create("DPanelList", panel)
		DList:EnableHorizontal(false)
		DList:EnableVerticalScrollbar(true)
		EntCat:SetContents(DList)
		
		for Class,ETbl in pairs(v.Ents) do
			local EntD = vgui.Create("tbfy_DEnt" , DList)
			EntD:SetupIcon(Class, ETbl)
			DList:AddItem(EntD)
		end
		
		local ButCat = vgui.Create("DPanelList", panel)
		ButCat:EnableHorizontal(false)
		ButCat:EnableVerticalScrollbar(true)
		ButCat:SetSpacing(5)
		
		for Name,CMD in pairs(v.Buttons) do
			local CMDBut = vgui.Create("tbfy_button", self)
			CMDBut:SetBText(Name)
			CMDBut.DoClick = function() RunConsoleCommand(CMD) end		
			ButCat:AddItem(CMDBut)
		end		
		
		self.DPanels[k] = {Pan = panel, Cat = EntCat, But = ButCat}
	end
end

function PANEL:PerformLayout(W,H)	
	self:SetPos(ScrW()/2-Width/2, ScrH()/2-Height/2)
	self:SetSize(Width, Height)
	
	self.TopDPanel:SetSize(W,HeaderH)
	
	self.Sheet:SetPos(0,HeaderH)
	self.Sheet:SetSize(W,H-HeaderH)
	
	for k,v in pairs(self.DPanels) do
		v.Pan:Dock(FILL)
		
		local PW, PH = self.Sheet.Content:GetWide()-10, self.Sheet.Content:GetTall()-20
		v.Cat:SetPos(Padding, Padding*2)
		v.Cat:SetSize(PW*0.35-Padding,PH)
		
		v.But:SetPos(Padding + PW*0.35, Padding*2)
		v.But:SetSize(PW*0.65-Padding, PH)
	end
	
	self.CloseButton:SetPos(Width-25,3)
	self.CloseButton:SetSize(20, 20)	
end

function PANEL:Paint(W,H)
	draw.RoundedBoxEx(4, 0, HeaderH, W, H-HeaderH, MainPanelColor, false, false, true, true)
end
vgui.Register("tbfy_selectionmenu", PANEL)