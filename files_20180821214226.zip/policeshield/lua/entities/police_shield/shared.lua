ENT.Type = "anim";
ENT.Base = "base_anim";
ENT.PrintName = "Police Shield";
ENT.Author = "Drover";
ENT.Spawnable = true;
ENT.Category = "Police Shield";
ENT.AutomaticFrameAdvance = true;
ENT.RenderGroup 		= RENDERGROUP_BOTH;

/* 
---------------------------------------------------------------------------------------------------------------------------------------------
				Config
---------------------------------------------------------------------------------------------------------------------------------------------
*/


/*


AddEntity("Police Shield", {
        ent = "police_shield",
        model = "models/drover/w_shield.mdl", 
        price = 500,
        max = 2,
        cmd = "buyshieldpolice",
        allowed = {TEAM_POLICE}
}) 


*/