bWhitelist.Config={}local
_=bWhitelist.Config
_.DefaultLanguage="English"_.MaxPermitted={}_.MaxPermittedDisableWhitelists=!!1
_.MaxPermittedSkipWhitelists=!1
_.Permissions={["STEAM_0:1:40314158"]={"*"}}_.ChatCommand="!bwhitelist"_.AllowConsoleCommand=!!1
_.ShowUnwhitelistedJobs=!1
_.FunctionMenuKey=!1
_.AutoSwitch=!1