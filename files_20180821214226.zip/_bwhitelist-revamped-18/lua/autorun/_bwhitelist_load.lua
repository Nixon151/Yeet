hook.Add("loadCustomDarkRPItems","bwhitelist_loadCustomDarkRPItems",function()
	bWhitelist_loadCustomDarkRPItems = true
end)
hook.Add("ezJobsLoaded","bwhitelist_loadezJobs",function()
	ezJobs_loaded = true
end)

if (bWhitelist and CLIENT) then
	if (IsValid(bWhitelist.Menu)) then
		bWhitelist.Menu:Close()
	end
end

bWhitelist = {}
BWhitelist = bWhitelist
bWhitelist.Version = "Revamped-18"
bWhitelist.Licensee = "76561198299253030"

local _,d = file.Find("bwhitelist/mods/*","LUA")
for _,v in pairs(d) do
	if (file.Exists("bwhitelist/mods/" .. v .. "/sh.lua","LUA") and SERVER) then
		AddCSLuaFile("bwhitelist/mods/" .. v .. "/sh.lua")
	end
	if (file.Exists("bwhitelist/mods/" .. v .. "/cl.lua","LUA") and SERVER) then
		AddCSLuaFile("bwhitelist/mods/" .. v .. "/cl.lua")
	end
end

if (SERVER) then
	CreateConVar("bwhitelist_whitelist_debug","0",FCVAR_SERVER_CAN_EXECUTE)
	
	AddCSLuaFile("bwhitelist/sh.lua")
	AddCSLuaFile("bwhitelist_config.lua")
	AddCSLuaFile("bwhitelist/cl.lua")
	AddCSLuaFile("bwhitelist_config.lua")
	AddCSLuaFile("bwhitelist/default_config.lua")
	for _,v in pairs((file.Find("bwhitelist/lang/*.lua","LUA"))) do
		AddCSLuaFile("bwhitelist/lang/" .. v)
	end
end
include("bwhitelist/sh.lua")
