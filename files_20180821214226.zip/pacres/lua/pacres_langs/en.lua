return {
Error="An error occured with outfit %s. See console...",
Editor="Editor are restricted for your rank.",
Wear="Wearing pac are restricted for your rank.",
Spam="Don't spam with wearing outfit(s)!",
Wearing="Wearing outfit(s)...",
Integrate="Limitations",

Timeout="Timeout",
Size="Total outfit(s) size too high(%d bytes/%d bytes max)(current:%d bytes).",
Count="Total %s count too high(%d/%d max)(current: %d)",
FailWhy="Failed to load %s: %s",
FailCode="Failed to load %s. Return code: %d",
FailModel="Failed to load model %s: File not found",
InvalidModel="Invalid model %s",
FailMaterial="Failed to load material %s: File not found",
FailSound="Failed to load sound %s: File not found",
Checking="Server is checking your outfit(s)...",

GUI={
"White & Gray","Golden","Green Apple","Cyan","Wine Coloured","Blue & Purple","Corn Coloured","Magma Red","Purple & Blue",
"PAC3 Restriction and Control Menu.","Select Theme","Use delay before send next outfit?(Recomended)","Max outfit(s) size in MBytes",
"Allow use editor?","Can send outfit(s)?","Check models for valid?(File not found)?",
"Check materials for valid?(File not found)?","Catch URL errors?(404 or too large files)(Recomended)",
"Check sounds path for valid(File not found)?","Add limit for item class \"%s\".\n0 - disable, empty field - reset.",
"Usergroups:","SteamIDs:","Add group or SteamID.","Adding new group","Enter group name or Steam ID",
"Add","Cancel","Dublicate parent","Default group","Remove group %s.","Are you sure to remove restricts from group %s?","Warning!","Yes","No"}
}