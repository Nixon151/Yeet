return {
Error="Ein Fehler ist aufgetreten mit Outfit %s, schau in die Konsole.",
Editor="Der Editor für diesen rank ist nicht verfügbar.",
Wear="Das Tragen ist für diesen rank nicht erlaubt.",
Spam="Spame nicht mit den Outfit tragen!",
Wearing="Wearing outfit(s)...",
Integrate="Einschränkungen",
 
Timeout="Unterbrechung",
Size="Gesamte Outfit Größe zu hoch (%d bytes/%d bytes max)(aktuell:%d bytes).",
Count="Gesamt %s zu hoch (%d/%d max)(aktuell: %d)",
FailWhy="Fehler beim Laden von %s: %s",
FailCode="Fehler beim Laden von %s. Rückgabestatus: %d",
FailModel="Fehler beim Laden des Modells %s: Datei nicht gefunden",
InvalidModel="Ungültiges Modell %s",
FailMaterial="Fehler beim Laden von Material %s: Datei nicht gefunden",
FailSound="Fehler beim Laden von Sound %s: Datei nicht gefunden",
Checking="Server prüft dein Outfit...",
 
GUI={
"Weiß & Grau","Gold","Apfel Grün","Cyan","Wein Farbig","Blau & Lila","Mais Farbig","Magma Rot","Lila & Blau",
"PAC3 Einschränkungen und Kontroll Menu.","Theme Auswählen","Verzögerung verwenden, bevor nächstes Outfit senden?(Empfohlen)","Maximale Outfit größe in MBytes",
"Erlaube Editor?","Kann Outfits senden?","Modelle prüfen auf gültigkeit?(Datei nicht gefunden)?",
"Material prüfen auf gültigkeit?(Datei nicht gefunden)?","Catch URL fehler?(404 oder datei zu gro?)(Empfohlen)",
"Sounds prüfen auf gültigkeit?(Datei nicht gefunden)?","Endlimit für Objektklasse hinzufügen \"%s\".\n0 - deaktivieren, leeres Feld - zurücksetzen.",
"Nutzergruppen:","SteamIDs:","Gruppe hinzufügen oder SteamID.","Neue Gruppe hinzufügen","Gruppenname oder SteamID eingeben",
"Hinzufügen","Abbrechen","Parent Duplizieren","Standart Gruppe","Gruppe %s entfernen","Bist du dir sicher, die Einschränkungen aus der Gruppe %s zu entfernen?","Warnung!","Ja","Nein"}
}