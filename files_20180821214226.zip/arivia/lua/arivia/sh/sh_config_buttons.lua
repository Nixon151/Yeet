-----------------------------------------------------------------
-- @package     Arivia
-- @author      Richard
-- @build       v2.0.2
-- @release     07.14.2016
-- @owner       76561198123392139
-----------------------------------------------------------------
-- BY MODIFYING THIS FILE -- YOU UNDERSTAND THAT THE ABOVE 
-- MENTIONED AUTHORS CANNOT BE HELD RESPONSIBLE FOR ANY ISSUES
-- THAT ARISE. AS A CUSTOMER TO THE ORIGINAL PURCHASED COPY OF
-- THIS SCRIPT, YOU ARE ENTITLED TO STANDARD SUPPORT WHICH CAN
-- BE PROVIDED USING [SCRIPTFODDER.COM]. 
-- ONLY THE ORIGINAL PURCHASER OF THIS SCRIPT CAN RECEIVE SUPPORT.
-----------------------------------------------------------------

-----------------------------------------------------------------
-- [ INFO BUTTONS ]
-- 
-- Displayed on left-side of the F4 Menu
-- You can disable any one of these by changing 
-- enabled = true to false.
--
-- To open a URL:
--      Arivia:OpenURL("http://url.com", "Titlebar Text")
--
-- To open standard text:
--      Arivia:OpenText("Text here", "Titlebar Text")
--
-----------------------------------------------------------------

Arivia.UseIconsWithInfo = true -- This shows the icons with text.

Arivia.Settings.Menu.TitleForums = "Community Forums"
Arivia.Settings.Menu.LinkForums = "https://galaxyscp.mistforums.com/"

Arivia.Settings.Menu.TitleDonate = "Donate to our Network!"
Arivia.Settings.Menu.LinkDonate = "https://galaxyscp.mistforums.com/donate"

Arivia.Settings.Menu.TitleWebsite = "Apply for staff here!"
Arivia.Settings.Menu.LinkWebsite = "https://galaxyscp.mistforums.com/category/staff-application-494735"

Arivia.Settings.Menu.TitleWorkshop = "The Official Network Steam Collection"
Arivia.Settings.Menu.LinkWorkshop = "https://steamcommunity.com/sharedfiles/filedetails/?id=1455496795"

-----------------------------------------------------------------
-- [ RULES ]
-----------------------------------------------------------------

Arivia.Settings.Menu.TitleRules = "Network Rules"

Arivia.Settings.RulesTextColor = Color( 255, 255, 255, 255 )
Arivia.Settings.RulesText = 
[[

----DO NOT DO THE FOLLOWING----
[x] No abusing NLR
[x] No racist or sexually abusive comments toward others
[x] No impersonating staff members
[x] No being disrespectful to other players or staff
[x] No threatening to DDoS or take down our network [perm-ban and IP logging]
[x] No asking for other players personal information (IE: home address, phone number)
[x] No blocking doors or denying players access to a part of the map.
[x] No abusing the !unstuck command.
[x] No prop-killing.
[x] No hiding in areas as a prop that hunters cannot access or see.
[x] No mic or chat spamming.

----INFRACTION CONSEQUENCES----
The following actions may be taken in this order [unless violating a more serious offense]:

[-] Player shall be warned about the rule they have broken.
[-] Will be kicked from the server if they continue to break a rule.
[-] A ban will be issued for a term of 3-5 days (depending on what occured)
[-] A permanent ban will be issued and shall not be removed
[-] Bypassing a server ban will result in a GLOBAL BAN from ALL servers within our network including denied access to our website

]]

Arivia.Settings.InfoButtons = {
    {
        name = "Online Staff",
        description = "Available to assist",
        icon = "arivia/arivia_button_staff.png",
        buttonNormal = Color(64, 105, 126, 190),
        buttonHover = Color(64, 105, 126, 240),
        textNormal = Color(255, 255, 255, 255),
        textHover = Color(255, 255, 255, 255),
        enabled = true,
        func = function()
            Arivia:OpenAdmins()
        end
    },
    { 
        enabled = true,
        name = "Rules", 
        description = "What you should know",
        icon = "arivia/arivia_button_rules.png",
        buttonNormal = Color( 163, 135, 79, 190 ), 
        buttonHover = Color( 163, 135, 79, 240 ), 
        textNormal = Color ( 255, 255, 255, 255 ),
        textHover = Color( 255, 255, 255, 255 ),
        func = function() Arivia:OpenExternal( Arivia.Settings.Menu.TitleRules, Arivia.Settings.RulesText, true ) end 
    },
    { 
        enabled = true,
        name = "Donate", 
        description = "Donate to help keep us running",
        icon = "arivia/arivia_button_donate.png",
        buttonNormal = Color( 145, 71, 101, 190 ), 
        buttonHover = Color( 145, 71, 101, 240 ), 
        textNormal = Color ( 255, 255, 255, 255 ),
        textHover = Color( 255, 255, 255, 255 ),
        func = function() Arivia:OpenExternal( Arivia.Settings.Menu.TitleDonate, Arivia.Settings.Menu.LinkDonate ) end 
    },
    { 
        enabled = true,
        name = "Website", 
        description = "Visit the official website",
        icon = "arivia/arivia_button_website.png",
        buttonNormal = Color( 72, 112, 58, 190 ), 
        buttonHover = Color( 72, 112, 58, 240 ), 
        textNormal = Color ( 255, 255, 255, 255 ),
        textHover = Color( 255, 255, 255, 255 ),
        func = function() Arivia:OpenExternal( Arivia.Settings.Menu.TitleWebsite, Arivia.Settings.Menu.LinkWebsite ) end 
    },
    { 
        enabled = true,
        name = "Steam Workshop", 
        description = "Download our addons here",
        icon = "arivia/arivia_button_workshop.png",
        buttonNormal = Color( 112, 87, 58, 190 ), 
        buttonHover = Color( 112, 87, 58, 220 ), 
        textNormal = Color ( 255, 255, 255, 255 ),
        textHover = Color( 255, 255, 255, 255 ),
        func = function() Arivia:OpenExternal( Arivia.Settings.Menu.TitleWorkshop, Arivia.Settings.Menu.LinkWorkshop ) end 
    },
    {
        enabled = true,
        name = "Disconnect",
        description = "Disconnect from our server",
        icon = "arivia/arivia_button_disconnect.png",
        buttonNormal = Color(124, 51, 50, 190),
        buttonHover = Color(124, 51, 50, 240),
        textNormal = Color(255, 255, 255, 255),
        textHover = Color(255, 255, 255, 255),
        func = function()
            RunConsoleCommand("disconnect")
        end
    }
}