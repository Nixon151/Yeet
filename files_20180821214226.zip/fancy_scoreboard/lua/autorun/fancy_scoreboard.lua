/*
	FancyScoreboard (Version 1.3.4)
	Created by: http://steamcommunity.com/profiles/76561198046951756
*/

-- Don't edit unless you know what you're doing! --


-- Init
FancyScoreboard = {}

if SERVER then
	include("fancy_scoreboard/sv_init.lua")
elseif CLIENT then
	include("fancy_scoreboard/cl_init.lua")
end