/*
	FancyScoreboard (Version 1.3.4)
	Created by: http://steamcommunity.com/profiles/76561198123392139
*/

-- Don't edit unless you know what you're doing! --


-- Title font
surface.CreateFont("FancyScoreboard.Title", {
	font = "Bebas Neue",
	size = 50,
	weight = 500,
	italic = true,
	antialias = true
})

-- Larger text
surface.CreateFont("FancyScoreboard.Large", {
	font = "Arial",
	size = 35,
	weight = 100,
	antialias = true
})

-- Button, and general text font
surface.CreateFont("FancyScoreboard.Normal", {
	font = "Arial",
	size = 20,
	weight = 100,
	antialias = true
})

-- Smaller font
surface.CreateFont("FancyScoreboard.Small", {
	font = "Arial",
	size = 15,
	weight = 100,
	antialias = true
})