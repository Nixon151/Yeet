/*
	FancyScoreboard (Version 1.3.4)
	Created by: http://steamcommunity.com/profiles/76561198046951756
*/


-- Don't touch this line
FancyScoreboard.Config = {}


-- [[ Config ]] --

-- If the scoreboard is enabled or not (May require server restart or player rejoin if changed at runtime) [ Default: true ]
FancyScoreboard.Config.Enabled = true

-- If the player must hold their tab key in order for the scoreboard to stay open, or if it's a toggle [ Default: false ]
FancyScoreboard.Config.IsToggle = false

-- Whether the quick settings menu should be enabled or not [ Default: true ]
FancyScoreboard.Config.QuickSettingsEnabled = true

-- Minimum rank required to open and use the quick settings menu ( 0 = Admin, 1 = SuperAdmin, "" = any ulx rank name) [ Default = 1 ]
FancyScoreboard.Config.QuickSettingsRank = 1

-- Enable mouse clicking by default (Or make users right click to enable mouse if false) [ Default: true ]
FancyScoreboard.Config.EnableMouse = true

-- If the hint at the bottom of the screen should be enabled (Only applies if EnableMouse is false) [ Default: true ]
FancyScoreboard.Config.EnableHint = true

-- Blur everything in the background while the scoreboard is open [ Default: true ]
FancyScoreboard.Config.BackgroundBlur = true

-- The multiplier for the animation speed [ Default: 1, Set to 0 to disable animations, Bigger number = slower animations ]
FancyScoreboard.Config.AnimationSpeed = 1

-- Title to display on top of the scoreboard [ Set to true to use server name as title, set to false to disable, or set to any string ]
FancyScoreboard.Config.Title = "GalaxyGaming"

-- Default message when kicking someone (Set to nil to disable or set to any string for custom default message)
FancyScoreboard.Config.DefaultKickReason = nil

-- Default message when banning someone (Set to nil to disable or set to any string for custom default message)
FancyScoreboard.Config.DefaultBanReason = nil

-- Minimum rank required to open scoreboard
FancyScoreboard.Config.RequiredRank = {
	-- The admin system which you are using (Leave as nil to use default GMod admin/superadmin ranks, "ULX", or "ServerGuard") [ Default: nil ]
	AdminSystem = nil,
	
	-- The minimum rank the player needs to have to open the scoreboard
	--(Set to nil to disable the RequiredRank feature, or set to any rank, such as: "admin") [ Default: nil ]
	Rank = nil,
}

-- Rank aliases
/*
	Example:
	
	{
		Rank = "admin", -- Rank name in ULX / Serverguard (REQUIRED)
		Name = "Admin", -- Rank name in-game (REQUIRED)
		Color = Color(200, 20, 200, 255), -- Rank color in-game (OPTIONAL)
		Icon = "icon16/user.png", -- Rank icon in-game, only works if RankIcon is set to true in the modules section (OPTIONAL)
	}, -- Don't forget this comma
	
	You can find a list of all the usable icons here: http://www.famfamfam.com/lab/icons/silk/preview.php
	If you use an icon from here, make sure the icon name uses ONLY forward slashes(/) and always starts with "icon16/{your_icon}.png"
	
	NOTE: If RankAliases is set to false in modules, this entire table is ignored
*/
FancyScoreboard.Config.RankAliases = {
	{
		Rank = "superadmin",
		Name = "Superadmin",
		Color = Color(200, 20, 20, 255),
		Icon = "icon16/shield_add.png",
	},
	{
		Rank = "general manager",
		Name = "General Manager",
		Color = Color(200, 20, 20, 255),
		Icon = "icon16/shield_add.png",
	},
	{
		Rank = "sector admin",
		Name = "Sector Admin",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield_add.png",
	},
        {
		Rank = "head admin",
		Name = "Head Admin",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield_add.png",
	},
	{
		Rank = "senior admin",
		Name = "Senior Admin",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield.png",
	},
        {
		Rank = "admin",
		Name = "Admin",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield.png",
	},
        {
		Rank = "trial admin",
		Name = "Trial Admin",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield.png",
	},
        {
		Rank = "head mod",
		Name = "Head Mod",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield_add.png",
	},
        {
		Rank = "senior mod",
		Name = "Senior Mod",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield.png",
	},
        {
		Rank = "mod",
		Name = "Mod",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield.png",
	},
        {
		Rank = "trial mod",
		Name = "Trial Mod",
		Color = Color(200, 200, 20, 255),
		Icon = "icon16/shield.png",
	},
	{
		Rank = "user",
		Name = "User",
		Icon = "icon16/user.png",
	},
}

-- Enable or disable certain things on the scoreboard (true - Enabled | false - Disabled)
FancyScoreboard.Modules = {
	-- Enable rank aliases. If this is false, the FancyScoreboard.Config.RankAliases table is ignored [ Default: true ]
	RankAliases = true,
	
	-- Allow users to mute other players [ Defualt: true ]
	Muting = true,
	
	-- Display user's rank when selecting them [ Default: true ]
	Rank = true,
	
	-- Display an icon next to a user based on their rank [ Default: true ]
	RankIcon = true,
	
	-- If it should draw the user's team/job [ Default: true ]
	Team = true,
	
	-- Display user's team/job color (Values: 0 = Disabled, 1 = Only job text and player info outline, 2 = Entire player panel) [ Default: 1 ]
	TeamColor = 1,
	
	-- Sort players into different categories based on team/job [ Default: false ]
	TeamCategorySorting = true,
	
	
	-- Sandbox prop info [ Default: true ]
	Sandbox_PropInfo = true,
	
	-- User's DarkRP money when selecting them [ Default: true ]
	DarkRP_Money = true,
	
	
	-- Basic actions menu when selecting player (Copy SteamID, Open profile) [ Default: true ]
	Basic_Actions = true,
	
	-- DarkRP actions when selecting player (Only works if DarkRP is the current gamemode) [ Default: true ]
	DarkRP_Actions = true,
	
	-- ULX actions when selecting player (Only works if ULX is installed) [ Default: true ]
	ULX_Actions = true,
	
	-- Serverguard actions when selecting player (Only works if Serverguard is installed) [ Default: true ]
	Serverguard_Actions = false,
	
	-- FAdmin actions when selecting player (Only works if FAdmin is installed) [ Default: false ]
	FAdmin_Actions = false,
}

-- Ping ranges and colors (Only applies if VisualPing is set to true)
FancyScoreboard.Config.Ping = {
	Good = {
		-- Max ping until it changes to next stage
		Limit = 60,
		
		-- Color for this stage
		Color = Color(20, 200, 20, 255),
	},
	Decent = {
		-- Max ping until it changes to next stage
		Limit = 120,
		
		-- Color for this stage
		Color = Color(200, 200, 20, 255),
	},
	Bad = {
		-- Last stage, any ping higher than the "Decent" limit is "Bad"
		-- Color for this stage
		Color = Color(200, 20, 20, 255),
	},
}


-- [[ Language ]] --

FancyScoreboard.Language = {
	-- Phrases
	QuickSettings = "Quick Settings",
	Hint = "Press right click to enable the mouse",
	NoOpenPermission = "You do not have permission to open the scoreboard",
	
	-- General words
	Name = "Name",
	Team = "Team",
	Kills = "Kills",
	Deaths = "Deaths",
	Ping = "Ping",
	Yes = "Yes",
	No = "No",
	Close = "Close",
	Amount = "Amount",
	Time = "Time",
	Reason = "Reason",
	Second = "Second",
	Minute = "Minute",
	Hour = "Hour",
	Day = "Day",
	Week = "Week",
	Month = "Month",
	Year = "Year",
	Forever = "Forever",
	Enable = "Enable",
	Disable = "Disable",
	
	-- Sandbox Info
	Props = "Props",
	Ragdolls = "Ragdolls",
	Entities = "SENTs",
	Vehicles = "Vehicles",
	NPCs = "NPCs",
	
	-- DarkRP Info
	Job = "Job",
	Money = "Money",
	
	-- Quick Settings
	Actions = "Actions",
	RCon = "RCon",
	ClearDecals = "Clear Decals",
	StopSounds = "Stop Sounds",
	CleanUp = "Clean Up Server",
	
	Player = "Player",
	EditGroups = "Edit Groups",
	Unban = "Unban",
	AdminPlayerPickup = "Admin -> Player Pickup",
	PlayerPlayerPickup = "Player -> Player Pickup",
	RestrictWeapons = "Restrict Weapons",
	
	Settings = "Settings",
	Godmode = "Godmode",
	Noclip = "Noclip",
	PvP = "PvP",
	ServerLimits = "Server Limits",
	
	-- Basic Actions Menu	
	BasicActions = "Basic Actions",
	CopySteamID = "Copy SteamID",
	CopiedID = "Copied SteamID to clipboard",
	OpenProfile = "Open Steam Profile",
	ProfileBot = "You cannot open the profile page of a bot!",
	
	-- DarkRP Actions Menu
	DarkRPActions = "DarkRP Actions",
	SetMoney = "Set Money",
	SetMoneyTitle = "Set %player%'s money",
	JobBan = "Job Ban",
	JobBanTitle = "Ban %player% from job",
	JobUnban = "Job Unban",
	JobUnbanTitle = "Unban %player% from job",
	
	-- Admin Actions Menus
	ULXActions = "ULX Actions",
	ServerguardActions = "Serverguard Actions",
	FAdminActions = "FAdmin Actions",
	Goto = "Goto",
	Bring = "Bring",
	Slay = "Slay",
	Freeze = "Freeze",
	ToggleFreeze = "Toggle Freeze",
	Unfreeze = "Unfreeze",
	Spectate = "Spectate",
	Kick = "Kick",
	KickTitle = "Kick %player%",
	Ban = "Ban",
	BanTitle = "Ban %player%",
}


-- [[ Colors ]] --

-- To change the colors, change the RGB values for any of the following colors:
-- However, make sure you do not forget the trailing comma (,) at the end of each line!
FancyScoreboard.Colors = {
	Accent = Color(220, 72, 58, 255),
	AccentText = Color(225, 255, 255, 240),
	Main = Color(35, 35, 35, 255),
	MainText = Color(255, 255, 255, 255),
	Background = Color(45, 45, 45, 255),
	BackgroundText = Color(220, 220, 220, 255),
	Selected = Color(255, 0, 0, 255),
	Alt = Color(28, 28, 28, 255),
}

/*
	========================
	Predefined color schemes
	========================
	
	To use any of these color schemes, replace the FancyScoreboard.Colors table above with any of the ones below:
	(Make sure you do not forget to include the '}' at the end!)
	
	-- Default colors (Red and black):
	FancyScoreboard.Colors = {
		Accent = Color(220, 72, 58, 255),
		AccentText = Color(255, 255, 255, 240),
		Main = Color(35, 35, 35, 255),
		MainText = Color(255, 255, 255, 255),
		Background = Color(45, 45, 45, 255),
		BackgroundText = Color(220, 220, 220, 255),
		Selected = Color(255, 0, 0, 255),
		Alt = Color(28, 28, 28, 255),
	}
	
	-- Cyan and black:
	FancyScoreboard.Colors = {
		Accent = Color(50, 200, 200, 255),
		AccentText = Color(255, 255, 255, 255),
		Main = Color(35, 35, 35, 255),
		MainText = Color(255, 255, 255, 255),
		Background = Color(45, 45, 45, 255),
		BackgroundText = Color(220, 220, 220, 255),
		Selected = Color(0, 255, 255, 255),
		Alt = Color(28, 28, 28, 255),
	}
*/


-- [[ Buttons and Sidebar info ]] --

/*
	If you wish to edit the buttons, look inside the 'cl_buttons.lua' file
	To add custom columns or custom sidebar info, look inside the 'cl_gminfo.lua' file
	
	!! Editing these files requires some more advanced Lua knowledge and is not recommended unless you know what you're doing !!
*/