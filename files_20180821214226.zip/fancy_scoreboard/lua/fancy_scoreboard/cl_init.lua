/*
	FancyScoreboard (Version 1.3.4)
	Created by: http://steamcommunity.com/profiles/76561198046951756
*/

-- Don't edit unless you know what you're doing! --


-- Includes
include("config.lua")
include("cl_fonts.lua")

-- Localization
local Color = Color
local ScrW = ScrW
local ScrH = ScrH
local surface = surface
local draw = draw
local vgui = vgui
local input = input
local gui = gui
local player = player

-- Prevent breaking during hot-refresh
if FancyScoreboard.Open then
	if IsValid(FancyScoreboard.Menu) then
		FancyScoreboard.Menu:Remove()
	end
	
	if IsValid(FancyScoreboard.MenuTitle) then
		FancyScoreboard.MenuTitle:Remove()
	end
	
	if IsValid(FancyScoreboard.MenuMain) then
		FancyScoreboard.MenuMain:Remove()
	end
end

-- Variables
FancyScoreboard.Open = false
FancyScoreboard.CanOpen = FancyScoreboard.CanOpen or false
FancyScoreboard.QuickMenuOpen = false
FancyScoreboard.DialogueOpen = 0
FancyScoreboard.SortingMode = nil
FancyScoreboard.Menu = nil
FancyScoreboard.MenuTitle = nil
FancyScoreboard.MenuMain = nil

-- Disable default DarkRP scoreboard
if FancyScoreboard.Config.Enabled then
	timer.Simple(1, function()
		if DarkRP then
			hook.Remove("ScoreboardShow", "FAdmin_scoreboard")
			hook.Remove("ScoreboardHide", "FAdmin_scoreboard")
		end
	end)
end

-- Language util function
function FancyScoreboard.GetPhrase(phrase, ...)
	local args = {...}
	local text = tostring(FancyScoreboard.Language[phrase])
	
	if text == nil then return "NULL" end
	
	if args ~= nil and istable(args) then
		for k, v in pairs(args) do
			text = string.Replace(text, v[1], v[2])
		end
	end
	
	return text
end

-- Util function to return all DarkRP job tables
function FancyScoreboard.GetDarkRPJobs()
	if DarkRP == nil then return {} end
	
	local jobs = {}
	
	for _, category in pairs(DarkRP.getCategories().jobs) do
		for _, job in pairs(category.members) do
			table.insert(jobs, job)
		end
	end
	
	return jobs
end
	
-- Input/confirm dialogue
function FancyScoreboard.OpenDialogue(info)
	if not istable(info) then return end
	
	FancyScoreboard.DialogueOpen = FancyScoreboard.DialogueOpen + 1
	FancyScoreboard.Hide()
	
	local colors = FancyScoreboard.Colors
	local menu, panel
	
	-- Menu
	menu = vgui.Create("DFrame")
	menu:SetPos(0, 0)
	menu:SetSize(ScrW(), ScrH())
	menu:ShowCloseButton(false)
	menu:SetTitle("")
	menu:MakePopup()
	
	function menu:Init()
		self.blurTime = SysTime()
	end
	
	function menu:Close()
		if FancyScoreboard.DialogueOpen > 1 then
			FancyScoreboard.DialogueOpen = FancyScoreboard.DialogueOpen - 1
		else
			FancyScoreboard.DialogueOpen = 0
		end
		
		if isfunction(info.OnClose) then
			info.OnClose()
		end
		
		panel:MoveTo((ScrW() - panel:GetWide()) / 2, ScrH(), 0.15 * FancyScoreboard.Config.AnimationSpeed)
		gui.EnableScreenClicker(false)
		
		function menu:Paint(w, h) end
		
		timer.Simple(0.15 * FancyScoreboard.Config.AnimationSpeed, function()
			self:Remove()
		end)
	end
	
	if FancyScoreboard.Config.BackgroundBlur then
		function menu:Paint(w, h)
			Derma_DrawBackgroundBlur(self, self.blurTime)
		end
	end
	
	-- Panel
	panel = vgui.Create("DPanel", menu)
	
	if info.Width == true or info.Width == nil then
		panel:SetWide(ScrW())
	else
		panel:SetWide(info.Width)
	end
	
	if info.Height == true or info.Height == nil then
		panel:SetTall(ScrH())
	else
		panel:SetTall(info.Height)
	end
	
	panel:SetPos((ScrW() - panel:GetWide()) / 2, ScrH())
	
	function panel:Paint(w, h)
		draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
		draw.RoundedBox(2, 0, 0, w - 2, h - 2, colors.Main)
		
		surface.SetFont("FancyScoreboard.Normal")
		local textW = surface.GetTextSize(tostring(info.Title))
		draw.SimpleText(info.Title or "", "FancyScoreboard.Normal", (w - 2) / 2 - textW / 2, 6, colors.MainText)
	end
	
	-- Content Panel
	local contentPanel = vgui.Create("DPanel", panel)
	contentPanel:StretchToParent(12, 50, 12, 60)
	
	function contentPanel:Paint(w, h) end
	
	-- Callback to build menu
	local settings = {}
	
	if isfunction(info.Build) then
		settings = info.Build(contentPanel) or {}
	end
	
	-- Auto size menu
	if info.Height == true or info.Height == nil then		
		local height = 110
		local lastElem = contentPanel:GetChildren()[#contentPanel:GetChildren()]
		local lastPos = select(2, lastElem:GetPos())
		
		height = height + lastPos + lastElem:GetTall()
		
		panel:SetHeight(height)
		contentPanel:SetHeight(lastPos + lastElem:GetTall())
	end
	
	if info.Width == true or info.Width == nil then
		local width = 24
		local largestElem = 0
		
		-- Find largest with
		for k, v in pairs(contentPanel:GetChildren()) do
			if v:GetWide() > largestElem then
				largestElem = v:GetWide()
			end
		end
		
		width = width + largestElem
		
		panel:SetWide(width)
		contentPanel:SetWidth(largestElem)
	end
	
	-- Buttons
	if info.Type == "Confirm" then
		local accept = vgui.Create("DButton", panel)
		accept:SetText(info.AcceptText or FancyScoreboard.GetPhrase("Yes"))
		accept:SetTextColor(colors.AccentText)
		accept:SetSize((panel:GetWide() - 38) / 2, 30)
		accept:SetPos(12, panel:GetTall() - accept:GetTall() - 10)
		
		function accept:DoClick()
			if isfunction(info.OnAccept) then
				info.OnAccept(settings)
			end
			
			menu:Close()
		end
		
		function accept:Paint(w, h)
			if self.Hovered then
				draw.RoundedBox(2, 0, 0, w, h, colors.Selected)
			else
				draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
			end
		end
		
		local decline = vgui.Create("DButton", panel)
		decline:SetText(info.DeclineText or FancyScoreboard.GetPhrase("No"))
		decline:SetTextColor(colors.AccentText)
		decline:SetSize((panel:GetWide() - 38) / 2, 30)
		decline:SetPos(24 + accept:GetWide(), panel:GetTall() - decline:GetTall() - 10)
		
		function decline:DoClick()
			menu:Close()
			
			if isfunction(info.OnDecline) then
				info.OnDecline(settings)
			end
		end
		
		function decline:Paint(w, h)
			if self.Hovered then
				draw.RoundedBox(2, 0, 0, w, h, colors.Selected)
			else
				draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
			end
		end
	elseif info.Type == "Notice" then
		local close = vgui.Create("DButton", panel)
		close:SetText(info.CloseText or FancyScoreboard.GetPhrase("Close"))
		close:SetTextColor(colors.AccentText)
		close:SetSize(panel:GetWide() - 24, 30)
		close:SetPos(12, panel:GetTall() - close:GetTall() - 10)
		
		function close:DoClick()
			menu:Close()
		end
		
		function close:Paint(w, h)
			if self.Hovered then
				draw.RoundedBox(2, 0, 0, w, h, colors.Selected)
			else
				draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
			end
		end
	end
	
	-- Animate panel
	panel:SetPos((ScrW() - panel:GetWide()) / 2, ScrH())
	panel:MoveTo((ScrW() - panel:GetWide()) / 2, (ScrH() - panel:GetTall()) / 2, 0.25 * FancyScoreboard.Config.AnimationSpeed)
end

-- Show scoreboard
function FancyScoreboard.Show()
	-- Check if already open
	if FancyScoreboard.Open or FancyScoreboard.DialogueOpen > 0 or FancyScoreboard.QuickMenuOpen then return end
	if not FancyScoreboard.CanOpen then return end
	if not IsValid(LocalPlayer()) then return end
	
	-- Checks for rank
	FancyScoreboard.Config.RequiredRank = FancyScoreboard.Config.RequiredRank or {} -- Backwards compat
	
	local reqRank = FancyScoreboard.Config.RequiredRank.Rank
	local adminSys = FancyScoreboard.Config.RequiredRank.AdminSystem
	
	if reqRank ~= nil and reqRank ~= "" then
		if adminSys == nil then
			reqRank = string.lower(reqRank)
			
			if reqRank == "admin" then
				if not LocalPlayer():IsAdmin() then return end
			elseif reqRank == "superadmin" then
				if not LocalPlayer():IsSuperAdmin() then return end
			end
		else
			adminSys = string.lower(adminSys)
			
			if adminSys == "ulx" and ulx ~= nil then
				if not LocalPlayer():CheckGroup(reqRank) then
					return
				else
					chat.AddText(Color(220, 20, 20), FancyScoreboard.GetPhrase("NoOpenPermission"))
				end
			end
			
			if adminSys == "serverguard" then
				 -- [TODO]
			end
		end
	end
	
	-- Prevent things breaking
	if IsValid(FancyScoreboard.Menu) then
		FancyScoreboard.Menu:Remove()
	end
	
	if IsValid(FancyScoreboard.MenuTitle) then
		FancyScoreboard.MenuTitle:Remove()
	end
	
	if IsValid(FancyScoreboard.MenuMain) then
		FancyScoreboard.MenuMain:Remove()
	end
	
	-- Variables
	local players
	local colors = FancyScoreboard.Colors
	local gmInfo = FancyScoreboard.GamemodeInfo[GAMEMODE.Name]
	local pingInfo = FancyScoreboard.Config.Ping
	local mouseEnabled = false
	local hintColor = false
	local hintLabel, contentPanel, titlePanel, quickBtnPanel, quickPanel
	local infoPanel, actionPanel, actionScrollPanel
	local drawContent
	local selectedPlayer
	
	FancyScoreboard.Open = true
	FancyScoreboard.QuickMenuOpen = false
	
	-- Check if gmInfo table is valid
	if istable(gmInfo) then
		if istable(gmInfo.Scoreboard) then
			if gmInfo.Scoreboard.Order == nil then
				gmInfo = nil
			end
			
			if gmInfo ~= nil then
				if not istable(gmInfo.Scoreboard.Custom) then
					gmInfo = nil
				end
			end
		else
			gmInfo = nil
		end
		
		if gmInfo ~= nil then
			if istable(gmInfo.Sidebar) then
				if gmInfo ~= nil then
					if not istable(gmInfo.Sidebar.Defaults) then
						gmInfo = nil
					end
				end
				
				if gmInfo ~= nil then
					if not istable(gmInfo.Sidebar.Custom) then
						gmInfo = nil
					end
				end
			else
				gmInfo = nil
			end
		end
	else
		gmInfo = nil
	end
	
	-- Mouse input
	if FancyScoreboard.Config.EnableMouse then
		gui.EnableScreenClicker(true)
		mouseEnabled = true
	end
	
	-- Helper function for labels
	local function createLabel(parent, text, font, yPos, color)
		local color = color or colors.MainText
		
		surface.SetFont(font)
		local textW, textH = surface.GetTextSize(tostring(text))
		
		local label = vgui.Create("DLabel", parent)
		label:SetFont(font)
		label:SetText(text)
		label:SetTextColor(color)
		label:SizeToContents()
		label:SetPos((parent:GetWide() - textW) / 2, yPos)
		
		return label
	end
	
	-- Helper function for buttons
	local function createButton(parent, text, yPos, doClick)
		local btn = vgui.Create("DButton", parent)
		btn:SetSize(parent:GetWide() - 80, 35)
		btn:SetPos((parent:GetWide() - btn:GetWide()) / 2, yPos)
		btn:SetText(text)
		btn:SetTextColor(colors.AccentText)
		--btn:SetFont("FancyScoreboard.Normal")
		btn.DoClick = doClick
		
		function btn:Paint(w, h)
			if self.Hovered then
				draw.RoundedBox(2, 0, 0, w, h, colors.Selected)
			else
				draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
			end
		end
		
		return btn
	end
	
	-- Helper function to sort players
	local function sortPlayers(name, compare, label)
		-- Change old label color
		if FancyScoreboard.SortingMode then
			local oldLabel = FancyScoreboard.SortingMode[3]
			
			if IsValid(oldLabel) then				
				oldLabel:SetTextColor(colors.MainText)
			end
		end
		
		-- Default sorting
		if name == nil or compare == nil then			
			FancyScoreboard.SortingMode = nil
			players = player.GetAll()
			
			return
		end
		
		-- Set new label color
		if IsValid(label) then
			label:SetTextColor(colors.Accent)
		end
		
		-- Sort based on compare callback (ply > other)
		FancyScoreboard.SortingMode = { name, compare, label }
		players = player.GetAll()
		table.sort(players, compare)
	end
	
	-- Helper function to get rank info
	local function getRankInfo(name)
		if FancyScoreboard.Modules.RankAliases and istable(FancyScoreboard.Config.RankAliases) then
			for k, v in pairs(FancyScoreboard.Config.RankAliases) do
				if not istable(v) then continue end
				
				if v.Rank == name then return v end
			end
		end
		
		return {
			Rank = name,
			Name = name,
			Color = colors.Text,
			Icon = nil
		}
	end
	
	-- Sort by last used sort mode, or nil
	if FancyScoreboard.SortingMode ~= nil then
		sortPlayers(unpack(FancyScoreboard.SortingMode))
	else
		sortPlayers(nil, nil, nil)
	end
	
	-- Menu container
	local menu = vgui.Create("DPanel")
	menu:SetPos(0, 0)
	menu:SetSize(ScrW(), ScrH())
	
	function menu:Init()
		self.blurTime = SysTime()
	end
	
	if FancyScoreboard.Config.BackgroundBlur then
		function menu:Paint(w, h)
			Derma_DrawBackgroundBlur(self, self.blurTime)
		end
	end
	
	function menu:Think()
		if not mouseEnabled and FancyScoreboard.Open then
			if input.IsMouseDown(MOUSE_RIGHT) then
				gui.EnableScreenClicker(true)
				mouseEnabled = true
			end
		else
			if hintLabel ~= nil and not hintColor then
				hintLabel:ColorTo(Color(255, 255, 255, 0), 0.25 * FancyScoreboard.Config.AnimationSpeed)
				hintColor = true
			end
		end
	end
	
	-- Find max width and height for scoreboard
	local maxWidth = ScrW() - 2 * (270 + 30)
	
	-- Title
	titlePanel = vgui.Create("DPanel", menu)
	titlePanel:SetSize(maxWidth, ScrH() - 150)
	
	titlePanel.ClosedPos = {(ScrW() - titlePanel:GetWide()) / 2, -titlePanel:GetTall() + 50 }
	titlePanel.OpenPos = { titlePanel.ClosedPos[1], 0 }
	
	titlePanel:SetPos((ScrW() - titlePanel:GetWide()) / 2, -titlePanel:GetTall())
	titlePanel:MoveTo(titlePanel.ClosedPos[1], titlePanel.ClosedPos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
	
	function titlePanel:Paint(w, h)
		-- Panel	
		local main = {
			{ x = 2, y = 0 },
			{ x = w - 2, y = 0 },
			{ x = w - 2, y = h - 50 },
			{ x = w - 52, y = h },
			{ x = 52, y = h },
			{ x = 2, y = h - 50 }
		}
		
		local border = {
			{ x = 0, y = 0 },
			{ x = w, y = 0 },
			{ x = w, y = h - 50 },
			{ x = w - 50, y = h },
			{ x = 50, y = h },
			{ x = 0, y = h - 50 }
		}
		
		
		draw.NoTexture()
		
		surface.SetDrawColor(colors.Accent)
		surface.DrawPoly(border)
		
		surface.SetDrawColor(colors.Main)
		surface.DrawPoly(main)
		
		-- Text
		surface.SetFont("FancyScoreboard.Title")
		
		local title
		
		if FancyScoreboard.QuickMenuOpen then
			title = FancyScoreboard.Language.QuickSettings
		else
			title = FancyScoreboard.Config.Title
			
			if type(title) == "boolean" then
				if title == true then
					title = GetHostName()
				else
					title = ""
				end
			end
		end
		
		local titleW, titleH = surface.GetTextSize(tostring(title))
		
		draw.SimpleText(title, "FancyScoreboard.Title", (titlePanel:GetWide() - titleW) / 2, titlePanel:GetTall() - titleH, colors.MainText)
	end
	
	-- Checks if the user can see the quick settings menu
	local canSeeQuickSettings = false
	
	if FancyScoreboard.Config.QuickSettingsEnabled then
		local rankSetting = FancyScoreboard.Config.QuickSettingsRank
	
		if rankSetting == 0 then
			if LocalPlayer():IsAdmin() then
				canSeeQuickSettings = true
			end
		elseif rankSetting == 1 then
			if LocalPlayer():IsSuperAdmin() then
				canSeeQuickSettings = true
			end
		else
			if ulx then
				if LocalPlayer():CheckGroup(rankSetting) then
					canSeeQuickSettings = true
				end
			else
				if LocalPlayer():GetUserGroup() == rankSetting then
					canSeeQuickSettings = true
				end
			end
		end
	end
	
	-- Quick settings
	if canSeeQuickSettings then
		-- Open button
		local quickSettings = vgui.Create("DButton", titlePanel)
		quickSettings:SetSize(16, 14)
		quickSettings:SetPos(60, titlePanel:GetTall() - 30)
		quickSettings:SetText("")
		quickSettings:SetTooltip("Open quick settings menu")
		quickSettings:SetTextColor(colors.MainText)
		
		function quickSettings:Paint(w, h)
			surface.SetDrawColor(colors.MainText)
			
			if FancyScoreboard.QuickMenuOpen then
				surface.DrawLine(0, 0, w, h)
				surface.DrawLine(w, 0, 0, h)
			else
				surface.DrawLine(0, 0, w, 0)
				surface.DrawLine(0, h / 2 - 1, w, h / 2 - 1)
				surface.DrawLine(0, h - 1, w, h - 1)
			end
		end
		
		function quickSettings:DoClick()
			FancyScoreboard.QuickMenuOpen = not FancyScoreboard.QuickMenuOpen
			
			drawContent()
			
			if FancyScoreboard.QuickMenuOpen then
				-- Open menu
				local pos = titlePanel.OpenPos
				titlePanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				
				pos = contentPanel.OpenPos
				contentPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				
				pos = infoPanel.MenuOpenPos
				infoPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				
				pos = actionPanel.MenuOpenPos
				actionPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				
				quickSettings:SetTooltip("Close quick settings menu")
			else
				-- Close menu
				local pos = titlePanel.ClosedPos
				titlePanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				
				pos = contentPanel.ClosedPos
				contentPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				
				if selectedPlayer ~= nil then
					pos = infoPanel.MenuSelClosedPos
					infoPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				else
					pos = infoPanel.MenuClosedPos
					infoPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				end
				
				if selectedPlayer ~= nil then
					pos = actionPanel.MenuSelClosedPos
					actionPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				else
					pos = actionPanel.MenuClosedPos
					actionPanel:MoveTo(pos[1], pos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
				end
				
				quickSettings:SetTooltip("Open quick settings menu")
			end
		end
		
		-- Quick settings panel
		quickPanel = vgui.Create("DScrollPanel", titlePanel)
		quickPanel:SetSize(titlePanel:GetWide() - 60, titlePanel:GetTall() - 110)
		quickPanel:SetPos(30, 30)
		
		function quickPanel:Paint(w, h)
			
		end
		
		local vbar = quickPanel:GetVBar()
	
		function vbar:Paint(w, h)
			
		end
		
		function vbar.btnUp:Paint(w, h)
			draw.RoundedBox(2, w / 2 - 1, 0, 2, h - 2, colors.Accent)
		end
		
		function vbar.btnDown:Paint(w, h)
			draw.RoundedBox(2, w / 2 - 1, 2, 2, h, colors.Accent)
		end
		
		function vbar.btnGrip:Paint(w, h)
			draw.RoundedBox(2, w / 2 - 1, 0, 2, h, colors.Accent)
		end
	end
	
	-- Main panel
	contentPanel = vgui.Create("DPanel", menu)
	contentPanel:SetSize(maxWidth, ScrH() - 80)
	contentPanel.ClosedPos = { (ScrW() - contentPanel:GetWide()) / 2, 60 }
	contentPanel.OpenPos = { contentPanel.ClosedPos[1], ScrH() }
	contentPanel:SetPos(contentPanel.ClosedPos[1], ScrH())
	contentPanel:MoveTo(contentPanel.ClosedPos[1], contentPanel.ClosedPos[2], 0.25 * FancyScoreboard.Config.AnimationSpeed)
	
	function contentPanel:Paint(w, h)		
		local main = {
			{ x = 50, y = 0 },
			{ x = w - 50, y = 0 },
			{ x = w - 2, y = 50 },
			{ x = w - 2, y = h - 50 },
			{ x = w - 52, y = h - 2 },
			{ x = 52, y = h - 2 },
			{ x = 2, y = h - 50 },
			{ x = 2, y = 50 }	
		}
		
		local border = {
			{ x = 48, y = 0 },
			{ x = w - 48, y = 0 },
			{ x = w, y = 50 },
			{ x = w, y = h - 50 },
			{ x = w - 50, y = h },
			{ x = 50, y = h },
			{ x = 0, y = h - 50 },
			{ x = 0, y = 50 }	
		}
		
		draw.NoTexture()
		
		surface.SetDrawColor(colors.Accent)
		surface.DrawPoly(border)
		
		surface.SetDrawColor(colors.Main)
		surface.DrawPoly(main)
	end
	
	-- Labels	
	local nameLabel = vgui.Create("DLabel", contentPanel)
	nameLabel:SetText(FancyScoreboard.GetPhrase("Name"))
	nameLabel:SetFont("FancyScoreboard.Normal")
	nameLabel:SetTextColor(colors.MainText)
	nameLabel:SizeToContents()
	nameLabel:SetMouseInputEnabled(true)
	nameLabel:SetCursor("hand")
	
	if FancyScoreboard.Modules.RankIcon and FancyScoreboard.Modules.RankAliases then
		nameLabel:SetPos(110, 30)
	else
		nameLabel:SetPos(80, 30)
	end
	
	if FancyScoreboard.SortingMode then
		if FancyScoreboard.SortingMode[1] == "Name" then
			FancyScoreboard.SortingMode[3] = nameLabel
		end
	end
	
	function nameLabel:DoClick()
		if FancyScoreboard.SortingMode then
			if FancyScoreboard.SortingMode[1] == "Name" then
				sortPlayers(nil, nil)
				drawContent()
				
				return
			end
		end
		
		sortPlayers("Name", function(ply, other)
			local tbl = {
				[ply:Nick()] = 1,
				[other:Nick()] = 2
			}
			
			for k, v in SortedPairs(tbl) do
				if v == 1 then return true else return false end
			end
		end, self)
		
		drawContent()
	end
	
	local labelXPos = contentPanel:GetWide() - 40
	
	if FancyScoreboard.Modules.Muting then
		labelXPos = labelXPos - 30
	end
	
	-- Default scoreboard columns
	local scoreboardColumns = {
		Ping = {
			Name = FancyScoreboard.GetPhrase("Ping"),
			Value = function(ply)
				return ""
			end,
			Sort = function(ply, other)
				return ply:Ping() > other:Ping()
			end,
			Init = function(lbl, ply)
				lbl:SetSize(40, 20)
				lbl:CalcPos()
				lbl:SetPos(select(1, lbl.Parent:GetPos()) - 32, select(2, lbl:GetPos()))
			end,
			Paint = function(lbl, ply, w, h)
				local p
				
				if IsValid(ply) then
					p = ply:Ping()
					lbl:SetTooltip(p)
				else
					lbl:SetTooltip("Disconnected")
					p = 999
				end
				
				local col, level
				
				if p <= pingInfo.Good.Limit then
					col = pingInfo.Good.Color
					level = 3
				elseif p > pingInfo.Good.Limit and p <= pingInfo.Decent.Limit then
					col = pingInfo.Decent.Color
					level = 2
				else
					col = pingInfo.Bad.Color
					level = 1
				end
				
				local len = h / 3
				draw.RoundedBox(2, 0, h - len, 5, len, col)
				
				len = 2 * (h / 3)
				draw.RoundedBox(2, 6, h - len, 5, len, col)
				
				len = h
				draw.RoundedBox(2, 12, h - len, 5, len, col)
				
				surface.SetFont("FancyScoreboard.Small")
				local textWidth, textHeight = surface.GetTextSize(tostring(p))
				draw.SimpleText(p, "FancyScoreboard.Small", 20, (h - textHeight) / 2, colors.BackgroundText)
			end
		},
		Deaths = {
			Name = FancyScoreboard.GetPhrase("Deaths"),
			Value = function(ply)
				return ply:Deaths()
			end,
			Sort = function(ply, other)
				return ply:Deaths() > other:Deaths()
			end,
		},
		Kills = {
			Name = FancyScoreboard.GetPhrase("Kills"),
			Value = function(ply)
				return ply:Frags()
			end,
			Sort = function(ply, other)
				return ply:Frags() > other:Frags()
			end,
		},
		Team = {
			Name = function()
				if DarkRP then
					return FancyScoreboard.GetPhrase("Job")
				else
					return FancyScoreboard.GetPhrase("Team")
				end
			end,
			Value = function(ply)
				if DarkRP then
					return ply:getDarkRPVar("job")
				else
					return team.GetName(ply:Team())
				end
			end,
			Sort = function(ply, other)
				local function teamName(p)
					if DarkRP then
						return tostring(p:getDarkRPVar("job"))
					else
						return tostring(team.GetName(p:Team()))
					end
				end
				
				local tbl = {
					[teamName(ply)] = 1,
					[teamName(other)] = 2
				}
				
				for k, v in SortedPairs(tbl) do
					if v == 1 then return true else return false end
				end
			end,
			ColumnInit = function(lbl)
				surface.SetFont("FancyScoreboard.Normal")
				
				local longest = 0
				
				for k, v in pairs(player.GetAll()) do
					local size = ""
					
					if DarkRP then
						size = surface.GetTextSize(tostring(v:getDarkRPVar("job")))
					else
						size = surface.GetTextSize(tostring(team.GetName(v:Team())))
					end
					
					if size > longest then
						longest = size
					end
				end
				
				local difference = 0
				
				if longest > lbl:GetWide() then
					lbl:SetWide(longest)
				end
			end,
			Init = function(lbl, ply)
				if FancyScoreboard.Modules.TeamColor == 1 and selectedPlayer ~= ply then
					lbl.AutoColor = false
					lbl:SetTextColor(team.GetColor(ply:Team()))
				end
			end,
		},
	}
	
	-- Determine which columns to draw
	local columns = {}
	local order = { "Ping", "Deaths", "Kills", "Team" }
	
	if gmInfo ~= nil then		
		table.Merge(scoreboardColumns, gmInfo.Scoreboard.Custom)
		
		if type(gmInfo.Scoreboard.Order) == "function" then
			order = gmInfo.Scoreboard.Order()
		elseif type(gmInfo.Scoreboard.Order) == "table" then
			order = gmInfo.Scoreboard.Order
		end
		
		if not FancyScoreboard.Modules.Team then
			table.RemoveByValue(order, "Team")
		end
	end
	
	for k, v in pairs(order) do
		table.insert(columns, scoreboardColumns[v])
	end
	
	-- Draw columns
	for k, v in pairs(columns) do
		if type(v.Value) ~= "function" or type(v.Sort) ~= "function" then continue end
		
		local nameTxt = nil
		
		if type(v.Name) == "function" then
			nameTxt = tostring(v.Name())
		else
			nameTxt = tostring(v.Name)
		end
		
		local lbl = vgui.Create("DLabel", contentPanel)
		lbl:SetText(nameTxt)
		lbl:SetFont("FancyScoreboard.Normal")
		lbl:SizeToContents()
		lbl:SetMouseInputEnabled(true)
		lbl:SetCursor("hand")
		lbl:SetContentAlignment(5)
		
		if type(v.ColumnInit) == "function" then
			v.ColumnInit(lbl)
		end
		
		labelXPos = labelXPos - lbl:GetWide() - 30
		lbl:SetPos(labelXPos, 30)
		
		if FancyScoreboard.SortingMode then
			if FancyScoreboard.SortingMode[1] == nameTxt then
				FancyScoreboard.SortingMode[3] = lbl
			end
		end
		
		function lbl:DoClick()
			if FancyScoreboard.SortingMode then
				if FancyScoreboard.SortingMode[1] == nameTxt then
					sortPlayers(nil, nil, nil)
					drawContent()
					
					return
				end
			end
			
			sortPlayers(nameTxt, v.Sort, self)
			drawContent()
		end
		
		v.Label = lbl
	end
	
	-- Set label color
	if FancyScoreboard.SortingMode then
		local label = FancyScoreboard.SortingMode[3]
		
		if IsValid(label) then
			label:SetTextColor(colors.Accent)
		end
	end
	
	-- Scroll panel
	local scrollPanel = vgui.Create("DScrollPanel", contentPanel)
	scrollPanel:SetSize(contentPanel:GetWide() - 60, contentPanel:GetTall() - 120)
	scrollPanel:SetPos(30, 60)
	
	local vbar = scrollPanel:GetVBar()
	
	function vbar:Paint(w, h)
		
	end
	
	function vbar.btnUp:Paint(w, h)
		draw.RoundedBox(2, w / 2 - 1, 0, 2, h - 2, colors.Accent)
	end
	
	function vbar.btnDown:Paint(w, h)
		draw.RoundedBox(2, w / 2 - 1, 2, 2, h, colors.Accent)
	end
	
	function vbar.btnGrip:Paint(w, h)
		draw.RoundedBox(2, w / 2 - 1, 0, 2, h, colors.Accent)
	end
	
	-- Player info
	infoPanel = vgui.Create("DPanel", menu)
	infoPanel.OpenW = 270 --(ScrW() - contentPanel:GetWide()) / 2 - 30
	infoPanel.ClosedW = 40
	infoPanel.WDiff = infoPanel.OpenW - infoPanel.ClosedW
	infoPanel.OpenX = (ScrW() - contentPanel:GetWide()) / 2 - infoPanel.OpenW
	infoPanel.ClosedX = infoPanel.OpenX + infoPanel.WDiff
	infoPanel.MenuClosedPos = { infoPanel.ClosedX, 120 }
	infoPanel.MenuSelClosedPos = { infoPanel.OpenX, 120 }
	infoPanel.MenuOpenPos = { infoPanel.ClosedX, ScrH() + 60 }
	
	infoPanel:SetSize(infoPanel.OpenW, contentPanel:GetTall() - 120)
	infoPanel:SetPos(infoPanel.ClosedX, ScrH() + 60)
	infoPanel:MoveTo(infoPanel.ClosedX, 120, 0.25 * FancyScoreboard.Config.AnimationSpeed)
	
	function infoPanel:Paint(w, h)
		local border = {
			{ x = 50, y = 0 },
			{ x = w, y = 0 },
			{ x = w, y = h },
			{ x = 50, y = h },
			{ x = 0, y = h - 50 },
			{ x = 0, y = 50 }
		}
		
		local main = {
			{ x = 50, y = 2 },
			{ x = w, y = 2 },
			{ x = w, y = h - 2 },
			{ x = 52, y = h - 2 },
			{ x = 2, y = h - 52 },
			{ x = 2, y = 50 }
		}
		
		draw.NoTexture()
		
		surface.SetDrawColor(colors.Accent)
		surface.DrawPoly(border)
		
		surface.SetDrawColor(colors.Alt)
		surface.DrawPoly(main)
	end
	
	-- Action panel
	actionPanel = vgui.Create("DPanel", menu)
	actionPanel.OpenW = 270 -- (ScrW() - contentPanel:GetWide()) / 2 - 30
	actionPanel.ClosedW = 40
	actionPanel.WDiff = actionPanel.OpenW - actionPanel.ClosedW
	actionPanel.OpenX = (ScrW() + contentPanel:GetWide()) / 2
	actionPanel.ClosedX = actionPanel.OpenX - actionPanel.WDiff
	actionPanel.MenuClosedPos = { actionPanel.ClosedX, 120 }
	actionPanel.MenuSelClosedPos = { actionPanel.OpenX, 120 }
	actionPanel.MenuOpenPos = { actionPanel.ClosedX, ScrH() + 60 }
	
	actionPanel:SetSize(actionPanel.OpenW, contentPanel:GetTall() - 120)
	actionPanel:SetPos(actionPanel.ClosedX, ScrH() + 60)
	actionPanel:MoveTo(actionPanel.ClosedX, 120, 0.25 * FancyScoreboard.Config.AnimationSpeed)
	
	function actionPanel:Paint(w, h)		
		local border = {
			{ x = 0, y = 0 },
			{ x = w - 50, y = 0 },
			{ x = w, y = 50 },
			{ x = w, y = h - 50 },
			{ x = w - 50, y = h },
			{ x = 0, y = h }
		}
		
		local main = {
			{ x = 0, y = 2 },
			{ x = w - 52, y = 2 },
			{ x = w - 2, y = 50 },
			{ x = w - 2, y = h - 52 },
			{ x = w - 52, y = h - 2 },
			{ x = 0, y = h }
		}
		
		draw.NoTexture()
		
		surface.SetDrawColor(colors.Accent)
		surface.DrawPoly(border)
		
		surface.SetDrawColor(colors.Alt)
		surface.DrawPoly(main)
	end
	
	actionScrollPanel = vgui.Create("DScrollPanel", actionPanel)
	actionScrollPanel:SetPos(5, 80)
	actionScrollPanel:SetSize(actionPanel:GetWide() - 15, actionPanel:GetTall() - 160)
	
	local actionVBar = actionScrollPanel:GetVBar()
	
	function actionVBar:Paint(w, h)
		
	end
	
	function actionVBar.btnUp:Paint(w, h)
		if selectedPlayer ~= nil then
			draw.RoundedBox(2, w / 2 - 1, 0, 2, h - 2, colors.Accent)
		end
	end
	
	function actionVBar.btnDown:Paint(w, h)
		if selectedPlayer ~= nil then
			draw.RoundedBox(2, w / 2 - 1, 2, 2, h, colors.Accent)
		end
	end
	
	function actionVBar.btnGrip:Paint(w, h)
		if selectedPlayer ~= nil then
			draw.RoundedBox(2, w / 2 - 1, 0, 2, h, colors.Accent)
		end
	end
	
	contentPanel:MoveToFront()
	titlePanel:MoveToFront()
	
	-- Draw content
	drawContent = function()
		-- Reset variables and clear panel
		local yPos = 0
		scrollPanel:Clear()
		
		-- Util function to draw player panel
		local function drawPlayerPanel(ply)
			if not IsValid(ply) then return end
			
			local pnl = vgui.Create("DButton", scrollPanel)
			pnl:SetSize(scrollPanel:GetWide() - 10, 38)
			pnl:SetPos(0, yPos)
			pnl:SetText("")
			
			function pnl:Paint(w, h)
				if selectedPlayer == ply then
					draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
				else
					if FancyScoreboard.Modules.TeamColor == 2 then
						if IsValid(ply) then
							draw.RoundedBox(2, 0, 0, w, h, team.GetColor(ply:Team()))
						end
					else
						draw.RoundedBox(2, 0, 0, w, h, colors.Background)
					end
				end
			end
			
			function pnl:DoClick()
				if selectedPlayer ~= ply then
					selectedPlayer = ply
					
					infoPanel:Clear()
					actionScrollPanel:Clear()
				else
					selectedPlayer = nil
				end
				
				drawContent()
			end
			
			local avatar = vgui.Create("AvatarImage", pnl)
			avatar:SetSize(32, 32)
			avatar:SetPos(2, 2)
			avatar:SetPlayer(ply, 32)
			
			-- Icon
			if FancyScoreboard.Modules.RankIcon and FancyScoreboard.Modules.RankAliases then
				local rank = getRankInfo(ply:GetUserGroup())
				
				if rank.Icon ~= nil and rank.Icon ~= "" then
					local icon = vgui.Create("DImage", pnl)
					icon:SetImage(rank.Icon)
					icon:SizeToContents()
					icon:SetPos(50, (pnl:GetTall() - icon:GetTall()) / 2)
				end
			end
			
			-- Name
			local name = vgui.Create("DLabel", pnl)
			name:SetFont("FancyScoreboard.Normal")
			name:SetTextColor(colors.BackgroundText)
			name:SetText(ply:Nick())
			name:SizeToContents()
			
			if FancyScoreboard.Modules.RankIcon and FancyScoreboard.Modules.RankAliases then
				name:SetPos(80, (pnl:GetTall() - name:GetTall()) / 2)
			else
				name:SetPos(50, (pnl:GetTall() - name:GetTall()) / 2)
			end
			
			function name:Think()
				if not IsValid(ply) then
					self:SetText("Disconnected")
					self:SizeToContents()
					self.Think = nil
				end
				
				if selectedPlayer == ply then
					self:SetTextColor(colors.AccentText)
				else
					self:SetTextColor(colors.BackgroundText)
				end
			end
			
			-- Mute
			if FancyScoreboard.Modules.Muting then
				local mute = vgui.Create("DButton", pnl)
				mute:SetText("")
				mute:SetSize(40, 17)
				mute:SetPos(pnl:GetWide() - mute:GetWide(), (pnl:GetTall() - mute:GetTall()) / 2)
				
				function mute:DetermineState()
					if not IsValid(ply) then return end
					
					if ply:IsMuted() then
						self:SetImage("icon16/sound_mute.png")
					else
						self:SetImage("icon16/sound.png")
					end
				end
				
				function mute:Paint(w, h) end
				
				function mute:DoClick()
					if not IsValid(ply) then return end
					
					ply:SetMuted(not ply:IsMuted())
					self:DetermineState()
				end
				
				mute:DetermineState()
			end
			
			-- Labels
			for k, v in pairs(columns) do
				if not IsValid(v.Label) then continue end
				
				local lbl = vgui.Create("DLabel", pnl)
				lbl:SetFont("FancyScoreboard.Normal")
				lbl:SetTextColor(colors.BackgroundText)
				lbl:SetText(tostring(v.Value(ply)))
				lbl:SizeToContents()
				lbl:SetContentAlignment(5)
				lbl.Parent = v.Label
				lbl.AutoColor = true
				
				function lbl:Think()
					if self.AutoColor then
						if selectedPlayer == ply then
							self:SetTextColor(colors.AccentText)
						else
							self:SetTextColor(colors.BackgroundText)
						end
					end
				end
				
				function lbl:CalcPos()
					local lblX = select(1, v.Label:GetPos()) - 30 + (v.Label:GetWide() - self:GetWide()) / 2
					self:SetPos(lblX, (pnl:GetTall() - self:GetTall()) / 2)
				end
				
				lbl:CalcPos()
				
				if type(v.Paint) == "function" then
					function lbl:Paint(w, h)
						v.Paint(self, ply, w, h)
					end
				end
				
				if type(v.Init) == "function" then
					v.Init(lbl, ply)
				end
			end
			
			yPos = yPos + pnl:GetTall() + 10
		end
		
		-- Player list
		if FancyScoreboard.Modules.TeamCategorySorting then
			-- Team category sorting
			yPos = 20
			
			-- Get all active teams
			local teams = {}
			
			for k, v in pairs(players) do
				if not IsValid(v) then continue end
				
				teams[team.GetName(v:Team())] = v:Team()
			end
			
			-- Draw teams and players
			for k, v in SortedPairs(teams) do
				-- Draw team panel
				local pnl = vgui.Create("DPanel", scrollPanel)
				pnl:SetSize(scrollPanel:GetWide() - 10, 38)
				pnl:SetPos(0, yPos)
				
				function pnl:Paint(w, h)
					draw.RoundedBox(2, 0, 0, w, h, team.GetColor(v))
					draw.RoundedBox(2, 0, 0, w, h - 2, colors.Background)
				end
					
				local lbl = vgui.Create("DLabel", pnl)
				lbl:SetFont("FancyScoreboard.Normal")
				lbl:SetText(k)
				lbl:SetTextColor(colors.BackgroundText)
				lbl:SizeToContents()
				lbl:SetPos(10, (pnl:GetTall() - lbl:GetTall()) / 2)
				lbl:SetContentAlignment(5)
				
				yPos = yPos + pnl:GetTall() + 10
				
				-- Draw player panels
				for _, ply in pairs(players) do
					if not IsValid(ply) then continue end
					
					if ply:Team() == v then
						drawPlayerPanel(ply)
					end
				end
				
				yPos = yPos + 20
			end
		else
			-- Default player list
			for k, v in pairs(players) do
				if not IsValid(v) then continue end
				
				drawPlayerPanel(v)
			end
		end
		
		-- Info Panel
		if selectedPlayer and IsValid(selectedPlayer) then
			local xPos, yPos = infoPanel:GetPos()
			infoPanel:MoveTo(infoPanel.OpenX, yPos, 0.20 * FancyScoreboard.Config.AnimationSpeed)
			
			yPos = 80
			
			local avatarBg = vgui.Create("DPanel", infoPanel)
			avatarBg:SetSize(132, 132)
			avatarBg:SetPos((infoPanel.OpenW - avatarBg:GetWide()) / 2, yPos)
			
			function avatarBg:Paint(w, h)
				if not IsValid(selectedPlayer) then return end
				
				if FancyScoreboard.Modules.TeamColor > 0 then
					draw.RoundedBox(2, 0, 0, w, h, team.GetColor(selectedPlayer:Team()))
				else
					draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
				end
			end
			
			local avatar = vgui.Create("AvatarImage", avatarBg)
			avatar:SetSize(128, 128)
			avatar:SetPos(2, 2)
			avatar:SetPlayer(selectedPlayer, 128)
			
			yPos = yPos + avatarBg:GetTall() + 30
			
			surface.SetFont("FancyScoreboard.Large")
			local nameText = selectedPlayer:Nick()
			local nameW, nameH = surface.GetTextSize(tostring(nameText))
			
			local name = vgui.Create("DLabel", infoPanel)
			name:SetFont("FancyScoreboard.Large")
			name:SetTextColor(colors.Text)
			name:SetText(nameText)
			name:SetPos(20, yPos)
			name:SetSize(infoPanel.OpenW - 40, nameH)
			name:SetContentAlignment(5)
			
			yPos = yPos + nameH + 10
			
			if gmInfo ~= nil then
				if gmInfo.Sidebar.Defaults.SteamID then
					local steamidText = selectedPlayer:SteamID()
					local steamid = createLabel(infoPanel, steamidText, "FancyScoreboard.Normal", yPos)
					yPos = yPos + steamid:GetTall() + 10
				end
			end
			
			if FancyScoreboard.Modules.Rank and gmInfo ~= nil then
				if gmInfo.Sidebar.Defaults.Rank then
					local rank = getRankInfo(selectedPlayer:GetUserGroup())
					
					local rankLbl = createLabel(infoPanel, rank.Name, "FancyScoreboard.Normal", yPos, rank.Color)
					
					if FancyScoreboard.Modules.RankIcon and FancyScoreboard.Modules.RankAliases then
						if rank.Icon ~= nil and rank.Icon ~= "" then
							local rankIcon = vgui.Create("DImage", infoPanel)
							rankIcon:SetImage(rank.Icon)
							rankIcon:SizeToContents()
							
							-- Center everything again
							local totalWidth = rankLbl:GetWide() + 10 + rankIcon:GetWide()
							local newX = (infoPanel:GetWide() - totalWidth) / 2
							
							rankLbl:SetPos(newX, yPos)
							rankIcon:SetPos(newX + rankLbl:GetWide() + 10, yPos)
						end
					end
					
					yPos = yPos + rankLbl:GetTall() + 10
				end
			end
			
			if gmInfo ~= nil then
				if gmInfo.Sidebar.Defaults.Ping then
					local pingText = "Ping: " .. tostring(selectedPlayer:Ping())
					local ping = createLabel(infoPanel, pingText, "FancyScoreboard.Normal", yPos)
					yPos = yPos + ping:GetTall()
				end
			end
			
			yPos = yPos + 80
			
			-- Draw gamemode-specific info
			if gmInfo ~= nil and IsValid(selectedPlayer) then
				for k, v in pairs(gmInfo.Sidebar.Custom) do
					local text, color = v(selectedPlayer)
					
					if text == false then continue end
					
					local lbl = createLabel(infoPanel, tostring(text), "FancyScoreboard.Normal", yPos)
					
					if color ~= nil then
						lbl:SetTextColor(color)
					end
					
					yPos = yPos + lbl:GetTall() + 10
				end
			end
		elseif not selectedPlayer then
			local xPos, yPos = infoPanel:GetPos()
			infoPanel:MoveTo(infoPanel.ClosedX, yPos, 0.20 * FancyScoreboard.Config.AnimationSpeed)
			
			timer.Simple(0.20 * FancyScoreboard.Config.AnimationSpeed, function()
				if not selectedPlayer then
					if IsValid(infoPanel) then
						infoPanel:Clear()
					end
				end
			end)
		end
		
		-- Action panel
		if selectedPlayer and IsValid(selectedPlayer) then
			local xPos, yPos = actionPanel:GetPos()
			actionPanel:MoveTo(actionPanel.OpenX, yPos, 0.20 * FancyScoreboard.Config.AnimationSpeed)
			
			yPos = 0
			
			for k, v in pairs(FancyScoreboard.Buttons) do
				-- Ignore category if it is not properly set up, or if it is disabled
				if not istable(v) then continue end
				if not istable(v.Buttons) then continue end
				
				local catEnabled = false
				
				if type(v.Enabled) == "boolean" then
					catEnabled = v.Enabled
				elseif type(v.Enabled) == "function" then
					catEnabled = v.Enabled(selectedPlayer)
				end
				
				if not catEnabled then continue end
				
				-- Determine if user can use any action in category
				local canSeeCat = false
				
				for _, btnInfo in pairs(v.Buttons) do
					local canSeeBtn = false
					
					if type(btnInfo.Enabled) == "boolean" then
						canSeeBtn = btnInfo.Enabled
					elseif type(btnInfo.Enabled) == "function" then
						canSeeBtn = btnInfo.Enabled(selectedPlayer)
					end
					
					if canSeeBtn then
						canSeeCat = true
					end
				end
				
				if not canSeeCat then continue end
				
				-- Draw buttons and category
				local catLabel = createLabel(actionScrollPanel, v.Category or "Category", "FancyScoreboard.Normal", yPos)
				yPos = yPos + catLabel:GetTall() + 20
				
				for _, btnInfo in pairs(v.Buttons) do
					local canSeeBtn = false
					
					if type(btnInfo.Enabled) == "boolean" then
						canSeeBtn = btnInfo.Enabled
					elseif type(btnInfo.Enabled) == "function" then
						canSeeBtn = btnInfo.Enabled(selectedPlayer)
					end
					
					if canSeeBtn then						
						local name = "Button"
						
						if type(btnInfo.Name) == "string" then
							name = btnInfo.Name
						elseif type(btnInfo.Name) == "function" then
							name = btnInfo.Name(selectedPlayer)
						end
						
						local btn = createButton(actionScrollPanel, name, yPos, function(self)
							if type(btnInfo.Action) ~= "function" then return end
							
							if IsValid(selectedPlayer) then
								btnInfo.Action(selectedPlayer)
							else
								selectedPlayer = nil
								drawContent()
							end
						end)
					
						yPos = yPos + btn:GetTall() + 20
					end
				end
				
				yPos = yPos + 40
			end
		elseif not selectedPlayer then
			local xPos, yPos = actionPanel:GetPos()
			actionPanel:MoveTo(actionPanel.ClosedX, yPos, 0.20 * FancyScoreboard.Config.AnimationSpeed)
			
			timer.Simple(0.20 * FancyScoreboard.Config.AnimationSpeed, function()
				if not selectedPlayer then
					if IsValid(actionScrollPanel) then
						actionScrollPanel:Clear()
					end
				end
			end)
		end
		
		-- Quick Settings
		if FancyScoreboard.Config.QuickSettingsEnabled and FancyScoreboard.QuickMenuOpen then
			local totalCategories = 0
			local categoryIndex = 1
			
			-- Predefine category (Name only for reference)
			local function allocateCategory(name, check)
				if isfunction(check) then
					if check() == true then
						totalCategories = totalCategories + 1
					end
				elseif type(check) == "boolean" then
					if check == true then
						totalCategories = totalCategories + 1
					end
				end
			end
			
			-- Add category and determine layout
			local function addCategory(title, content, shouldDraw)
				local titleWidth = titlePanel:GetWide()
				local padding = 80
				local catWidth = 175
				local space = totalCategories * (catWidth + padding)
				local xPos = (titleWidth - space) / 2 + (categoryIndex - 1) * (catWidth + padding)
				yPos = 0
				
				-- Check if it should draw				
				if shouldDraw ~= nil then
					if isfunction(shouldDraw) then
						if not shouldDraw() then return end
					elseif type(shouldDraw) == "boolean" then
						if shouldDraw == false then return end
					end
				end
				
				-- Increment category index if drawing
				categoryIndex = categoryIndex + 1
				
				-- Title
				local titleLabel = vgui.Create("DLabel", quickPanel)
				titleLabel:SetText(FancyScoreboard.GetPhrase(title))
				titleLabel:SetFont("FancyScoreboard.Large")
				titleLabel:SetTextColor(colors.MainText)
				titleLabel:SizeToContents()
				titleLabel:SetPos(xPos + (catWidth - titleLabel:GetWide()) / 2, yPos)
				
				yPos = yPos + titleLabel:GetTall() + 30
				
				-- Draw content
				for k, v in pairs(content) do
					local enabled = true
					
					if v.Enabled ~= nil then
						if type(v.Enabled) == "function" then
							enabled = v.Enabled()
						elseif type(v.Enabled) == "boolean" then
							enabled = v.Enabled
						end
					end
					
					if enabled then
						local btn = vgui.Create("DButton", quickPanel)
						btn:SetPos(xPos, yPos)
						btn:SetSize(catWidth, 35)
						btn:SetTextColor(colors.AccentText)
						
						-- Determine if to draw Enable/Disable text
						if v.Value ~= nil then
							local val = v.Value
							local text = tostring(v.Text or "")
							
							if type(v.Phrase) == "string" then
								text = FancyScoreboard.GetPhrase(v.Phrase)
							end
							
							if type(v.Value) == "function" then
								val = v.Value()
							end
							
							if val then
								text = FancyScoreboard.GetPhrase("Disable") .. " " .. text
							else
								text = FancyScoreboard.GetPhrase("Enable") .. " " .. text
							end
							
							btn:SetText(text)
						else
							if type(v.Phrase) == "string" then
								btn:SetText(FancyScoreboard.GetPhrase(v.Phrase))
							else
								btn:SetText(v.Text)
							end
						end
						
						function btn:DoClick()
							local cmd = v.Command
							local action = v.Action
							local notification = v.Notification
							
							-- Check if to use primary or secondary action/command
							local passCheck = true
							
							if isfunction(v.Check) then
								passCheck = v.Check()
							elseif type(v.Check) == "boolean" then
								passCheck = v.Check
							end
							
							if not passCheck then
								cmd = v.CommandSecondary
								action = v.ActionSecondary
								notification = v.NotificationSecondary
							end
							
							-- Perform action
							if type(cmd) == "string" then
								RunConsoleCommand(unpack(string.Explode(" ", cmd)))
							elseif istable(cmd) then
								RunConsoleCommand(unpack(cmd))
							end
							
							if type(action) == "string" then
								net.Start("FancyScoreboard.QuickSetting")
								net.WriteString(action)
								net.SendToServer()
							elseif type(action) == "function" then
								action()
							end
							
							if notification ~= nil then
								chat.AddText(colors.MainText, notification)
							end
							
							-- Redraw
							timer.Simple(0.1, drawContent)
						end
						
						function btn:Paint(w, h)
							if self.Hovered then
								draw.RoundedBox(2, 0, 0, w, h, colors.Selected)
							else
								draw.RoundedBox(2, 0, 0, w, h, colors.Accent)
							end
						end
						
						yPos = yPos + btn:GetTall() + 20
					end
				end
			end
			
			-- Generate command, fix Sandbox issues
			local function generateCommand(cmd, subcmd)
				if not ConVarExists(subcmd) then return "" end
				
				return tostring(cmd) .. tostring(GetConVar(subcmd):GetBool() and 0 or 1)
			end
			
			-- [TEMP] Calls FAdmin control GUI function
			local function fadminActionButton(btnType, name)
				for k, v in pairs(FAdmin.ScoreBoard.Server.ActionButtons) do
					if v.TYPE == btnType and v.Name == name then
						v.Action()
					end
				end
			end
			
			-- Allocate space for categories
			allocateCategory("Actions", true)
			allocateCategory("Player", FAdmin ~= nil)
			allocateCategory("Settings", true)
			
			-- Categories
			addCategory("Actions", {
				{
					Phrase = "RCon",
					Enabled = FAdmin ~= nil,
					Action = function()
						FancyScoreboard.OpenDialogue({
							Title = "RCon",
							Type = "Confirm",
							AcceptText = "OK",
							DeclineText = "Cancel",
							Width = 500,
							Build = function(menu)
								local settings = {
									Text = ""
								}
								
								local label = vgui.Create("DLabel", menu)
								label:SetText("Enter a command to be run on the server.\nNote: a lot of commands are blocked and they will not work!")
								label:SetFont("FancyScoreboard.Normal")
								label:SetPos(0, 0)
								label:SetSize(menu:GetWide(), 40)
								
								local textEntry = vgui.Create("DTextEntry", menu)
								textEntry:SetWide(menu:GetWide())
								textEntry:SetPos(0, 45 + label:GetTall())
								textEntry:SetUpdateOnType(true)
								
								function textEntry:OnValueChange(value)
									settings.Text = value
								end
								
								return settings
							end,
							OnAccept = function(settings)
								RunConsoleCommand("_FAdmin", "RCon", unpack(string.Explode(" ", settings.Text)))
							end
						})
					end
				},
				{
					Phrase = "ClearDecals",
					Check = FAdmin ~= nil,
					Command = "_FAdmin ClearDecals",
					NotificationSecondary = "Cleared decals",
					ActionSecondary = "ClearDecals"
				},
				{
					Phrase = "StopSounds",
					Check = FAdmin ~= nil,
					Command = "_FAdmin StopSounds",
					NotificationSecondary = "Stopped sounds",
					ActionSecondary = "StopSounds"
				},
				{
					Phrase = "CleanUp",
					Check = FAdmin ~= nil,
					Command = "_FAdmin CleanUp",
					NotificationSecondary = "Cleaned up server",
					ActionSecondary = "CleanUp"
				},
			})
			
			addCategory("Player", {
				{
					Phrase = "EditGroups",
					Action = function()
						-- [TODO]
						fadminActionButton("PlayerActions", "Edit groups")
					end
				},
				{
					Phrase = "Unban",
					Action = function()
					
					fadminActionButton("PlayerActions", "Unban")
					
					--[[
						FancyScoreboard.OpenDialogue({
							Title = "Unban Details",
							Type = "Notice",
							Width = 750,
							Build = function(menu)
								local banList = vgui.Create("DListView", menu)
								banList:SetPos(0, 0)
								banList:SetSize(menu:GetWide(), 350)
								banList:AddColumn("SteamID")
								banList:AddColumn("Name")
								banList:AddColumn("Time")
								banList:AddColumn("Reason")
								banList:AddColumn("Banned by")
								banList:AddColumn("Banned by SteamID")
								
								for k, v in pairs(banList.Columns) do
									v.Header:SetTextColor(FancyScoreboard.Colors.AccentText)
									
									function v.Header:Paint(w, h)
										if self.IsHovered() then
											draw.RoundedBox(2, 2, 2, w - 4, h - 4, FancyScoreboard.Colors.Selected)
										else
											draw.RoundedBox(2, 2, 2, w - 4, h - 4, FancyScoreboard.Colors.Accent)
										end
									end
								end
								
								function banList:Paint(w, h)
									draw.RoundedBox(2, 0, 0, w, h, FancyScoreboard.Colors.Background)
								end
								
								function banList:OnRowRightClick(lineID)
									local line = self:GetLine(lineID)
									local d = DermaMenu()
									
									-- Edit unban window
									d:AddOption("Edit", function()
										FancyScoreboard.OpenDialogue({
											Title = "Edit Ban Details",
											Type = "Confirm",
											Build = function(menu)
												-- Variables
												local wangXPos = 0
												local banTime = line.Time or 60
												local settings = {
													Reason = line.Reason or "",
													Time = {
														Minutes = banTime % 60,
														Hours = math.floor(banTime / 60) % 24,
														Days = math.floor(banTime / 1440) % 7,
														Weeks = math.floor(banTime / 10080) % 53,
														Years = math.floor(banTime / 525948)
													}
												}
												
												-- Util function to add number wang with label
												local function addWang(name, min, max)													
													local label = vgui.Create("DLabel", menu)
													label:SetText(name .. ": ")
													label:SetTextColor(FancyScoreboard.Colors.BackgroundText)
													label:SetFont("FancyScoreboard.Normal")
													label:SetPos(wangXPos, 40)
													label:SizeToContents()
													
													local wang = vgui.Create("DNumberWang", menu)
													wang:SetPos(wangXPos, label:GetTall() + 45)
													wang:SetDecimals(0) 
													wang:SetMinMax(min, max)
													wang:SetValue(settings.Time[name])
													
													function wang:OnValueChanged(value)
														settings.Time[name] = value
													end
													
													local width = label:GetWide()
													
													if wang:GetWide() > width then
														width = wang:GetWide()
													end
													
													wangXPos = wangXPos + width + 20
													
													return wang
												end
												
												-- Build menu
												local nameLabel = vgui.Create("DLabel", menu)
												nameLabel:SetText("Ban details for: " .. line.Name)
												nameLabel:SetFont("FancyScoreboard.Normal")
												nameLabel:SetTextColor(FancyScoreboard.Colors.BackgroundText)
												nameLabel:SizeToContents()
												nameLabel:SetPos(0, 0)
												
												addWang("Minutes", 0, 59)
												addWang("Hours", 0, 23)
												addWang("Days", 0, 6)
												addWang("Weeks", 0, 53)
												addWang("Years", 0, 4)
												
												local reasonLabel = vgui.Create("DLabel", menu)
												reasonLabel:SetText("Reason")
												reasonLabel:SetFont("FancyScoreboard.Normal")
												reasonLabel:SetTextColor(FancyScoreboard.Colors.BackgroundText)
												reasonLabel:SizeToContents()
												reasonLabel:SetPos(0, 100)
												
												local reasonBox = vgui.Create("DTextEntry", menu)
												reasonBox:SetPos(0, 100 + reasonLabel:GetTall())
												reasonBox:SetSize(wangXPos, 26)
												reasonBox:SetText(settings.Reason)
												reasonBox:SetUpdateOnType(true)
												
												function reasonBox:OnChange()
													settings.Reason = self:GetText()
												end
												
												return settings
											end,
											OnAccept = function(settings)
												local time = settings.Time.Minutes + 
													settings.Time.Hours * 60 + 
													settings.Time.Days * 1440 + 
													settings.Time.Weeks * 10080 + 
													settings.Time.Years * 525948
												
												RunConsoleCommand("_FAdmin", "ban", line.SteamID, "update", time, settings.Reason)
												--RunConsoleCommand("_FAdmin", "ban", line.SteamID, time, settings.Reason)
											end
										})
									end)
									
									d:AddOption("Unban", function()
										RunConsoleCommand("_FAdmin", "Unban", string.upper(line:GetValue(1)))
										self:RemoveLine(lineID)
									end)
									
									d:Open()
								end
								
								-- Populate list
								net.Receive("FAdmin_retrievebans", function(len, ply)
									banList:Clear()
									local banCount = net.ReadUInt(32)
									
									for i = 1, banCount do
										local steamID = net.ReadString()
										local time = net.ReadUInt(32)
										local name = net.ReadString()
										local reason = net.ReadString()
										local adminName = net.ReadString()
										local adminSteamID = net.ReadString()

										local line = banList:AddLine(
											steamID,
											name or "N/A",
											(tonumber(time or "") and FAdmin.PlayerActions.ConvertBanTime((tonumber(time) - os.time()) / 60)) or "N/A",
											reason or "",
											adminName or "",
											adminSteamID or ""
										)
										
										line.SteamID = steamID
										line.Name = name
										line.Time = time
										line.Reason = reason
										
										for k, v in pairs(line.Columns) do
											v:SetTextColor(FancyScoreboard.Colors.BackgroundText)
										end
										
										function line:Paint(w, h)
											if self:IsLineSelected() then
												draw.RoundedBox(2, 0, 0, w, h, FancyScoreboard.Colors.Accent)
											elseif self:IsHovered() then
												draw.RoundedBox(2, 0, 0, w, h, FancyScoreboard.Colors.Selected)
											end
										end
									end
								end)
								
								RunConsoleCommand("_FAdmin", "RequestBans")
							end
						})
						--]]
					end
				},
				{
					Phrase = "AdminPlayerPickup",
					Value = function()
						if FAdmin == nil then return end
						if not ConVarExists("AdminsCanPickUpPlayers") then return false end
						
						return GetConVar("AdminsCanPickUpPlayers"):GetBool()
					end,
					Command = generateCommand("FAdmin", "AdminsCanPickUpPlayers")
					--Command = "FAdmin AdminsCanPickUpPlayers " .. tostring(GetConVar("AdminsCanPickUpPlayers"):GetBool() and 0 or 1),
				},
				{
					Phrase = "PlayerPlayerPickup",
					Command = "_FAdmin PlayersCanPickUpPlayers",
					Value = function()
						if FAdmin == nil then return end
						if not ConVarExists("PlayersCanPickUpPlayers") then return false end
						
						return GetConVar("PlayersCanPickUpPlayers"):GetBool()
					end,
					Command = generateCommand("FAdmin", "PlayersCanPickUpPlayers")
					--Command = "FAdmin PlayersCanPickUpPlayers " .. tostring(GetConVar("PlayersCanPickUpPlayers"):GetBool() and 0 or 1),
				},
				{
					Phrase = "RestrictWeapons",
					Action = function()
						-- [TODO]
						fadminActionButton("PlayerActions", "Restrict weapons")
					end
				}
			}, FAdmin ~= nil)
			
			addCategory("Settings", {
				{
					Phrase = "Godmode",
					Enabled = ConVarExists("sbox_godmode"),
					Value = GetConVar("sbox_godmode"):GetBool(),
					Check = FAdmin ~= nil,
					Command = "_FAdmin ServerSetting sbox_godmode " .. tostring(GetConVar("sbox_godmode"):GetBool() and 0 or 1),
					NotificationSecondary = "Toggled Godmode",
					ActionSecondary = "Godmode"
				},
				{
					Phrase = "Noclip",
					Enabled = ConVarExists("sbox_noclip"),
					Value = GetConVar("sbox_noclip"):GetBool(),
					Check = FAdmin ~= nil,
					Command = "_FAdmin ServerSetting sbox_noclip " .. tostring(GetConVar("sbox_noclip"):GetBool() and 0 or 1),
					NotificationSecondary = "Toggled Noclip",
					ActionSecondary = "Noclip"
				},
				{
					Phrase = "PvP",
					Enabled = ConVarExists("sbox_playershurtplayers"),
					Value = GetConVar("sbox_playershurtplayers"):GetBool(),
					Check = FAdmin ~= nil,
					Command = "_FAdmin ServerSetting sbox_playershurtplayers " .. tostring(GetConVar("sbox_playershurtplayers"):GetBool() and 0 or 1),
					NotificationSecondary = "Toggled PvP",
					ActionSecondary = "PvP"
				},
				{
					Phrase = "ServerLimits",
					Enabled = FAdmin ~= nil,
					Action = function()
						FancyScoreboard.OpenDialogue({
							Title = "Set Server Limits",
							Type = "Notice",
							Width = 450,
							Build = function(menu)
								local settings = util.KeyValuesToTable(file.Read("gamemodes/sandbox/sandbox.txt", "GAME"))
								local yPos = 0
								
								for k, v in SortedPairs(settings.settings or {}) do
									if v.type == "Numeric" then
										local convarVal = GetConVar(v.name):GetFloat()
										
										local label = vgui.Create("DLabel", menu)
										label:SetText(v.name)
										label:SetFont("FancyScoreboard.Normal")
										label:SetTextColor(FancyScoreboard.Colors.BackgroundText)
										label:SizeToContents()
										label:SetPos(0, yPos)
										
										local numWang = vgui.Create("DNumberWang", menu)
										numWang:SetMinMax(v.low or 0, v.high or 1000)
										numWang:SetValue(convarVal)
										numWang:SetDecimals(v.decimals or 0)
										numWang:SetPos(menu:GetWide() - numWang:GetWide(), yPos)
										
										yPos = yPos + numWang:GetTall() + 10
										
										function numWang:ValueChanged(value)
											if value == convarVal then return end
											
											RunConsoleCommand("_FAdmin", "ServerSetting", v.name, value)
										end
									end
								end
							end,
						})
					end
				}
			})
		end
	end
	
	-- Hint at the bottom
	if FancyScoreboard.Config.EnableHint and not FancyScoreboard.Config.EnableMouse then		
		hintLabel = vgui.Create("DLabel", menu)
		hintLabel:SetFont("FancyScoreboard.Normal")
		hintLabel:SetText(FancyScoreboard.Language.Hint)
		hintLabel:SetColor(Color(255, 255, 255, 0))
		hintLabel:SizeToContents()
		hintLabel:SetPos((ScrW() - hintLabel:GetWide()) / 2, ScrH() - 20)
		
		hintLabel:ColorTo(Color(255, 255, 255, 150), 0.25)
	end
	
	drawContent()
	
	-- Save menus
	FancyScoreboard.Menu = menu
	FancyScoreboard.MenuTitle = titlePanel
	FancyScoreboard.MenuMain = contentPanel
	FancyScoreboard.MenuMain.InfoPanel = infoPanel
	FancyScoreboard.MenuMain.ActionPanel = actionPanel
end

-- Hide scoreboard
function FancyScoreboard.Hide()
	if not FancyScoreboard.Open then return end
	
	local menu = FancyScoreboard.Menu
	local content = FancyScoreboard.MenuMain
	local title = FancyScoreboard.MenuTitle
	local hint = FancyScoreboard.MenuHint
	
	if FancyScoreboard.DialogueOpen == 0 then
		gui.EnableScreenClicker(false)
	end
	
	if FancyScoreboard.Config.BackgroundBlur then
		if IsValid(menu) then
			function menu:Paint(w, h) end
		end
	end
	
	if IsValid(title) then
		local x, y = title:GetPos()
		title:MoveTo(x, -title:GetTall(), 0.25 * FancyScoreboard.Config.AnimationSpeed)
	end
	
	if IsValid(content) then
		local infoPanel = content.InfoPanel
		local actionPanel = content.ActionPanel
		
		if IsValid(infoPanel) then
			local x, y = infoPanel:GetPos()
			local w, h = infoPanel:GetSize()
			
			infoPanel:MoveTo(select(1, content:GetPos()), ScrH(), 0.25 * FancyScoreboard.Config.AnimationSpeed)
			infoPanel:SizeTo(0, h, 0.25 * FancyScoreboard.Config.AnimationSpeed)
		end
		
		if IsValid(actionPanel) then
			local x, y = actionPanel:GetPos()
			local w, h = actionPanel:GetSize()
			
			actionPanel:MoveTo(x, ScrH(), 0.25 * FancyScoreboard.Config.AnimationSpeed)
			actionPanel:SizeTo(0, h, 0.25 * FancyScoreboard.Config.AnimationSpeed)
		end
		
		local x, y = content:GetPos()
		content:MoveTo(x, ScrH(), 0.25 * FancyScoreboard.Config.AnimationSpeed)
	end
	
	if IsValid(hint) then
		hint:ColorTo(Color(255, 255, 255, 0), 0.25 * FancyScoreboard.Config.AnimationSpeed)
	end
	
	timer.Simple(0.25 * FancyScoreboard.Config.AnimationSpeed, function()
		if IsValid(menu) then
			menu:Remove()
			menu = nil
		end
		
		if not FancyScoreboard.DialogueOpen then
			gui.EnableScreenClicker(false)
		end
		
		FancyScoreboard.Open = false
		FancyScoreboard.QuickMenuOpen = false
	end)
end

-- Hooks
if FancyScoreboard.Config.Enabled then
	hook.Add("InitPostEntity", "FancyScoreboard.ShowDelay", function()
		timer.Simple(2, function()
			FancyScoreboard.CanOpen = true
		end)
	end)
	
	hook.Add("ScoreboardShow", "FancyScoreboard.Show", function()
		if not IsValid(LocalPlayer()) then return end
		
		if FancyScoreboard.Config.IsToggle then
			if FancyScoreboard.Open then
				FancyScoreboard.Hide()
			else
				FancyScoreboard.Show()
			end
		else
			FancyScoreboard.Show()
		end
		
		return true
	end)

	hook.Add("ScoreboardHide", "FancyScoreboard.Hide", function()		
		if not FancyScoreboard.Config.IsToggle then
			FancyScoreboard.Hide()
		end
		
		return true
	end)
end

-- More includes
include("cl_gminfo.lua")
include("cl_buttons.lua")

-- Stopsound workaround
net.Receive("FancyScoreboard.StopSounds", function(len, ply)
	RunConsoleCommand("stopsound")
end)