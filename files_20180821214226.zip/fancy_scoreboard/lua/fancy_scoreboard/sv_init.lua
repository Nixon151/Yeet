/*
	FancyScoreboard (Version 1.3.4)
	Created by: http://steamcommunity.com/profiles/76561198046951756
*/

-- Don't edit unless you know what you're doing! --


-- Includes
include("config.lua")

-- Client Lua
AddCSLuaFile("config.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("cl_fonts.lua")
AddCSLuaFile("cl_buttons.lua")
AddCSLuaFile("cl_gminfo.lua")

-- Net messages
util.AddNetworkString("FancyScoreboard.StopSounds")
util.AddNetworkString("FancyScoreboard.QuickSetting")

local quickSettingActions = {
	-- Actions
	ClearDecals = function()
		for k, v in pairs(player.GetAll()) do
			v:ConCommand("r_cleardecals")
		end
	end,
	
	StopSounds = function()
		net.Start("FancyScoreboard.StopSounds")
		net.Broadcast()
	end,
	
	CleanUp = function()
		game.CleanUpMap()
	end,
	
	-- Settings
	Godmode = function()
		local val = GetConVar("sbox_godmode"):GetBool()
		RunConsoleCommand("sbox_godmode", val and 0 or 1)
	end,
	
	Noclip = function()
		local val = GetConVar("sbox_noclip"):GetBool()
		RunConsoleCommand("sbox_noclip", val and 0 or 1)
	end,
	
	PvP = function()
		local val = GetConVar("sbox_playershurtplayers"):GetBool()
		RunConsoleCommand("sbox_playershurtplayers", val and 0 or 1)
	end,
}

-- Change quick settings
net.Receive("FancyScoreboard.QuickSetting", function(len, ply)
	if not IsValid(ply) then return end
	
	-- Check rank
	local rankSetting = FancyScoreboard.Config.QuickSettingsRank
	
	if rankSetting == 0 then
		if not ply:IsAdmin() then return end
	elseif rankSetting == 1 then
		if not ply:IsSuperAdmin() then return end
	else
		if ulx then
			if not ply:CheckGroup(rankSetting) then return end
		else
			if ply:GetUserGroup() ~= rankSetting then return end
		end
	end
	
	-- Check action
	local action = net.ReadString()
	
	if quickSettingActions[action] ~= nil then
		quickSettingActions[action]()
	end
end)